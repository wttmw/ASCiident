package com.asciiwall.live.ui.sections

import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.asciiwall.live.R
import com.asciiwall.live.presets.PresetRegistry
import com.asciiwall.live.settings.Profile
import com.asciiwall.live.ui.MainViewModel
import com.asciiwall.live.ui.components.AppSlider
import com.asciiwall.live.ui.components.GroupLabel
import com.asciiwall.live.ui.components.SectionCard
import com.asciiwall.live.ui.components.SwitchRow
import com.asciiwall.live.ui.components.VSpace
import java.util.Locale
import kotlin.math.roundToInt

private const val MIN = 0.25f
private const val MAX = 3f
/** Шаг 0.05 между 0.25 и 3.0 = 55 интервалов, 54 промежуточных деления. */
private const val STEPS = 54

private fun speedText(v: Float) = String.format(Locale.US, "%.2fx", v)
private fun snap(v: Float) = (v * 20f).roundToInt() / 20f

@Composable
fun SpeedSection(profile: Profile, vm: MainViewModel) {
    val sp = profile.speedFor()
    val frozen = sp.global <= 0f
    val presetName = stringResource(remember(profile.presetId) { PresetRegistry.create(profile.presetId).nameRes })

    SectionCard(
        tag = stringResource(R.string.section_speed),
        title = stringResource(R.string.section_speed_title)
    ) {
        Column {
            // Скорости хранятся отдельно для каждого пресета.
            GroupLabel(presetName)

            SwitchRow(
                label = stringResource(R.string.speed_freeze),
                checked = frozen,
                onChange = { on -> vm.setSpeed { it.copy(global = if (on) 0f else 1f) } }
            )
            VSpace(4.dp)

            AppSlider(
                label = stringResource(R.string.speed_global),
                valueText = if (frozen) "0x" else speedText(sp.global),
                value = sp.global,
                range = MIN..MAX,
                steps = STEPS,
                enabled = !frozen,
                onChange = { v -> vm.setSpeed { it.copy(global = snap(v)) } }
            )
            AppSlider(
                label = stringResource(R.string.speed_background),
                valueText = speedText(sp.background),
                value = sp.background,
                range = MIN..MAX,
                steps = STEPS,
                onChange = { v -> vm.setSpeed { it.copy(background = snap(v)) } }
            )
            AppSlider(
                label = stringResource(R.string.speed_events),
                valueText = speedText(sp.events),
                value = sp.events,
                range = MIN..MAX,
                steps = STEPS,
                onChange = { v -> vm.setSpeed { it.copy(events = snap(v)) } }
            )
            AppSlider(
                label = stringResource(R.string.speed_parallax),
                valueText = speedText(sp.parallax),
                value = sp.parallax,
                range = MIN..MAX,
                steps = STEPS,
                onChange = { v -> vm.setSpeed { it.copy(parallax = snap(v)) } }
            )
        }
    }
}

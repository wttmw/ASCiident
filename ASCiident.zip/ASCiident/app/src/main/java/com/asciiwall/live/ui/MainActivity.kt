package com.asciiwall.live.ui

import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.asciiwall.live.R
import com.asciiwall.live.ui.components.ActionButton
import com.asciiwall.live.ui.components.ScreenHeader
import com.asciiwall.live.ui.sections.CharsSection
import com.asciiwall.live.ui.sections.ColorSection
import com.asciiwall.live.ui.sections.EffectsSection
import com.asciiwall.live.ui.sections.GridSection
import com.asciiwall.live.ui.sections.ImageSection
import com.asciiwall.live.ui.sections.PresetSection
import com.asciiwall.live.ui.sections.ProfilesSection
import com.asciiwall.live.ui.sections.SpeedSection
import com.asciiwall.live.ui.sections.ThemeSection
import com.asciiwall.live.ui.theme.App
import com.asciiwall.live.ui.theme.AppTheme
import com.asciiwall.live.wallpaper.AsciiWallpaperService

/**
 * Главный экран. AppCompatActivity нужна для переключения языка (per-app locale).
 * Сверху закреплённое превью, под ним прокручиваемый список секций.
 */
class MainActivity : AppCompatActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent { Root() }
    }

    override fun onStop() {
        vm.flush()
        super.onStop()
    }

    @Composable
    private fun Root() {
        val loaded by vm.loaded.collectAsStateWithLifecycle()
        val ui by vm.ui.collectAsStateWithLifecycle()
        val profile by vm.profile.collectAsStateWithLifecycle()
        val saved by vm.saved.collectAsStateWithLifecycle()
        val context = LocalContext.current

        LaunchedEffect(loaded, ui.language, ui.themeMode) {
            if (loaded) {
                LocaleHelper.apply(ui.language)
                LocaleHelper.applyNightMode(ui.themeMode)
            }
        }

        LaunchedEffect(Unit) {
            vm.events.collect { e ->
                val res = when (e) {
                    UiEvent.SAVED -> R.string.msg_saved
                    UiEvent.LIMIT -> R.string.msg_limit
                    UiEvent.LOADED -> R.string.msg_loaded
                    UiEvent.IMPORTED -> R.string.msg_imported
                    UiEvent.IMPORT_FAILED -> R.string.msg_import_failed
                    UiEvent.IMAGE_FAILED -> R.string.msg_image_failed
                }
                Toast.makeText(context, res, Toast.LENGTH_SHORT).show()
            }
        }

        AppTheme(ui) {
            val c = App.colors
            Box(Modifier.fillMaxSize().background(c.bg)) {
                if (loaded) {
                    Column(Modifier.fillMaxSize()) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .background(c.bg)
                                .statusBarsPadding()
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            PreviewPane(presetId = profile.presetId, lightPreview = ui.previewLight)
                        }

                        LazyColumn(
                            Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            item(key = "header") {
                                Column(Modifier.padding(horizontal = 4.dp)) {
                                    ScreenHeader(
                                        tag = stringResource(R.string.header_tag),
                                        title = stringResource(R.string.header_title),
                                        subtitle = stringResource(R.string.header_subtitle)
                                    )
                                }
                            }
                            item(key = "set") {
                                ActionButton(
                                    stringResource(R.string.action_set_wallpaper),
                                    { openWallpaperPicker() },
                                    modifier = Modifier.fillMaxWidth(),
                                    filled = true
                                )
                            }
                            item(key = "preset") { PresetSection(profile, vm) }
                            item(key = "grid") { GridSection(profile, vm) }
                            item(key = "chars") { CharsSection(profile, vm) }
                            item(key = "color") { ColorSection(profile, vm) }
                            item(key = "effects") { EffectsSection(profile, vm) }
                            item(key = "speed") { SpeedSection(profile, vm) }
                            item(key = "image") { ImageSection(profile, vm) }
                            item(key = "theme") { ThemeSection(ui, vm) }
                            item(key = "profiles") { ProfilesSection(profile, saved, vm) }
                            item(key = "bottom") { Box(Modifier.navigationBarsPadding()) }
                        }
                    }
                }
            }
        }
    }

    /** Открывает системный выбор обоев сразу на наших обоях, иначе общий список. */
    private fun openWallpaperPicker() {
        val component = ComponentName(this, AsciiWallpaperService::class.java)
        val direct = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
        try {
            startActivity(direct)
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: ActivityNotFoundException) {
            }
        }
    }
}

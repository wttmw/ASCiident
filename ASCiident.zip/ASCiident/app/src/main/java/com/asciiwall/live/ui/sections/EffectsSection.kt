package com.asciiwall.live.ui.sections

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.asciiwall.live.R
import com.asciiwall.live.settings.Profile
import com.asciiwall.live.ui.MainViewModel
import com.asciiwall.live.ui.components.ActionButton
import com.asciiwall.live.ui.components.AppSlider
import com.asciiwall.live.ui.components.SectionCard
import com.asciiwall.live.ui.components.VSpace
import kotlin.math.roundToInt

private const val CUTOFF_MAX = 0.6f
private const val CUTOFF_DEFAULT = 0.12f

private fun pct(v: Float) = "${(v * 100).roundToInt()}%"
private fun snap(v: Float) = (v * 20f).roundToInt() / 20f

@Composable
fun EffectsSection(profile: Profile, vm: MainViewModel) {
    // Баланс заполнения: правее = больше символов. Внутри хранится порог пустоты (наоборот).
    val fill = 1f - profile.cutoff / CUTOFF_MAX

    SectionCard(
        tag = stringResource(R.string.section_effects),
        title = stringResource(R.string.section_effects_title)
    ) {
        Column {
            AppSlider(
                label = stringResource(R.string.effect_density),
                valueText = pct(fill),
                value = fill,
                range = 0f..1f,
                onChange = { v -> vm.update { it.copy(cutoff = (1f - snap(v)) * CUTOFF_MAX) } }
            )
            AppSlider(
                label = stringResource(R.string.effect_flicker),
                valueText = pct(profile.flicker),
                value = profile.flicker,
                range = 0f..1f,
                onChange = { v -> vm.update { it.copy(flicker = snap(v)) } }
            )
            AppSlider(
                label = stringResource(R.string.effect_noise),
                valueText = pct(profile.noise),
                value = profile.noise,
                range = 0f..1f,
                onChange = { v -> vm.update { it.copy(noise = snap(v)) } }
            )
            AppSlider(
                label = stringResource(R.string.effect_glow),
                valueText = pct(profile.glow),
                value = profile.glow,
                range = 0f..1f,
                onChange = { v -> vm.update { it.copy(glow = snap(v)) } }
            )
            AppSlider(
                label = stringResource(R.string.effect_contrast),
                valueText = ((profile.contrast - 0.5f) * 200f).roundToInt().let { if (it > 0) "+$it" else "$it" },
                value = profile.contrast,
                range = 0f..1f,
                onChange = { v -> vm.update { it.copy(contrast = snap(v)) } }
            )

            VSpace(8.dp)
            ActionButton(
                text = stringResource(R.string.action_reset),
                onClick = {
                    vm.update {
                        it.copy(
                            cutoff = CUTOFF_DEFAULT,
                            flicker = 0f,
                            noise = 0f,
                            glow = 0f,
                            contrast = 0.5f
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

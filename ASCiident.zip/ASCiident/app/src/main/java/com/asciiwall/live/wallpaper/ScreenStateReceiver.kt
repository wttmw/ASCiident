package com.asciiwall.live.wallpaper

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.PowerManager
import androidx.core.content.ContextCompat

/**
 * Слушает состояние экрана и питания. Регистрируется динамически.
 * Блокировка: SCREEN_OFF. Разблокировка: USER_PRESENT, а если замка нет,
 * то SCREEN_ON без keyguard. Повторы одного и того же события отсекаются.
 */
class ScreenStateReceiver(private val listener: Listener) : BroadcastReceiver() {

    interface Listener {
        fun onScreenOff()
        fun onUserPresent()
        fun onPower(batteryLow: Boolean, powerSave: Boolean)
    }

    private var registered = false
    private var locked = false
    private var batteryLow = false
    private var charging = false

    fun register(context: Context) {
        if (registered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_BATTERY_LOW)
            addAction(Intent.ACTION_BATTERY_OKAY)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
        }
        ContextCompat.registerReceiver(context, this, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        registered = true

        val sticky = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (sticky != null) {
            val level = sticky.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = sticky.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = sticky.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            batteryLow = level >= 0 && scale > 0 && level * 100 / scale <= LOW_PERCENT
        }
        locked = isKeyguardLocked(context)
        notifyPower(context)
    }

    fun unregister(context: Context) {
        if (!registered) return
        registered = false
        try {
            context.unregisterReceiver(this)
        } catch (e: IllegalArgumentException) {
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_SCREEN_OFF -> {
                locked = true
                listener.onScreenOff()
            }
            Intent.ACTION_SCREEN_ON -> {
                if (locked && !isKeyguardLocked(context)) {
                    locked = false
                    listener.onUserPresent()
                }
            }
            Intent.ACTION_USER_PRESENT -> {
                if (locked) {
                    locked = false
                    listener.onUserPresent()
                }
            }
            Intent.ACTION_BATTERY_LOW -> {
                batteryLow = true
                notifyPower(context)
            }
            Intent.ACTION_BATTERY_OKAY -> {
                batteryLow = false
                notifyPower(context)
            }
            Intent.ACTION_POWER_CONNECTED -> {
                charging = true
                notifyPower(context)
            }
            Intent.ACTION_POWER_DISCONNECTED -> {
                charging = false
                notifyPower(context)
            }
            PowerManager.ACTION_POWER_SAVE_MODE_CHANGED -> notifyPower(context)
        }
    }

    private fun notifyPower(context: Context) {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        listener.onPower(batteryLow && !charging, pm.isPowerSaveMode)
    }

    private fun isKeyguardLocked(context: Context): Boolean {
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isKeyguardLocked
    }

    private companion object {
        const val LOW_PERCENT = 20
    }
}

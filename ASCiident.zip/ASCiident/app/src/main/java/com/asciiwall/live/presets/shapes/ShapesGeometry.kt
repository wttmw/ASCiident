package com.asciiwall.live.presets.shapes

import com.asciiwall.live.presets.Noise

/**
 * Геометрия фигур: вершины (x,y,z подряд) и рёбра (пары индексов).
 * Все фигуры вписаны в сферу радиуса ~1.
 */
object ShapesGeometry {

    private const val RING_SEG = 16
    private const val TWO_PI = 6.2831855f

    val verts: Array<FloatArray> = arrayOf(cubeV(), octaV(), ringV(), tetraV())
    val edges: Array<IntArray> = arrayOf(cubeE(), octaE(), ringE(), tetraE())

    fun vertexCount(kind: Int): Int = verts[kind].size / 3
    fun edgeCount(kind: Int): Int = edges[kind].size / 2

    private fun cubeV(): FloatArray {
        val h = 0.58f
        val out = FloatArray(24)
        for (i in 0 until 8) {
            out[i * 3] = if (i and 1 == 0) -h else h
            out[i * 3 + 1] = if (i and 2 == 0) -h else h
            out[i * 3 + 2] = if (i and 4 == 0) -h else h
        }
        return out
    }

    private fun cubeE(): IntArray {
        val out = IntArray(24)
        var n = 0
        for (i in 0 until 8) {
            for (bit in intArrayOf(1, 2, 4)) {
                val j = i xor bit
                if (j > i) { out[n++] = i; out[n++] = j }
            }
        }
        return out
    }

    private fun octaV(): FloatArray = floatArrayOf(
        1f, 0f, 0f, -1f, 0f, 0f,
        0f, 1f, 0f, 0f, -1f, 0f,
        0f, 0f, 1f, 0f, 0f, -1f
    )

    private fun octaE(): IntArray {
        val out = IntArray(24)
        var n = 0
        for (a in 0 until 6) for (b in a + 1 until 6) {
            if (a / 2 != b / 2) { out[n++] = a; out[n++] = b }
        }
        return out
    }

    private fun tetraV(): FloatArray {
        val k = 0.62f
        return floatArrayOf(
            k, k, k,
            k, -k, -k,
            -k, k, -k,
            -k, -k, k
        )
    }

    private fun tetraE(): IntArray = intArrayOf(0, 1, 0, 2, 0, 3, 1, 2, 1, 3, 2, 3)

    private fun ringV(): FloatArray {
        val out = FloatArray(RING_SEG * 2 * 3)
        for (i in 0 until RING_SEG) {
            val a = i * TWO_PI / RING_SEG
            val c = Noise.cos(a)
            val s = Noise.sin(a)
            out[i * 3] = c
            out[i * 3 + 1] = s
            out[i * 3 + 2] = 0f
            val o = (RING_SEG + i) * 3
            out[o] = c * 0.86f
            out[o + 1] = 0f
            out[o + 2] = s * 0.86f
        }
        return out
    }

    private fun ringE(): IntArray {
        val out = IntArray(RING_SEG * 2 * 2)
        var n = 0
        for (i in 0 until RING_SEG) {
            out[n++] = i
            out[n++] = (i + 1) % RING_SEG
        }
        for (i in 0 until RING_SEG) {
            out[n++] = RING_SEG + i
            out[n++] = RING_SEG + (i + 1) % RING_SEG
        }
        return out
    }
}

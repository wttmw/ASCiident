package com.asciiwall.live.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import java.io.IOException

private val Context.store: DataStore<Preferences> by preferencesDataStore(name = "asciiwall")

/**
 * Хранилище настроек: текущий профиль, список сохранённых профилей, настройки интерфейса.
 * Все записи атомарны (чтение и запись внутри одной транзакции edit{}).
 */
class SettingsRepository private constructor(context: Context) {

    private val ds = context.store

    private val data: Flow<Preferences> = ds.data.catch { e ->
        if (e is IOException) emit(emptyPreferences()) else throw e
    }

    val profile: Flow<Profile> = data.map { readProfile(it) }.distinctUntilChanged()

    val saved: Flow<List<Profile>> = data.map { readSaved(it) }.distinctUntilChanged()

    val ui: Flow<UiSettings> = data.map { readUi(it) }.distinctUntilChanged()

    suspend fun profileOnce(): Profile = profile.first()

    suspend fun uiOnce(): UiSettings = ui.first()

    // ---------------- Текущий профиль ----------------

    suspend fun updateProfile(block: (Profile) -> Profile) {
        ds.edit { p ->
            p[K_PROFILE] = block(readProfile(p)).sanitized().toJson()
        }
    }

    suspend fun setProfile(profile: Profile) {
        ds.edit { p -> p[K_PROFILE] = profile.sanitized().toJson() }
    }

    // ---------------- Сохранённые профили ----------------

    suspend fun saveCurrentAs(name: String): Boolean {
        var ok = true
        ds.edit { p ->
            val cur = readProfile(p).copy(name = cleanName(name)).sanitized()
            val list = readSaved(p)
            val exists = list.any { it.name.equals(cur.name, ignoreCase = true) }
            if (!exists && list.size >= MAX_SAVED) {
                ok = false
            } else {
                p[K_SAVED] = writeSaved(upsert(list, cur))
                p[K_PROFILE] = cur.toJson()
            }
        }
        return ok
    }

    suspend fun loadSaved(name: String): Boolean {
        var ok = false
        ds.edit { p ->
            val found = readSaved(p).firstOrNull { it.name.equals(name, ignoreCase = true) }
            if (found != null) {
                p[K_PROFILE] = found.toJson()
                ok = true
            }
        }
        return ok
    }

    suspend fun deleteSaved(name: String) {
        ds.edit { p ->
            p[K_SAVED] = writeSaved(readSaved(p).filterNot { it.name.equals(name, ignoreCase = true) })
        }
    }

    // ---------------- Экспорт и импорт ----------------

    suspend fun exportJson(name: String? = null): String {
        val p = data.first()
        val prof = if (name == null) readProfile(p)
        else readSaved(p).firstOrNull { it.name.equals(name, ignoreCase = true) } ?: readProfile(p)
        return prof.toJson()
    }

    /** Импорт: профиль добавляется в сохранённые. Возвращает имя или null при ошибке или лимите. */
    suspend fun importJson(text: String): String? {
        val imported = Profile.fromJson(text.trim()) ?: return null
        var result: String? = null
        ds.edit { p ->
            val list = readSaved(p)
            val exists = list.any { it.name.equals(imported.name, ignoreCase = true) }
            if (exists || list.size < MAX_SAVED) {
                p[K_SAVED] = writeSaved(upsert(list, imported))
                result = imported.name
            }
        }
        return result
    }

    // ---------------- Интерфейс ----------------

    suspend fun updateUi(block: (UiSettings) -> UiSettings) {
        ds.edit { p ->
            val n = block(readUi(p))
            p[K_THEME_MODE] = n.themeMode.name
            p[K_THEME_STYLE] = n.themeStyle.name
            p[K_ACCENT] = n.customAccent or 0xFF000000.toInt()
            p[K_PREVIEW_LIGHT] = n.previewLight
            p[K_LANGUAGE] = if (n.language in LANGUAGES) n.language else "system"
        }
    }

    // ---------------- Внутреннее ----------------

    private fun readProfile(p: Preferences): Profile =
        p[K_PROFILE]?.let { Profile.fromJson(it) } ?: Profile()

    private fun readSaved(p: Preferences): List<Profile> {
        val raw = p[K_SAVED] ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Profile>(arr.length())
            for (i in 0 until arr.length()) {
                Profile.fromJson(arr.getString(i))?.let { out.add(it) }
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeSaved(list: List<Profile>): String {
        val arr = JSONArray()
        for (pr in list) arr.put(pr.toJson())
        return arr.toString()
    }

    private fun upsert(list: List<Profile>, item: Profile): List<Profile> {
        val i = list.indexOfFirst { it.name.equals(item.name, ignoreCase = true) }
        return if (i < 0) list + item else list.toMutableList().also { it[i] = item }
    }

    private fun readUi(p: Preferences): UiSettings {
        val d = UiSettings()
        return UiSettings(
            themeMode = ThemeMode.parse(p[K_THEME_MODE]),
            themeStyle = ThemeStyle.parse(p[K_THEME_STYLE]),
            customAccent = p[K_ACCENT] ?: d.customAccent,
            previewLight = p[K_PREVIEW_LIGHT] ?: d.previewLight,
            language = p[K_LANGUAGE]?.takeIf { it in LANGUAGES } ?: d.language
        )
    }

    private fun cleanName(s: String): String =
        s.trim().take(Profile.MAX_NAME).ifEmpty { "Profile" }

    companion object {
        const val MAX_SAVED = 30
        private val LANGUAGES = setOf("system", "en", "uk")

        private val K_PROFILE = stringPreferencesKey("profile")
        private val K_SAVED = stringPreferencesKey("saved_profiles")
        private val K_THEME_MODE = stringPreferencesKey("theme_mode")
        private val K_THEME_STYLE = stringPreferencesKey("theme_style")
        private val K_ACCENT = intPreferencesKey("custom_accent")
        private val K_PREVIEW_LIGHT = booleanPreferencesKey("preview_light")
        private val K_LANGUAGE = stringPreferencesKey("language")

        @Volatile private var instance: SettingsRepository? = null

        fun get(context: Context): SettingsRepository =
            instance ?: synchronized(this) {
                instance ?: SettingsRepository(context.applicationContext).also { instance = it }
            }
    }
}

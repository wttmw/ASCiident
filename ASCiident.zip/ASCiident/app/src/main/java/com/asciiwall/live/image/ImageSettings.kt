package com.asciiwall.live.image

import org.json.JSONObject

/** Дизеринг: как скрывать ступени тона при малом числе символов. */
enum class Dither {
    NONE,
    BAYER,
    FLOYD;

    companion object {
        fun parse(s: String?) = entries.firstOrNull { it.name == s } ?: NONE
    }
}

/** Как картинка вписывается в сетку. */
enum class ImageFit {
    COVER,
    CONTAIN;

    companion object {
        fun parse(s: String?) = entries.firstOrNull { it.name == s } ?: COVER
    }
}

/** Параметры конвертера картинки в ASCII. Входят в профиль. */
data class ImageSettings(
    val uri: String = "",
    val fit: ImageFit = ImageFit.COVER,
    val threshold: Float = 0.08f,
    val contrast: Float = 0.5f,
    val gamma: Float = 1f,
    val invert: Boolean = false,
    val density: Float = 1f,
    val dither: Dither = Dither.NONE,
    val sharpen: Float = 0.25f
) {

    val isSet: Boolean get() = uri.isNotEmpty()

    fun sanitized() = copy(
        uri = uri.take(MAX_URI),
        threshold = threshold.coerceIn(0f, 0.9f),
        contrast = contrast.coerceIn(0f, 1f),
        gamma = gamma.coerceIn(GAMMA_MIN, GAMMA_MAX),
        density = density.coerceIn(DENSITY_MIN, DENSITY_MAX),
        sharpen = sharpen.coerceIn(0f, 1f)
    )

    /** Ключ кэша результата: меняется при любой правке, влияющей на тона. */
    fun toneKey(): Int {
        var h = fit.ordinal
        h = h * 31 + (threshold * 1000f).toInt()
        h = h * 31 + (contrast * 1000f).toInt()
        h = h * 31 + (gamma * 1000f).toInt()
        h = h * 31 + (if (invert) 1 else 0)
        h = h * 31 + (density * 1000f).toInt()
        h = h * 31 + dither.ordinal
        h = h * 31 + (sharpen * 1000f).toInt()
        return h
    }

    fun toJson(): JSONObject = JSONObject()
        .put("uri", uri)
        .put("fit", fit.name)
        .put("threshold", threshold.toDouble())
        .put("contrast", contrast.toDouble())
        .put("gamma", gamma.toDouble())
        .put("invert", invert)
        .put("density", density.toDouble())
        .put("dither", dither.name)
        .put("sharpen", sharpen.toDouble())

    companion object {
        const val MAX_URI = 512
        const val GAMMA_MIN = 0.4f
        const val GAMMA_MAX = 2.5f
        const val DENSITY_MIN = 0.5f
        const val DENSITY_MAX = 1.5f

        fun fromJson(o: JSONObject?): ImageSettings {
            if (o == null) return ImageSettings()
            val d = ImageSettings()
            return ImageSettings(
                uri = o.optString("uri", d.uri),
                fit = ImageFit.parse(o.optString("fit")),
                threshold = o.optDouble("threshold", d.threshold.toDouble()).toFloat(),
                contrast = o.optDouble("contrast", d.contrast.toDouble()).toFloat(),
                gamma = o.optDouble("gamma", d.gamma.toDouble()).toFloat(),
                invert = o.optBoolean("invert", d.invert),
                density = o.optDouble("density", d.density.toDouble()).toFloat(),
                dither = Dither.parse(o.optString("dither")),
                sharpen = o.optDouble("sharpen", d.sharpen.toDouble()).toFloat()
            ).sanitized()
        }
    }
}

package com.asciiwall.live.ui.sections

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.asciiwall.live.R
import com.asciiwall.live.settings.CharSets
import com.asciiwall.live.settings.Profile
import com.asciiwall.live.ui.MainViewModel
import com.asciiwall.live.ui.components.AppTextField
import com.asciiwall.live.ui.components.ChipGroup
import com.asciiwall.live.ui.components.GroupLabel
import com.asciiwall.live.ui.components.Option
import com.asciiwall.live.ui.components.SectionCard
import com.asciiwall.live.ui.components.VSpace
import com.asciiwall.live.ui.theme.App
import com.asciiwall.live.ui.theme.AppType

@Composable
fun CharsSection(profile: Profile, vm: MainViewModel) {
    val c = App.colors
    val custom = profile.charSetId == CharSets.CUSTOM_ID
    val options = CharSets.presets.map { Option(it.id, it.label) } +
        Option(CharSets.CUSTOM_ID, stringResource(R.string.chars_custom_chip))

    SectionCard(
        tag = stringResource(R.string.section_chars),
        title = stringResource(R.string.section_chars_title)
    ) {
        Column {
            GroupLabel(stringResource(R.string.chars_preset))
            ChipGroup(
                options = options,
                selected = profile.charSetId,
                onSelect = { id -> vm.update { it.copy(charSetId = id) } }
            )

            VSpace(16.dp)
            if (custom) {
                GroupLabel(stringResource(R.string.chars_custom))
                AppTextField(
                    value = profile.customChars,
                    onValueChange = { s -> vm.update { it.copy(customChars = s.take(600)) } },
                    hint = stringResource(R.string.chars_custom_hint),
                    singleLine = false
                )
                VSpace(8.dp)
                Text(
                    stringResource(R.string.chars_count, CharSets.count(profile.customChars)),
                    style = AppType.label,
                    color = c.textMuted
                )
                VSpace(12.dp)
            }

            Text(
                CharSets.resolve(profile.charSetId, profile.customChars).trim(),
                style = AppType.value,
                color = c.accent,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )
        }
    }
}

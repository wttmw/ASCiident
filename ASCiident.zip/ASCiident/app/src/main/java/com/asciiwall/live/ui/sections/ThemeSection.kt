package com.asciiwall.live.ui.sections

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.asciiwall.live.R
import com.asciiwall.live.settings.ColorUtils
import com.asciiwall.live.settings.ThemeMode
import com.asciiwall.live.settings.ThemeStyle
import com.asciiwall.live.settings.UiSettings
import com.asciiwall.live.ui.LocaleHelper
import com.asciiwall.live.ui.MainViewModel
import com.asciiwall.live.ui.components.AppSlider
import com.asciiwall.live.ui.components.ChipGroup
import com.asciiwall.live.ui.components.GroupLabel
import com.asciiwall.live.ui.components.Option
import com.asciiwall.live.ui.components.SectionCard
import com.asciiwall.live.ui.components.SwitchRow
import com.asciiwall.live.ui.components.VSpace
import com.asciiwall.live.ui.theme.App
import com.asciiwall.live.ui.theme.AppShapes
import kotlin.math.roundToInt

@Composable
fun ThemeSection(ui: UiSettings, vm: MainViewModel) {
    val c = App.colors

    val modes = listOf(
        Option(ThemeMode.SYSTEM, stringResource(R.string.theme_mode_system)),
        Option(ThemeMode.DARK, stringResource(R.string.theme_mode_dark)),
        Option(ThemeMode.LIGHT, stringResource(R.string.theme_mode_light))
    )
    // Material You есть только на Android 12+.
    val styles = buildList {
        add(Option(ThemeStyle.TERMINAL, stringResource(R.string.theme_style_terminal)))
        if (ColorUtils.systemPaletteAvailable()) {
            add(Option(ThemeStyle.MATERIAL, stringResource(R.string.theme_style_material)))
        }
        add(Option(ThemeStyle.CUSTOM, stringResource(R.string.theme_style_custom)))
    }
    val langs = listOf(
        Option("system", stringResource(R.string.language_system)),
        Option("en", stringResource(R.string.language_en)),
        Option("uk", stringResource(R.string.language_uk))
    )

    SectionCard(
        tag = stringResource(R.string.section_theme),
        title = stringResource(R.string.section_theme_title)
    ) {
        Column {
            GroupLabel(stringResource(R.string.theme_mode))
            ChipGroup(modes, ui.themeMode, { m ->
                vm.updateUi { it.copy(themeMode = m) }
                LocaleHelper.applyNightMode(m)
            })

            VSpace(16.dp)
            GroupLabel(stringResource(R.string.theme_style))
            ChipGroup(styles, ui.themeStyle, { s -> vm.updateUi { it.copy(themeStyle = s) } })

            if (ui.themeStyle == ThemeStyle.CUSTOM) {
                VSpace(16.dp)
                GroupLabel(stringResource(R.string.theme_accent))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(16.dp)
                        .clip(AppShapes.chip)
                        .background(Color(ui.customAccent))
                        .border(1.dp, c.border, AppShapes.chip)
                )
                val acc = ui.customAccent
                AppSlider(
                    label = stringResource(R.string.color_red),
                    valueText = ColorUtils.red(acc).toString(),
                    value = ColorUtils.red(acc).toFloat(),
                    range = 0f..255f,
                    onChange = { v -> vm.updateUi { it.copy(customAccent = ColorUtils.withChannel(acc, 0, v.roundToInt())) } }
                )
                AppSlider(
                    label = stringResource(R.string.color_green),
                    valueText = ColorUtils.green(acc).toString(),
                    value = ColorUtils.green(acc).toFloat(),
                    range = 0f..255f,
                    onChange = { v -> vm.updateUi { it.copy(customAccent = ColorUtils.withChannel(acc, 1, v.roundToInt())) } }
                )
                AppSlider(
                    label = stringResource(R.string.color_blue),
                    valueText = ColorUtils.blue(acc).toString(),
                    value = ColorUtils.blue(acc).toFloat(),
                    range = 0f..255f,
                    onChange = { v -> vm.updateUi { it.copy(customAccent = ColorUtils.withChannel(acc, 2, v.roundToInt())) } }
                )
            }

            VSpace(8.dp)
            SwitchRow(
                label = stringResource(R.string.theme_preview_light),
                checked = ui.previewLight,
                onChange = { on -> vm.updateUi { it.copy(previewLight = on) } }
            )

            VSpace(16.dp)
            GroupLabel(stringResource(R.string.language))
            ChipGroup(langs, ui.language, { l ->
                vm.updateUi { it.copy(language = l) }
                LocaleHelper.apply(l)
            })
        }
    }
}

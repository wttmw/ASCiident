package com.asciiwall.live.presets.shapes

import com.asciiwall.live.core.CellBuffer
import com.asciiwall.live.presets.Noise

/**
 * 3D-математика для ASCII-сцен. Без аллокаций: матрица 3x3 лежит в FloatArray(9).
 */
object Math3D {

    /** Пропорции символа: ячейка выше, чем шире. */
    const val ASPECT = 1.9f

    fun setRotation(m: FloatArray, ax: Float, ay: Float, az: Float) {
        val sx = Noise.sin(ax); val cx = Noise.cos(ax)
        val sy = Noise.sin(ay); val cy = Noise.cos(ay)
        val sz = Noise.sin(az); val cz = Noise.cos(az)
        m[0] = cz * cy;  m[1] = cz * sy * sx - sz * cx;  m[2] = cz * sy * cx + sz * sx
        m[3] = sz * cy;  m[4] = sz * sy * sx + cz * cx;  m[5] = sz * sy * cx - cz * sx
        m[6] = -sy;      m[7] = cy * sx;                 m[8] = cy * cx
    }

    fun rotate(m: FloatArray, x: Float, y: Float, z: Float, out: FloatArray) {
        out[0] = m[0] * x + m[1] * y + m[2] * z
        out[1] = m[3] * x + m[4] * y + m[5] * z
        out[2] = m[6] * x + m[7] * y + m[8] * z
    }

    /** Мягкое затухание по глубине: near -> 1, far -> 0. */
    fun depthFade(z: Float, near: Float, far: Float): Float {
        val t = ((z - near) / (far - near)).coerceIn(0f, 1f)
        return 1f - t * t * (3f - 2f * t)
    }
}

/** Перспективная проекция в координаты сетки (ячейки). Камера смотрит вдоль +Z. */
class Projector {
    var cx = 0f
    var cy = 0f
    var scale = 20f
    var camDist = 6f

    fun setup(cols: Int, rows: Int, worldHeight: Float) {
        cx = cols * 0.5f
        cy = rows * 0.5f
        scale = rows * Math3D.ASPECT / worldHeight
    }

    fun project(x: Float, y: Float, z: Float, out: FloatArray): Boolean {
        val d = camDist + z
        if (d < 0.3f) return false
        val w = camDist / d
        out[0] = cx + x * scale * w
        out[1] = cy + y * scale * w / Math3D.ASPECT
        out[2] = z
        return true
    }
}

/** Растеризация в CellBuffer. */
object Raster {

    fun line(
        buf: CellBuffer,
        x0: Float, y0: Float, v0: Float,
        x1: Float, y1: Float, v1: Float,
        tint: Float
    ) {
        val dx = x1 - x0
        val dy = y1 - y0
        val len = maxOf(Math.abs(dx), Math.abs(dy))
        val steps = (len * 1.4f).toInt().coerceIn(1, 400)
        val inv = 1f / steps
        for (i in 0..steps) {
            val t = i * inv
            buf.max(
                Math.round(x0 + dx * t),
                Math.round(y0 + dy * t),
                v0 + (v1 - v0) * t,
                tint
            )
        }
    }

    fun dot(buf: CellBuffer, x: Float, y: Float, v: Float, tint: Float) {
        val xi = Math.round(x)
        val yi = Math.round(y)
        buf.max(xi, yi, v, tint)
        val h = v * 0.4f
        if (h > 0.05f) {
            buf.max(xi - 1, yi, h, tint)
            buf.max(xi + 1, yi, h, tint)
        }
    }
}

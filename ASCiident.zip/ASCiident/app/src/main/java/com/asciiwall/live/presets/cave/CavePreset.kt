package com.asciiwall.live.presets.cave

import com.asciiwall.live.R
import com.asciiwall.live.core.CellBuffer
import com.asciiwall.live.presets.Noise
import com.asciiwall.live.presets.Preset
import com.asciiwall.live.presets.TouchAction
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Магическая пещера: 3 слоя сталактитов, берега с кристаллами, тихая вода с отражением,
 * споры, падающие капли. Кристаллы пульсируют и красят сцену через tint.
 */
class CavePreset : Preset() {

    override val id = "cave"
    override val nameRes = R.string.preset_cave
    override val descRes = R.string.preset_cave_desc

    private var pad = 0
    private var len = 0
    private var waterRow = 0
    private val roof = arrayOf(FloatArray(0), FloatArray(0), FloatArray(0))
    private var bank = FloatArray(0)

    // ---- Кристаллы ----
    private var nC = 0
    private var cX = FloatArray(0)
    private var cBase = FloatArray(0)
    private var cH = FloatArray(0)
    private var cW = FloatArray(0)
    private var cLean = FloatArray(0)
    private var cPh = FloatArray(0)
    private var cTint = FloatArray(0)
    private var cL = ByteArray(0)
    private var cE = FloatArray(0)
    private var gM = FloatArray(0)
    private var gT = FloatArray(0)
    private var woke = BooleanArray(0)
    private var dly = FloatArray(0)

    // ---- Споры ----
    private var spCount = 0
    private var spX = FloatArray(0)
    private var spY = FloatArray(0)
    private var spPh = FloatArray(0)
    private var spL = ByteArray(0)

    // ---- Капли ----
    private val dActive = BooleanArray(DRIPS)
    private val dIdx = IntArray(DRIPS)
    private val dY = FloatArray(DRIPS)
    private val dV = FloatArray(DRIPS)
    private val dTimer = FloatArray(DRIPS)
    private var dCount = 0

    // ---- Круги на воде ----
    private val rX = FloatArray(RIPPLES)
    private val rAge = FloatArray(RIPPLES)
    private val rLife = FloatArray(RIPPLES)
    private val rAmp = FloatArray(RIPPLES)
    private var rNext = 0

    // ---- Состояние ----
    private var lastTime = 0f
    private var flash = 0f
    private var dark = 0f
    private var darkTarget = 0f
    private var calm = 0f
    private var calmTarget = 0f
    private var agit = 0f
    private var sBoost = 0f
    private var scrollOffset = 0f
    private var scrollVel = 0f
    private var shift = 0f
    private var touching = false
    private var touchX = 0f
    private var touchY = 0f
    private var waveActive = false
    private var waveX = 0f
    private var lockActive = false
    private var lockT = 0f

    private var lvl = FloatArray(0)
    private var tnt = FloatArray(0)

    override fun onSizeChanged(cols: Int, rows: Int) {
        super.onSizeChanged(cols, rows)
        val c = cols.toFloat()
        val r = rows.toFloat()
        pad = (cols * 0.22f).toInt() + 2
        len = cols + 2 * pad
        waterRow = (rows * WATER).toInt().coerceIn(4, rows - 2)

        for (l in 0 until 3) {
            val a = FloatArray(len)
            val period = max(4f, PERIOD[l] * c / 80f)
            for (i in 0 until len) {
                val u = i / period + l * 0.37f
                val cell = floor(u)
                val local = u - cell
                val tri = 1f - Math.abs(local * 2f - 1f)
                var lr = 0.35f + 0.65f * Noise.hash(cell.toInt() * 13 + l * 101)
                if (Noise.hash(cell.toInt() * 7 + l * 53) < 0.3f) lr *= 0.2f
                val n = Noise.noise2(i * 0.06f + l * 10f, l * 3.1f)
                val spike = tri * Math.sqrt(tri.toDouble()).toFloat()
                a[i] = r * (BASEL[l] * (0.6f + 0.8f * n) + LMAX[l] * lr * spike)
            }
            roof[l] = a
        }

        bank = FloatArray(len)
        for (i in 0 until len) {
            val u = (i - pad) / c * 2f - 1f
            val env = 0.15f + 0.85f * u * u
            val n = Noise.fbm2(i * 0.045f + 40f, 5.5f)
            val mound = Noise.smooth(0.35f, 0.85f, n)
            bank[i] = r * 0.14f * (0.1f + 0.9f * env) * (0.3f + 0.7f * mound)
        }

        val clusters = (cols / 22).coerceIn(3, 6)
        nC = clusters * 3
        cX = FloatArray(nC); cBase = FloatArray(nC); cH = FloatArray(nC); cW = FloatArray(nC)
        cLean = FloatArray(nC); cPh = FloatArray(nC); cTint = FloatArray(nC)
        cL = ByteArray(nC); cE = FloatArray(nC)
        gM = FloatArray(nC); gT = FloatArray(nC); woke = BooleanArray(nC); dly = FloatArray(nC)
        for (g in 0 until clusters) {
            val gx = pad + (g + 0.2f + 0.6f * Noise.hash(g * 5 + 1)) / clusters * c
            val ct = 0.2f + 0.8f * Noise.hash(g * 5 + 2)
            for (k in 0 until 3) {
                val i = g * 3 + k
                val s = i * 29 + 5
                val x = gx + (k - 1) * (2f + 1.5f * Noise.hash(s))
                val hh = r * (0.10f + 0.16f * Noise.hash(s + 1)) * (if (k == 1) 1f else 0.65f)
                cX[i] = x
                cH[i] = hh
                cW[i] = 1.1f + hh / r * 5f
                cLean[i] = (k - 1) * 0.12f + (Noise.hash(s + 2) - 0.5f) * 0.1f
                cPh[i] = Noise.hash(s + 3) * 6.2832f
                cTint[i] = (ct + k * 0.06f).coerceIn(0f, 1f)
                cL[i] = (if (k == 1) 1 else 0).toByte()
                val bi = x.toInt().coerceIn(0, len - 1)
                cBase[i] = waterRow - bank[bi] + 1f
                gM[i] = 1f; gT[i] = 1f; woke[i] = true
                dly[i] = 0.2f + 1.6f * Noise.hash(s + 4)
            }
        }

        spCount = (cols * rows / 55).coerceIn(30, 120)
        spX = FloatArray(spCount); spY = FloatArray(spCount)
        spPh = FloatArray(spCount); spL = ByteArray(spCount)
        for (i in 0 until spCount) {
            spX[i] = Noise.hash(i * 3 + 1) * c
            spY[i] = Noise.hash(i * 3 + 2) * waterRow
            spPh[i] = Noise.hash(i * 3 + 3) * 6.2832f
            val q = Noise.hash(i * 7 + 5)
            spL[i] = (if (q < 0.4f) 0 else if (q < 0.75f) 1 else 2).toByte()
        }

        for (i in 0 until DRIPS) {
            dActive[i] = false
            dTimer[i] = 0.8f + i * 1.1f + 2f * Noise.hash(i + 70)
        }
        java.util.Arrays.fill(rAmp, 0f)
        flash = 0f; dark = 0f; darkTarget = 0f; calm = 0f; calmTarget = 0f
        agit = 0f; sBoost = 0f
        waveActive = false; lockActive = false; touching = false
    }

    private fun crystalSx(i: Int): Float = cX[i] - pad + shift * cols * PAR_B

    private fun addRipple(x: Float, amp: Float, life: Float) {
        val i = rNext
        rNext = (rNext + 1) % RIPPLES
        rX[i] = x; rAge[i] = 0f; rLife[i] = life; rAmp[i] = amp
    }

    override fun update(dt: Float, time: Float) {
        if (cols == 0) return
        lastTime = time
        val bgDt = bg(dt)
        val evDt = ev(dt)
        val pxDt = px(dt)
        val c = cols.toFloat()

        val darkRate = if (darkTarget > dark) 1.1f else 3.2f
        dark += (darkTarget - dark) * min(1f, darkRate * evDt)
        calm += (calmTarget - calm) * min(1f, 1.4f * evDt)
        if (flash > 0.001f) flash *= 1f - min(1f, 1.6f * evDt) else flash = 0f
        agit *= 1f - min(1f, 1.5f * evDt)
        sBoost *= 1f - min(1f, 0.9f * evDt)

        scrollVel *= 1f - min(1f, 3f * pxDt)
        val shiftTarget = -(scrollOffset - 0.5f) * 0.8f
        shift += (shiftTarget - shift) * min(1f, 5f * pxDt)
        val drift = (-scrollVel * 3f).coerceIn(-3f, 3f)

        // ---- Кристаллы ----
        val dec = 1f - min(1f, 1.4f * evDt)
        val ap = min(1f, 3f * evDt)
        for (i in 0 until nC) {
            cE[i] *= dec
            gM[i] += (gT[i] - gM[i]) * ap
        }
        if (lockActive) {
            lockT += evDt
            for (i in 0 until nC) if (lockT > dly[i]) gT[i] = 0f
        }
        if (waveActive) {
            waveX += 75f * evDt
            for (i in 0 until nC) {
                if (!woke[i] && crystalSx(i) <= waveX) {
                    woke[i] = true
                    gT[i] = 1f
                    cE[i] = 1.1f
                }
            }
            if (waveX > c + 20f) waveActive = false
        }
        if (touching) {
            for (i in 0 until nC) {
                val my = cBase[i] - cH[i] * 0.5f
                val d = Noise.dist(crystalSx(i) - touchX, my - touchY)
                if (d < 18f) {
                    val k = 1f - d / 18f
                    if (k > cE[i]) cE[i] = k
                }
            }
        }

        // ---- Споры ----
        val up = (1f - 0.6f * calm) * (1f + sBoost)
        for (i in 0 until spCount) {
            val l = spL[i].toInt()
            spY[i] -= (0.6f + 0.5f * l) * up * bgDt
            spX[i] += (Noise.sin(time * 0.4f + spPh[i]) * 0.9f + drift * (0.4f + 0.3f * l)) * bgDt
            if (touching) {
                val dx = touchX - spX[i]
                val dy = touchY - spY[i]
                if (Noise.dist(dx, dy) < 14f) {
                    spX[i] += dx * 0.8f * evDt
                    spY[i] += dy * 0.8f * evDt
                }
            }
            if (spX[i] >= c) spX[i] -= c else if (spX[i] < 0f) spX[i] += c
            if (spY[i] < 1f) {
                spY[i] = waterRow - 1f
                spX[i] = Noise.hash(i * 7 + (time * 3f).toInt()) * c
            }
        }

        // ---- Капли со сталактитов ----
        val near = roof[2]
        val sc2 = (shift * c * PAR_R[2]).toInt()
        for (i in 0 until DRIPS) {
            if (!dActive[i]) {
                dTimer[i] -= bgDt
                if (dTimer[i] <= 0f) {
                    val xs = (Noise.hash(i * 17 + dCount * 31) * c).toInt()
                    var best = (xs + pad + sc2).coerceIn(3, len - 4)
                    for (k in -3..3) {
                        val j = (best + k).coerceIn(0, len - 1)
                        if (near[j] > near[best]) best = j
                    }
                    dCount++
                    dIdx[i] = best
                    dY[i] = near[best]
                    dV[i] = 0f
                    dActive[i] = true
                }
            } else {
                dV[i] += 28f * bgDt
                dY[i] += dV[i] * bgDt
                if (dY[i] >= waterRow) {
                    dActive[i] = false
                    dTimer[i] = 1.2f + 3f * Noise.hash(i * 11 + dCount * 5)
                    addRipple((dIdx[i] - pad - sc2).toFloat(), 0.55f, 1.8f)
                    agit = min(2f, agit + 0.4f)
                }
            }
        }

        // ---- Круги ----
        for (i in 0 until RIPPLES) {
            if (rAmp[i] > 0f) {
                rAge[i] += evDt
                if (rAge[i] >= rLife[i]) rAmp[i] = 0f
            }
        }
    }

    override fun draw(buffer: CellBuffer) {
        if (cols == 0) return
        buffer.clear()
        lvl = buffer.level
        tnt = buffer.tint
        val lm = (1f + flash * 0.5f) * (1f - dark * 0.85f)
        val lmC = 1f + flash * 0.5f

        drawRoof(0, lm)
        drawRoof(1, lm)
        drawBank(lm)
        for (i in 0 until nC) drawCrystal(buffer, i, lmC)
        drawRoof(2, lm)
        drawWater(buffer, lm)
        drawSpores(buffer, lm)
        drawDrips(buffer)
        drawRipples(buffer, lm)

        if (touching) {
            val tx = touchX.toInt()
            val ty = touchY.toInt()
            for (dy in -1..1) for (dx in -3..3) {
                val d = Noise.dist(dx / 1.9f, dy.toFloat(), 1f)
                val v = 0.5f * (1f - d / 2.2f)
                if (v > 0f) buffer.max(tx + dx, ty + dy, v, 0.9f)
            }
        }

        if (params.flicker > 0f || params.noise > 0f) {
            val step = (lastTime * 8f).toInt() * 131
            for (y in 0 until rows) {
                for (x in 0 until cols) {
                    val i = y * cols + x
                    val v = lvl[i]
                    if (v <= 0f) continue
                    lvl[i] = fx(v, Noise.hash2(x + step, y))
                }
            }
        }
    }

    // ---------------- Скала ----------------

    private fun drawRoof(l: Int, lm: Float) {
        val arr = roof[l]
        val sc = (shift * cols * PAR_R[l]).toInt()
        val br = BRC[l] * lm
        val tn = TINT_R[l]
        for (x in 0 until cols) {
            val idx = (x + pad + sc).coerceIn(1, len - 2)
            val ln = arr[idx]
            val yEnd = min(rows - 1, ceil(ln).toInt() - 1)
            for (y in 0..yEnd) {
                val edge = y + 1 > arr[idx - 1] || y + 1 > arr[idx + 1]
                val tip = ln - y < 1.5f
                val v = if (tip) 1f else if (edge) 0.65f else 0.12f + 0.12f * Noise.hash2(idx + l * 500, y)
                val i = y * cols + x
                lvl[i] = v * br
                tnt[i] = tn
            }
        }
    }

    private fun drawBank(lm: Float) {
        val sc = (shift * cols * PAR_B).toInt()
        for (x in 0 until cols) {
            val idx = (x + pad + sc).coerceIn(0, len - 1)
            val ys = max(0, (waterRow - bank[idx]).toInt())
            for (y in ys until waterRow) {
                val v = if (y == ys) 0.75f else 0.14f + 0.14f * Noise.hash2(idx + 900, y)
                val i = y * cols + x
                lvl[i] = v * lm
                tnt[i] = 0.25f
            }
        }
    }

    // ---------------- Кристаллы ----------------

    private fun drawCrystal(buf: CellBuffer, i: Int, lmC: Float) {
        val sx = crystalSx(i)
        if (sx < -10f || sx > cols + 10f) return
        val h = cH[i]
        val w = cW[i]
        val by = cBase[i]
        val top = by - h
        val cl = cL[i].toInt()
        val g = 0.6f + 0.4f * Noise.sin(lastTime * 0.9f + cPh[i])
        val glow = min(1.3f, gM[i] * g + cE[i] * 0.7f)
        val br = BRC_C[cl] * lmC
        val rim = min(1f, br * (0.3f + 0.7f * glow))
        val t0 = cTint[i]
        val lean = cLean[i]

        val y0 = max(0, ceil(top).toInt())
        val y1 = min(rows - 1, by.toInt())
        for (y in y0..y1) {
            val p = (y - top) / h
            val half = if (p < 0.25f) max(0.3f, w * p * 4f) else w
            val cen = sx + lean * h * (1f - p)
            val xl = Math.round(cen - half)
            val xr = Math.round(cen + half)
            for (x in xl..xr) {
                if (x < 0 || x >= cols) continue
                val edge = x == xl || x == xr || y - y0 < 1
                val s = (x - cen) / (half + 0.5f)
                val v = if (edge) rim else min(1f, br * glow * (0.20f + 0.22f * (s + 1f)))
                val idx = y * cols + x
                lvl[idx] = v
                tnt[idx] = t0 + 0.12f * p
            }
        }

        if (glow > 0.05f) {
            val hx = Math.round(sx + lean * h * 0.4f)
            val hy = Math.round(top + h * 0.45f)
            for (dy in -3..3) for (dx in -7..7) {
                val a = dx / 7f
                val b = dy / 3f
                val d = Math.sqrt((a * a + b * b).toDouble()).toFloat()
                if (d < 1f) buf.max(hx + dx, hy + dy, 0.2f * (1f - d) * glow * lmC, t0)
            }
        }
    }

    // ---------------- Вода ----------------

    private fun drawWater(buf: CellBuffer, lm: Float) {
        val t = lastTime
        val amp = 0.7f + agit * 1.6f
        val depth = (rows - waterRow).coerceAtLeast(1).toFloat()

        for (x in 0 until cols) {
            val n = Noise.noise2(x * 0.2f - t * 0.5f, t * 0.3f)
            if (n > 0.55f) buf.max(x, waterRow, (0.1f + 0.5f * Noise.smooth(0.55f, 0.8f, n)) * lm, 0.9f)
        }

        for (y in waterRow + 1 until rows) {
            val k = y - waterRow
            val ys = waterRow - (k * 1.8f).toInt()
            if (ys < 0) break
            val fade = 0.55f * (1f - 0.7f * k / depth)
            for (x in 0 until cols) {
                val sx = x + (Noise.sin(y * 1.3f + t * 1.6f + x * 0.15f) * amp).toInt()
                if (sx < 0 || sx >= cols) continue
                val si = ys * cols + sx
                val v = lvl[si] * fade
                if (v > 0.05f) {
                    val idx = y * cols + x
                    if (v > lvl[idx]) {
                        lvl[idx] = v
                        tnt[idx] = tnt[si]
                    }
                }
            }
        }
    }

    private fun drawRipples(buf: CellBuffer, lm: Float) {
        val cy = waterRow + (rows - waterRow) * 0.45f
        for (i in 0 until RIPPLES) {
            val a = rAmp[i]
            if (a <= 0f) continue
            val rad = rAge[i] * 11f
            if (rad < 0.8f) continue
            val fade = a * (1f - rAge[i] / rLife[i]) * lm
            ring(buf, rX[i], cy, rad, fade * 0.8f)
            ring(buf, rX[i], cy, rad * 0.7f, fade * 0.4f)
        }
    }

    private fun ring(buf: CellBuffer, cx: Float, cy: Float, rad: Float, v: Float) {
        if (v <= 0.02f) return
        val ry = rad * 0.16f
        val steps = (rad * 4f).toInt().coerceIn(10, 120)
        val k = 6.2832f / steps
        for (n in 0 until steps) {
            val ang = n * k
            val y = Math.round(cy + Noise.sin(ang) * ry)
            if (y <= waterRow) continue
            buf.max(Math.round(cx + Noise.cos(ang) * rad), y, v, 0.92f)
        }
    }

    // ---------------- Споры и капли ----------------

    private fun drawSpores(buf: CellBuffer, lm: Float) {
        val c = cols.toFloat()
        for (i in 0 until spCount) {
            val l = spL[i].toInt()
            var x = (spX[i] + shift * c * PAR_S[l]) % c
            if (x < 0f) x += c
            val tw = 0.5f + 0.5f * Noise.sin(lastTime * 1.5f + spPh[i])
            buf.max(x.toInt(), spY[i].toInt(), BRS[l] * (0.4f + 0.6f * tw) * lm, 0.7f)
        }
    }

    private fun drawDrips(buf: CellBuffer) {
        val sc2 = (shift * cols * PAR_R[2]).toInt()
        for (i in 0 until DRIPS) {
            if (!dActive[i]) continue
            val x = dIdx[i] - pad - sc2
            val y = dY[i].toInt()
            buf.max(x, y, 1f, 1f)
            buf.max(x, y - 1, 0.5f, 0.95f)
        }
    }

    // ---------------- События ----------------

    override fun onTouch(nx: Float, ny: Float, action: Int) {
        if (cols == 0) return
        touchX = nx.coerceIn(0f, 1f) * cols
        touchY = ny.coerceIn(0f, 1f) * rows
        when (action) {
            TouchAction.DOWN -> {
                touching = true
                addRipple(touchX, 0.8f, 1.8f)
                sBoost = min(3f, sBoost + 0.8f)
                agit = min(2f, agit + 0.5f)
            }
            TouchAction.UP -> {
                touching = false
                addRipple(touchX, 0.4f, 1.2f)
            }
        }
    }

    override fun onUnlock() {
        if (cols == 0) return
        darkTarget = 0f
        calmTarget = 0f
        flash = 0.5f
        lockActive = false
        waveActive = true
        waveX = -6f
        for (i in 0 until nC) woke[i] = false
        sBoost = 3f
        agit = 1.5f
        addRipple(cols * 0.5f, 1f, 3.2f)
        addRipple(cols * 0.5f, 0.6f, 4f)
    }

    override fun onLock() {
        darkTarget = 0.5f
        calmTarget = 1f
        lockActive = true
        lockT = 0f
        waveActive = false
        touching = false
    }

    override fun onScroll(offset: Float, velocity: Float) {
        scrollOffset = offset
        scrollVel = velocity
    }

    override fun onVisibility(visible: Boolean) {
        if (visible) touching = false
    }

    companion object {
        private const val WATER = 0.80f
        private const val DRIPS = 3
        private const val RIPPLES = 8
        private const val PAR_B = 0.16f

        private val PERIOD = floatArrayOf(7f, 9f, 13f)
        private val LMAX = floatArrayOf(0.22f, 0.30f, 0.42f)
        private val BASEL = floatArrayOf(0.05f, 0.07f, 0.09f)
        private val BRC = floatArrayOf(0.30f, 0.50f, 0.80f)
        private val TINT_R = floatArrayOf(0.08f, 0.16f, 0.26f)
        private val PAR_R = floatArrayOf(0.03f, 0.09f, 0.20f)

        private val BRC_C = floatArrayOf(0.75f, 1.0f)

        private val BRS = floatArrayOf(0.25f, 0.40f, 0.60f)
        private val PAR_S = floatArrayOf(0.06f, 0.12f, 0.20f)
    }
}

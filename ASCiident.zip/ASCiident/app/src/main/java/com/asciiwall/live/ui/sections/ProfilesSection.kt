package com.asciiwall.live.ui.sections

import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.asciiwall.live.R
import com.asciiwall.live.presets.PresetRegistry
import com.asciiwall.live.settings.Profile
import com.asciiwall.live.ui.MainViewModel
import com.asciiwall.live.ui.components.ActionButton
import com.asciiwall.live.ui.components.AppTextField
import com.asciiwall.live.ui.components.GroupLabel
import com.asciiwall.live.ui.components.SectionCard
import com.asciiwall.live.ui.components.VSpace
import com.asciiwall.live.ui.theme.App
import com.asciiwall.live.ui.theme.AppShapes
import com.asciiwall.live.ui.theme.AppType
import kotlinx.coroutines.launch

@Composable
fun ProfilesSection(profile: Profile, saved: List<Profile>, vm: MainViewModel) {
    val c = App.colors
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    var name by rememberSaveable { mutableStateOf("") }
    var toDelete by remember { mutableStateOf<String?>(null) }
    val shareTitle = stringResource(R.string.profile_share_title)

    val presetNames = remember { PresetRegistry.entries.associate { it.id to it.create().nameRes } }

    fun share(json: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, json)
        }
        try {
            context.startActivity(Intent.createChooser(send, shareTitle))
        } catch (e: ActivityNotFoundException) {
        }
    }

    SectionCard(
        tag = stringResource(R.string.section_profiles),
        title = stringResource(R.string.section_profiles_title)
    ) {
        Column {
            GroupLabel(stringResource(R.string.profile_name_hint))
            AppTextField(
                value = name,
                onValueChange = { name = it.take(Profile.MAX_NAME) },
                hint = profile.name
            )
            VSpace(10.dp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(
                    stringResource(R.string.profile_save),
                    { vm.saveAs(name.ifBlank { profile.name }); name = "" },
                    filled = true
                )
                ActionButton(
                    stringResource(R.string.profile_export),
                    { scope.launch { share(vm.export(null)) } }
                )
            }

            VSpace(20.dp)

            if (saved.isEmpty()) {
                Text(stringResource(R.string.profile_empty), style = AppType.caption, color = c.textMuted)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (p in saved) {
                        val active = p.name.equals(profile.name, ignoreCase = true)
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(AppShapes.row)
                                .background(if (active) c.selected else c.bg)
                                .border(1.dp, if (active) c.accent else c.border, AppShapes.row)
                                .padding(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        p.name,
                                        style = AppType.rowTitle,
                                        color = c.text,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val nameRes = presetNames[p.presetId]
                                    if (nameRes != null) {
                                        Text(stringResource(nameRes), style = AppType.caption, color = c.textMuted)
                                    }
                                }
                                if (active) {
                                    Text("ACTIVE", style = AppType.tag, color = c.accent, modifier = Modifier.padding(start = 8.dp))
                                }
                            }
                            VSpace(10.dp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ActionButton(stringResource(R.string.profile_load), { vm.load(p.name) }, filled = !active)
                                ActionButton(
                                    stringResource(R.string.profile_export),
                                    { scope.launch { share(vm.export(p.name)) } }
                                )
                                ActionButton(
                                    stringResource(R.string.profile_delete),
                                    { toDelete = p.name },
                                    danger = true
                                )
                            }
                        }
                    }
                }
            }

            VSpace(20.dp)
            Text(stringResource(R.string.profile_import_hint), style = AppType.caption, color = c.textMuted)
            VSpace(8.dp)
            ActionButton(
                stringResource(R.string.profile_import),
                { vm.import(clipboard.getText()?.text.orEmpty()) },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    val del = toDelete
    if (del != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            containerColor = c.card,
            title = {
                Text(stringResource(R.string.profile_delete_confirm, del), style = AppType.rowTitle, color = c.text)
            },
            confirmButton = {
                TextButton(onClick = { vm.delete(del); toDelete = null }) {
                    Text(stringResource(R.string.profile_delete).uppercase(), style = AppType.label, color = c.danger)
                }
            },
            dismissButton = {
                TextButton(onClick = { toDelete = null }) {
                    Text(stringResource(R.string.action_cancel).uppercase(), style = AppType.label, color = c.textMuted)
                }
            }
        )
    }
}

package com.asciiwall.live.ui.sections

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.asciiwall.live.R
import com.asciiwall.live.presets.PresetRegistry
import com.asciiwall.live.settings.PresetLook
import com.asciiwall.live.settings.Profile
import com.asciiwall.live.ui.MainViewModel
import com.asciiwall.live.ui.components.RadioRow
import com.asciiwall.live.ui.components.SectionCard

/** Короткие моно-метки справа, как FUSILLI на референсе. Не переводятся. */
private fun tagOf(id: String): String = when (id) {
    "underwater" -> "DEEP"
    else -> id
}

@Composable
fun PresetSection(profile: Profile, vm: MainViewModel) {
    val presets = remember { PresetRegistry.entries.map { it.id to it.create() } }

    SectionCard(
        tag = stringResource(R.string.section_preset),
        title = stringResource(R.string.section_preset_title)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            for ((id, p) in presets) {
                RadioRow(
                    title = stringResource(p.nameRes),
                    subtitle = stringResource(p.descRes),
                    tag = tagOf(id),
                    selected = id == profile.presetId,
                    onClick = {
                        if (id != profile.presetId) {
                            vm.update { cur ->
                                val look = PresetLook.of(cur.presetId)
                                val untouched = cur.stops == look.stops && cur.background == look.background
                                cur.withPreset(id, applyLook = untouched)
                            }
                        }
                    }
                )
            }
        }
    }
}

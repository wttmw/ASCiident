package com.asciiwall.live.engine

import java.util.concurrent.CopyOnWriteArraySet

/**
 * Мост между настройками и обоями. Приложение и сервис обоев работают в одном процессе,
 * поэтому достаточно синглтона: UI кладёт сюда новый конфиг, все живые Engine получают его сразу.
 */
object ConfigHub {

    @Volatile
    var current: EngineConfig = EngineConfig()
        private set

    private val listeners = CopyOnWriteArraySet<(EngineConfig) -> Unit>()

    /** Заменяет конфиг целиком и уведомляет слушателей. Одинаковый конфиг игнорируется. */
    fun publish(config: EngineConfig) {
        if (config == current) return
        current = config
        for (l in listeners) l(config)
    }

    @Synchronized
    fun update(block: EngineConfig.() -> EngineConfig) {
        publish(current.block())
    }

    fun addListener(l: (EngineConfig) -> Unit) {
        listeners.add(l)
    }

    fun removeListener(l: (EngineConfig) -> Unit) {
        listeners.remove(l)
    }
}

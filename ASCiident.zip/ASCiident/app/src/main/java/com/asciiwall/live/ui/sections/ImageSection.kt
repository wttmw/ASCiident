package com.asciiwall.live.ui.sections

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.asciiwall.live.R
import com.asciiwall.live.image.Dither
import com.asciiwall.live.image.ImageFit
import com.asciiwall.live.settings.Profile
import com.asciiwall.live.ui.MainViewModel
import com.asciiwall.live.ui.components.ActionButton
import com.asciiwall.live.ui.components.AppSlider
import com.asciiwall.live.ui.components.ChipGroup
import com.asciiwall.live.ui.components.GroupLabel
import com.asciiwall.live.ui.components.Option
import com.asciiwall.live.ui.components.SectionCard
import com.asciiwall.live.ui.components.SwitchRow
import com.asciiwall.live.ui.components.VSpace
import com.asciiwall.live.ui.theme.App
import com.asciiwall.live.ui.theme.AppType
import java.util.Locale
import kotlin.math.roundToInt

private val ditherOptions = Dither.entries.map { Option(it, it.name) }
private val fitOptions = ImageFit.entries.map { Option(it, it.name) }

private fun pct(v: Float) = "${(v * 100).roundToInt()}%"
private fun snap(v: Float) = (v * 20f).roundToInt() / 20f

@Composable
fun ImageSection(profile: Profile, vm: MainViewModel) {
    val c = App.colors
    val img = profile.image
    val missing by vm.imageMissing.collectAsStateWithLifecycle()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setImage(uri)
    }

    SectionCard(
        tag = stringResource(R.string.section_image),
        title = stringResource(R.string.section_image_title)
    ) {
        Column {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(
                    stringResource(R.string.image_pick),
                    {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    filled = true
                )
                ActionButton(
                    stringResource(R.string.image_clear),
                    { vm.clearImage() },
                    danger = true,
                    enabled = img.isSet
                )
            }

            VSpace(10.dp)
            when {
                !img.isSet -> Text(stringResource(R.string.image_empty), style = AppType.caption, color = c.textMuted)
                missing -> Text(stringResource(R.string.msg_image_missing), style = AppType.caption, color = c.danger)
            }

            if (img.isSet && !missing && profile.presetId != "image") {
                VSpace(10.dp)
                ActionButton(
                    stringResource(R.string.image_use_preset),
                    { vm.setPreset("image") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            VSpace(16.dp)
            GroupLabel(stringResource(R.string.image_fit))
            ChipGroup(fitOptions, img.fit, { f -> vm.updateImage { it.copy(fit = f) } })

            VSpace(12.dp)
            AppSlider(
                label = stringResource(R.string.image_threshold),
                valueText = pct(img.threshold),
                value = img.threshold,
                range = 0f..0.9f,
                onChange = { v -> vm.updateImage { it.copy(threshold = (v * 50f).roundToInt() / 50f) } }
            )
            AppSlider(
                label = stringResource(R.string.image_contrast),
                valueText = ((img.contrast - 0.5f) * 200f).roundToInt().let { if (it > 0) "+$it" else "$it" },
                value = img.contrast,
                range = 0f..1f,
                onChange = { v -> vm.updateImage { it.copy(contrast = snap(v)) } }
            )
            AppSlider(
                label = stringResource(R.string.image_gamma),
                valueText = String.format(Locale.US, "%.2f", img.gamma),
                value = img.gamma,
                range = 0.4f..2.5f,
                onChange = { v -> vm.updateImage { it.copy(gamma = (v * 20f).roundToInt() / 20f) } }
            )
            AppSlider(
                label = stringResource(R.string.image_density),
                valueText = pct(img.density),
                value = img.density,
                range = 0.5f..1.5f,
                onChange = { v -> vm.updateImage { it.copy(density = snap(v)) } }
            )
            AppSlider(
                label = stringResource(R.string.image_sharpen),
                valueText = pct(img.sharpen),
                value = img.sharpen,
                range = 0f..1f,
                onChange = { v -> vm.updateImage { it.copy(sharpen = snap(v)) } }
            )

            SwitchRow(
                label = stringResource(R.string.image_invert),
                checked = img.invert,
                onChange = { on -> vm.updateImage { it.copy(invert = on) } }
            )

            VSpace(8.dp)
            GroupLabel(stringResource(R.string.image_dithering))
            ChipGroup(ditherOptions, img.dither, { d -> vm.updateImage { it.copy(dither = d) } })
        }
    }
}

package com.asciiwall.live.wallpaper

import android.app.WallpaperColors
import android.app.WallpaperManager
import android.graphics.Canvas
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import androidx.annotation.RequiresApi
import com.asciiwall.live.engine.ConfigHub
import com.asciiwall.live.engine.EngineConfig
import com.asciiwall.live.engine.WallpaperEngine
import com.asciiwall.live.presets.TouchAction
import com.asciiwall.live.settings.ColorUtils

/**
 * Живые обои. Каждый Engine (домашний экран, экран блокировки, превью системы)
 * получает свой WallpaperEngine и свой поток рендера.
 * Поток спит между кадрами (postDelayed), при невидимости цикл остановлен полностью.
 */
class AsciiWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = AsciiEngine()

    private inner class AsciiEngine : Engine(), ScreenStateReceiver.Listener {

        private val engine = WallpaperEngine()
        private val thread = HandlerThread("ascii-render", Process.THREAD_PRIORITY_DISPLAY)
        private lateinit var handler: Handler
        private val receiver = ScreenStateReceiver(this)

        @Volatile private var visible = false
        @Volatile private var surfaceReady = false
        @Volatile private var surfaceW = 1
        @Volatile private var surfaceH = 1

        private val frame = Runnable { step() }
        private val configListener: (EngineConfig) -> Unit = { c ->
            engine.setConfig(c)
            kick()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) notifyColorsChanged()
        }

        // ---------------- Жизненный цикл ----------------

        override fun onCreate(holder: SurfaceHolder) {
            super.onCreate(holder)
            setTouchEventsEnabled(true)
            thread.start()
            handler = Handler(thread.looper)
            engine.setConfig(ConfigHub.current)
            ConfigHub.addListener(configListener)
            receiver.register(this@AsciiWallpaperService)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceW = width.coerceAtLeast(1)
            surfaceH = height.coerceAtLeast(1)
            handler.post {
                engine.onSurface(width, height)
                surfaceReady = true
                drawFrame()
                if (visible) kick()
            }
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) {
            super.onSurfaceRedrawNeeded(holder)
            handler.post {
                engine.requestRedraw()
                if (surfaceReady) drawFrame()
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            surfaceReady = false
            handler.removeCallbacks(frame)
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(v: Boolean) {
            super.onVisibilityChanged(v)
            visible = v
            engine.setVisible(v)
            if (v) kick() else handler.removeCallbacks(frame)
        }

        override fun onDestroy() {
            visible = false
            surfaceReady = false
            ConfigHub.removeListener(configListener)
            receiver.unregister(this@AsciiWallpaperService)
            handler.removeCallbacksAndMessages(null)
            handler.post {
                engine.release()
                thread.quitSafely()
            }
            super.onDestroy()
        }

        // ---------------- Цвета обоев для системы ----------------

        @RequiresApi(Build.VERSION_CODES.O_MR1)
        override fun onComputeColors(): WallpaperColors? =
            ColorUtils.wallpaperColors(ConfigHub.current.stops)

        // ---------------- Цикл кадров ----------------

        private fun step() {
            if (!visible || !surfaceReady) return
            if (engine.tick()) drawFrame()
            val delay = if (engine.clock.frozen) IDLE_MS
            else engine.clock.delayMillis(engine.frameNanos).coerceAtLeast(1L)
            handler.postDelayed(frame, delay)
        }

        private fun kick() {
            if (!::handler.isInitialized) return
            handler.removeCallbacks(frame)
            handler.post(frame)
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = try {
                    holder.lockHardwareCanvas()
                } catch (e: Exception) {
                    holder.lockCanvas()
                }
                if (canvas != null) engine.draw(canvas)
            } catch (e: Exception) {
                // Поверхность исчезла посреди кадра, пропускаем.
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: IllegalArgumentException) {
                    }
                }
            }
        }

        // ---------------- Ввод ----------------

        override fun onTouchEvent(event: MotionEvent) {
            val action = when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> TouchAction.DOWN
                MotionEvent.ACTION_MOVE -> TouchAction.MOVE
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> TouchAction.UP
                else -> return
            }
            engine.touch(event.x / surfaceW, event.y / surfaceH, action)
            kick()
        }

        override fun onCommand(
            action: String?, x: Int, y: Int, z: Int, extras: Bundle?, resultRequested: Boolean
        ): Bundle? {
            if (action == WallpaperManager.COMMAND_TAP) {
                val nx = x.toFloat() / surfaceW
                val ny = y.toFloat() / surfaceH
                engine.touch(nx, ny, TouchAction.DOWN)
                engine.touch(nx, ny, TouchAction.UP)
                kick()
            }
            return super.onCommand(action, x, y, z, extras, resultRequested)
        }

        override fun onOffsetsChanged(
            xOffset: Float, yOffset: Float, xStep: Float, yStep: Float, xPixels: Int, yPixels: Int
        ) {
            engine.scroll(xOffset)
            kick()
        }

        // ---------------- Экран и питание ----------------

        override fun onScreenOff() {
            engine.lock()
            kick()
        }

        override fun onUserPresent() {
            engine.unlock()
            kick()
        }

        override fun onPower(batteryLow: Boolean, powerSave: Boolean) {
            engine.setPower(batteryLow, powerSave)
        }
    }

    private companion object {
        const val IDLE_MS = 200L
    }
}

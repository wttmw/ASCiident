package com.asciiwall.live.core

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.roundToInt

/**
 * Атлас глифов: ALPHA_8 bitmap, символы отсортированы по "плотности".
 * Индекс 0 всегда пробел (пусто). Цвет задаётся Paint при отрисовке.
 */
class GlyphAtlas private constructor(
    val bitmap: Bitmap,
    val cellW: Int,
    val cellH: Int,
    val glyphCount: Int,
    val atlasCols: Int,
    val chars: String,
    val coverage: FloatArray,
    val lut: IntArray
) {
    val atlasRows: Int get() = (glyphCount + atlasCols - 1) / atlasCols

    fun srcLeft(index: Int): Int = (index % atlasCols) * cellW
    fun srcTop(index: Int): Int = (index / atlasCols) * cellH

    fun u0(index: Int): Float = srcLeft(index).toFloat() / bitmap.width
    fun v0(index: Int): Float = srcTop(index).toFloat() / bitmap.height
    val uSize: Float get() = cellW.toFloat() / bitmap.width
    val vSize: Float get() = cellH.toFloat() / bitmap.height

    fun glyphFor(level: Float): Int = lut[(level.coerceIn(0f, 1f) * 255f).toInt()]

    fun recycle() {
        if (!bitmap.isRecycled) bitmap.recycle()
    }

    companion object {
        const val ATLAS_COLS = 16
        const val MAX_GLYPHS = 256

        fun build(
            rawChars: String,
            cellW: Int,
            cellH: Int,
            typeface: Typeface = Typeface.MONOSPACE
        ): GlyphAtlas {
            require(cellW >= 4 && cellH >= 6) { "cell too small" }

            val set = LinkedHashSet<Char>()
            set.add(' ')
            rawChars.forEach { if (!it.isISOControl() && !it.isWhitespace()) set.add(it) }

            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                this.typeface = typeface
                textAlign = Paint.Align.CENTER
            }
            // Символы, которых нет в шрифте, отбрасываются (иначе рисовался бы квадратик).
            val list = set.filter { it == ' ' || it.code < 128 || paint.hasGlyph(it.toString()) }
                .take(MAX_GLYPHS)
                .toMutableList()
            if (list.size < 2) list.add('#')
            fitTextSize(paint, cellW, cellH)
            val baseline = cellH / 2f - (paint.ascent() + paint.descent()) / 2f

            // Проход 1: плотность каждого глифа.
            val tmp = Bitmap.createBitmap(cellW, cellH, Bitmap.Config.ARGB_8888)
            val tmpCanvas = Canvas(tmp)
            val px = IntArray(cellW * cellH)
            val measured = FloatArray(list.size)
            list.forEachIndexed { i, ch ->
                tmp.eraseColor(Color.TRANSPARENT)
                tmpCanvas.drawText(ch.toString(), cellW / 2f, baseline, paint)
                tmp.getPixels(px, 0, cellW, 0, 0, cellW, cellH)
                var sum = 0L
                for (p in px) sum += (p ushr 24)
                measured[i] = sum.toFloat() / (255f * px.size)
            }
            tmp.recycle()

            val order = list.indices.sortedBy { measured[it] }
            val maxCov = (measured.maxOrNull() ?: 1f).coerceAtLeast(0.0001f)
            val sortedChars = CharArray(list.size) { list[order[it]] }
            val coverage = FloatArray(list.size) { measured[order[it]] / maxCov }

            // Проход 2: атлас в отсортированном порядке.
            val n = sortedChars.size
            val rows = (n + ATLAS_COLS - 1) / ATLAS_COLS
            val argb = Bitmap.createBitmap(ATLAS_COLS * cellW, rows * cellH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(argb)
            for (i in 0 until n) {
                val cx = (i % ATLAS_COLS) * cellW + cellW / 2f
                val cy = (i / ATLAS_COLS) * cellH + baseline
                canvas.drawText(sortedChars[i].toString(), cx, cy, paint)
            }
            val alpha = argb.extractAlpha()
            argb.recycle()

            val lut = IntArray(256) { ((it / 255f) * (n - 1)).roundToInt() }

            return GlyphAtlas(
                bitmap = alpha,
                cellW = cellW,
                cellH = cellH,
                glyphCount = n,
                atlasCols = ATLAS_COLS,
                chars = String(sortedChars),
                coverage = coverage,
                lut = lut
            )
        }

        private fun fitTextSize(paint: Paint, cellW: Int, cellH: Int) {
            var size = cellH * 0.82f
            paint.textSize = size
            val w = paint.measureText("M")
            if (w > cellW * 0.95f) {
                size *= (cellW * 0.95f) / w
                paint.textSize = size
            }
        }
    }
}

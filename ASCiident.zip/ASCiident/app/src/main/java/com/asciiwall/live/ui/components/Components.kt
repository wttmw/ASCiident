package com.asciiwall.live.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.asciiwall.live.ui.theme.App
import com.asciiwall.live.ui.theme.AppShapes
import com.asciiwall.live.ui.theme.AppType

@Composable
fun VSpace(h: Dp) = Spacer(Modifier.height(h))

/** Шапка экрана: зелёная точка + метка, заголовок, одна строка описания. */
@Composable
fun ScreenHeader(tag: String, title: String, subtitle: String, modifier: Modifier = Modifier) {
    val c = App.colors
    Column(modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(c.accent))
            Spacer(Modifier.size(12.dp))
            Text(tag.uppercase(), style = AppType.tag, color = c.accent)
        }
        VSpace(14.dp)
        Text(title, style = AppType.title, color = c.text)
        VSpace(12.dp)
        Text(subtitle, style = AppType.body, color = c.textMuted)
    }
}

/** Карточка секции: метка "01 / ИМЯ" (моно, акцент) и крупный заголовок. */
@Composable
fun SectionCard(
    tag: String,
    title: String,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    val c = App.colors
    Column(
        modifier
            .fillMaxWidth()
            .clip(AppShapes.card)
            .background(c.card)
            .border(1.dp, c.border, AppShapes.card)
            .padding(20.dp)
    ) {
        Text(tag.uppercase(), style = AppType.tag, color = c.accent)
        VSpace(12.dp)
        Text(title, style = AppType.cardTitle, color = c.text)
        VSpace(16.dp)
        content()
    }
}

@Composable
fun GroupLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        style = AppType.label,
        color = App.colors.textMuted,
        modifier = modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun RadioDot(selected: Boolean) {
    val c = App.colors
    val ring = if (selected) c.accent else c.textFaint
    Box(
        Modifier.size(28.dp).clip(CircleShape).border(2.dp, ring, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (selected) Box(Modifier.size(14.dp).clip(CircleShape).background(c.accent))
    }
}

/** Строка выбора: радио, название, серое описание, справа моно-метка. */
@Composable
fun RadioRow(
    title: String,
    subtitle: String,
    tag: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val c = App.colors
    Row(
        modifier
            .fillMaxWidth()
            .clip(AppShapes.row)
            .background(if (selected) c.selected else Color.Transparent)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioDot(selected)
        Spacer(Modifier.size(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = AppType.rowTitle, color = c.text)
            if (subtitle.isNotEmpty()) {
                Text(subtitle, style = AppType.caption, color = c.textMuted)
            }
        }
        if (tag.isNotEmpty()) {
            Spacer(Modifier.size(12.dp))
            Text(
                tag.uppercase(),
                style = AppType.tag,
                color = if (selected) c.accent else c.textFaint,
                textAlign = TextAlign.End,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** Ползунок: слева моно-подпись, справа моно-значение акцентом. */
@Composable
fun AppSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    steps: Int = 0,
    enabled: Boolean = true
) {
    val c = App.colors
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                label.uppercase(),
                style = AppType.label,
                color = if (enabled) c.textMuted else c.textFaint,
                modifier = Modifier.weight(1f)
            )
            Text(valueText, style = AppType.value, color = if (enabled) c.accent else c.textFaint)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            enabled = enabled,
            modifier = Modifier.semantics { contentDescription = label },
            colors = SliderDefaults.colors(
                thumbColor = c.accent,
                activeTrackColor = c.accent,
                inactiveTrackColor = c.track,
                activeTickColor = Color.Transparent,
                inactiveTickColor = Color.Transparent,
                disabledThumbColor = c.textFaint,
                disabledActiveTrackColor = c.textFaint,
                disabledInactiveTrackColor = c.track
            )
        )
    }
}

class Option<T>(val id: T, val label: String)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun <T> ChipGroup(
    options: List<Option<T>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    FlowRow(
        modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for (o in options) {
            Chip(o.label, o.id == selected, onClick = { onSelect(o.id) })
        }
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = App.colors
    Box(
        modifier
            .heightIn(min = 40.dp)
            .clip(AppShapes.chip)
            .background(if (selected) c.accent else Color.Transparent)
            .border(1.dp, if (selected) c.accent else c.border, AppShapes.chip)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text.uppercase(),
            style = AppType.label,
            color = if (selected) c.onAccent else c.text,
            maxLines = 1
        )
    }
}

@Composable
fun SwitchRow(
    label: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val c = App.colors
    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .toggleable(value = checked, enabled = enabled, role = Role.Switch, onValueChange = onChange),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = AppType.body,
            color = if (enabled) c.text else c.textFaint,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = null,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = c.onAccent,
                checkedTrackColor = c.accent,
                checkedBorderColor = c.accent,
                uncheckedThumbColor = c.textMuted,
                uncheckedTrackColor = c.track,
                uncheckedBorderColor = c.border
            )
        )
    }
}

@Composable
fun ActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    danger: Boolean = false,
    enabled: Boolean = true
) {
    val c = App.colors
    val tone = if (danger) c.danger else c.accent
    val bg = when {
        !enabled -> c.track
        filled -> tone
        else -> Color.Transparent
    }
    val fg = when {
        !enabled -> c.textFaint
        filled -> if (danger) Color.White else c.onAccent
        else -> tone
    }
    val stroke = if (filled) BorderStroke(0.dp, Color.Transparent) else BorderStroke(1.dp, if (enabled) tone else c.border)
    Box(
        modifier
            .heightIn(min = 48.dp)
            .clip(AppShapes.chip)
            .background(bg)
            .border(stroke, AppShapes.chip)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text.uppercase(), style = AppType.label, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun AppTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    hint: String = "",
    singleLine: Boolean = true,
    mono: Boolean = true,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default
) {
    val c = App.colors
    val style: TextStyle = (if (mono) AppType.value else AppType.body).copy(color = c.text)
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = singleLine,
        textStyle = style,
        keyboardOptions = keyboardOptions,
        cursorBrush = SolidColor(c.accent),
        modifier = modifier,
        decorationBox = { inner ->
            Box(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .clip(AppShapes.chip)
                    .background(c.bg)
                    .border(1.dp, c.border, AppShapes.chip)
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                if (value.isEmpty() && hint.isNotEmpty()) {
                    Text(hint, style = style.copy(color = c.textFaint))
                }
                inner()
            }
        }
    )
}

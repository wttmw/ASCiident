package com.asciiwall.live.ui.sections

import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.asciiwall.live.R
import com.asciiwall.live.core.GridConfig
import com.asciiwall.live.settings.Profile
import com.asciiwall.live.ui.MainViewModel
import com.asciiwall.live.ui.components.AppSlider
import com.asciiwall.live.ui.components.ChipGroup
import com.asciiwall.live.ui.components.GroupLabel
import com.asciiwall.live.ui.components.Option
import com.asciiwall.live.ui.components.SectionCard
import com.asciiwall.live.ui.components.SwitchRow
import com.asciiwall.live.ui.components.VSpace
import java.util.Locale
import kotlin.math.roundToInt

private const val ROWS_DEFAULT = 90

private val fpsOptions = GridConfig.FPS_OPTIONS.map { Option(it, it.toString()) }

@Composable
fun GridSection(profile: Profile, vm: MainViewModel) {
    val auto = profile.rows == 0

    SectionCard(
        tag = stringResource(R.string.section_grid),
        title = stringResource(R.string.section_grid_title)
    ) {
        Column {
            AppSlider(
                label = stringResource(R.string.grid_columns),
                valueText = profile.columns.toString(),
                value = profile.columns.toFloat(),
                range = GridConfig.MIN_COLUMNS.toFloat()..GridConfig.MAX_COLUMNS.toFloat(),
                steps = (GridConfig.MAX_COLUMNS - GridConfig.MIN_COLUMNS) / 5 - 1,
                onChange = { v -> vm.update { it.copy(columns = (v / 5f).roundToInt() * 5) } }
            )

            SwitchRow(
                label = stringResource(R.string.grid_rows_auto),
                checked = auto,
                onChange = { on -> vm.update { it.copy(rows = if (on) 0 else ROWS_DEFAULT) } }
            )
            AppSlider(
                label = stringResource(R.string.grid_rows),
                valueText = if (auto) "AUTO" else profile.rows.toString(),
                value = (if (auto) ROWS_DEFAULT else profile.rows).toFloat(),
                range = GridConfig.MIN_ROWS.toFloat()..GridConfig.MAX_ROWS.toFloat(),
                enabled = !auto,
                onChange = { v -> vm.update { it.copy(rows = v.roundToInt()) } }
            )

            AppSlider(
                label = stringResource(R.string.grid_cell_aspect),
                valueText = String.format(Locale.US, "%.2f", profile.cellAspect),
                value = profile.cellAspect,
                range = 1.2f..3.0f,
                steps = 35,
                onChange = { v -> vm.update { it.copy(cellAspect = (v * 20f).roundToInt() / 20f) } }
            )

            VSpace(8.dp)
            GroupLabel(stringResource(R.string.fps_limit))
            ChipGroup(
                options = fpsOptions,
                selected = profile.fps,
                onSelect = { f -> vm.update { it.copy(fps = f) } }
            )

            VSpace(8.dp)
            SwitchRow(
                label = stringResource(R.string.fps_auto_saver),
                checked = profile.autoSaver,
                onChange = { on -> vm.update { it.copy(autoSaver = on) } }
            )
        }
    }
}

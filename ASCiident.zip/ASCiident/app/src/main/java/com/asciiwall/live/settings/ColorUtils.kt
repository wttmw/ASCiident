package com.asciiwall.live.settings

import android.app.WallpaperColors
import android.content.Context
import android.graphics.Color
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils as CoreColors

/**
 * Цветовые помощники: каналы RGB, HSV, HEX, правка градиента, системная палитра (Material You),
 * цвета обоев для системы, контрастный акцент интерфейса. Все цвета в ARGB Int, альфа 0xFF.
 */
object ColorUtils {

    fun red(c: Int) = Color.red(c)
    fun green(c: Int) = Color.green(c)
    fun blue(c: Int) = Color.blue(c)

    fun rgb(r: Int, g: Int, b: Int): Int =
        Color.rgb(r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255))

    /** channel: 0 = R, 1 = G, 2 = B. */
    fun withChannel(color: Int, channel: Int, value: Int): Int = when (channel) {
        0 -> rgb(value, green(color), blue(color))
        1 -> rgb(red(color), value, blue(color))
        else -> rgb(red(color), green(color), value)
    }

    fun toHsv(color: Int): FloatArray {
        val out = FloatArray(3)
        Color.colorToHSV(color, out)
        return out
    }

    fun fromHsv(h: Float, s: Float, v: Float): Int =
        Color.HSVToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))

    fun hex(color: Int): String = String.format("#%06X", color and 0xFFFFFF)

    /** "#RRGGBB", "RRGGBB" или "#RGB". null при неверном вводе. */
    fun parseHex(text: String): Int? {
        var s = text.trim().removePrefix("#")
        if (s.length == 3) s = s.map { "$it$it" }.joinToString("")
        if (s.length != 6) return null
        val v = s.toIntOrNull(16) ?: return null
        return v or 0xFF000000.toInt()
    }

    fun lerp(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return rgb(
            (red(a) + (red(b) - red(a)) * k).toInt(),
            (green(a) + (green(b) - green(a)) * k).toInt(),
            (blue(a) + (blue(b) - blue(a)) * k).toInt()
        )
    }

    // ---------------- Градиент: правка списка ----------------

    fun addStop(stops: List<Int>): List<Int> {
        if (stops.size >= Profile.MAX_STOPS) return stops
        val last = stops.lastOrNull() ?: Color.WHITE
        return stops + lerp(last, Color.WHITE, 0.4f)
    }

    fun removeStop(stops: List<Int>, index: Int): List<Int> {
        if (stops.size <= 2 || index !in stops.indices) return stops
        return stops.filterIndexed { i, _ -> i != index }
    }

    fun setStop(stops: List<Int>, index: Int, color: Int): List<Int> {
        if (index !in stops.indices) return stops
        return stops.mapIndexed { i, c -> if (i == index) color or 0xFF000000.toInt() else c }
    }

    fun moveStop(stops: List<Int>, from: Int, to: Int): List<Int> {
        if (from !in stops.indices || to !in stops.indices || from == to) return stops
        val m = stops.toMutableList()
        m.add(to, m.removeAt(from))
        return m
    }

    // ---------------- Системная палитра (Android 12+) ----------------

    fun systemPaletteAvailable(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    /** Три цвета арта из динамической палитры: тень, середина, свет. null на Android 11 и ниже. */
    fun systemStops(context: Context): List<Int>? {
        if (!systemPaletteAvailable()) return null
        return try {
            listOf(
                ContextCompat.getColor(context, android.R.color.system_accent1_700),
                ContextCompat.getColor(context, android.R.color.system_accent1_300),
                ContextCompat.getColor(context, android.R.color.system_accent1_50)
            ).map { it or 0xFF000000.toInt() }
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- Цвета обоев для системы ----------------

    private val hsvTmp = FloatArray(3)

    /** Основной цвет обоев: самый насыщенный и яркий из градиента. null на Android 8.0. */
    fun wallpaperColors(stops: List<Int>): WallpaperColors? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O_MR1 || stops.isEmpty()) return null
        val ranked = stops.sortedByDescending { c ->
            Color.colorToHSV(c, hsvTmp)
            hsvTmp[1] * hsvTmp[2]
        }
        val p = ranked[0]
        val s = ranked.getOrElse(1) { p }
        val t = ranked.getOrElse(2) { s }
        return WallpaperColors(Color.valueOf(p), Color.valueOf(s), Color.valueOf(t))
    }

    // ---------------- Контраст интерфейса ----------------

    fun luminance(color: Int): Double = CoreColors.calculateLuminance(color)

    fun contrast(a: Int, b: Int): Double =
        CoreColors.calculateContrast(a or 0xFF000000.toInt(), b or 0xFF000000.toInt())

    fun onColor(background: Int): Int =
        if (luminance(background) > 0.40) 0xFF08120D.toInt() else Color.WHITE

    /** Подтягивает яркость акцента под тему интерфейса, оттенок сохраняется. */
    fun readableAccent(accent: Int, darkTheme: Boolean): Int {
        val h = FloatArray(3)
        CoreColors.colorToHSL(accent, h)
        h[2] = if (darkTheme) maxOf(h[2], 0.60f) else minOf(h[2], 0.34f)
        return CoreColors.HSLToColor(h) or 0xFF000000.toInt()
    }

    fun muted(accent: Int, base: Int, amount: Float = 0.78f): Int = lerp(accent, base, amount)
}

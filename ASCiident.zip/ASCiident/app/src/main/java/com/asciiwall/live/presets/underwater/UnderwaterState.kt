package com.asciiwall.live.presets.underwater

import com.asciiwall.live.presets.Noise

/** 4 слоя глубины: множители яркости, скорости и параллакса. */
object Depth {
    const val LAYERS = 4
    const val FAR = 0
    const val MID = 1
    const val NEAR = 2
    const val SURFACE = 3

    val brightness = floatArrayOf(0.35f, 0.60f, 0.90f, 1.00f)
    val speed = floatArrayOf(0.35f, 0.65f, 1.00f, 0.80f)
    val parallax = floatArrayOf(0.06f, 0.15f, 0.32f, 0.10f)
}

/** Типы существ. */
object Kind {
    const val FISH = 0
    const val JELLY = 1
}

/**
 * Всё состояние сцены. Массивы создаются в resize(), в кадре аллокаций нет.
 * Координаты в ячейках: x 0..cols, y 0..rows (0 = поверхность сверху).
 */
class UnderwaterState {

    var cols = 0
        private set
    var rows = 0
        private set

    // ---- Течение и параллакс ----
    var flowX = 0.6f
    var flowTarget = 0.6f
    var scrollOffset = 0f
    var scrollVel = 0f
    var shift = 0f

    // ---- Освещение и события ----
    var flash = 0f
    var dark = 0f
    var darkTarget = 0f
    var calm = 0f

    // ---- Касание ----
    var touching = false
    var touchX = 0f
    var touchY = 0f
    var touchPrevX = 0f
    var touchPrevY = 0f
    var touchVx = 0f
    var touchVy = 0f
    var touchTimer = 0f

    // ---- Кольца на воде ----
    val rx = FloatArray(MAX_RIPPLES)
    val ry = FloatArray(MAX_RIPPLES)
    val rAge = FloatArray(MAX_RIPPLES)
    val rLife = FloatArray(MAX_RIPPLES)
    val rAmp = FloatArray(MAX_RIPPLES)
    val rSpeed = FloatArray(MAX_RIPPLES)
    private var rNext = 0

    // ---- Пузырьки ----
    var bubbleCount = 0
        private set
    var bx = FloatArray(0)
    var by = FloatArray(0)
    var bVy = FloatArray(0)
    var bPhase = FloatArray(0)
    var bSize = FloatArray(0)
    var bLayer = ByteArray(0)
    private var bNext = 0

    // ---- Планктон ----
    var planktonCount = 0
        private set
    var px = FloatArray(0)
    var py = FloatArray(0)
    var pPhase = FloatArray(0)
    var pLayer = ByteArray(0)

    // ---- Существа ----
    var creatureCount = 0
        private set
    var cKind = ByteArray(0)
    var cx = FloatArray(0)
    var cy = FloatArray(0)
    var cVx = FloatArray(0)
    var cVy = FloatArray(0)
    var cPhase = FloatArray(0)
    var cScale = FloatArray(0)
    var cLayer = ByteArray(0)
    var cKickX = FloatArray(0)
    var cKickY = FloatArray(0)

    fun resize(newCols: Int, newRows: Int) {
        cols = newCols
        rows = newRows
        val area = cols * rows

        bubbleCount = (area / 90).coerceIn(14, 70)
        bx = FloatArray(bubbleCount); by = FloatArray(bubbleCount)
        bVy = FloatArray(bubbleCount); bPhase = FloatArray(bubbleCount)
        bSize = FloatArray(bubbleCount); bLayer = ByteArray(bubbleCount)
        for (i in 0 until bubbleCount) spawnBubble(i, true)

        planktonCount = (area / 22).coerceIn(50, 260)
        px = FloatArray(planktonCount); py = FloatArray(planktonCount)
        pPhase = FloatArray(planktonCount); pLayer = ByteArray(planktonCount)
        for (i in 0 until planktonCount) {
            px[i] = Noise.hash(i * 3 + 1) * cols
            py[i] = Noise.hash(i * 3 + 2) * rows
            pPhase[i] = Noise.hash(i * 3 + 3) * 6.2832f
            val r = Noise.hash(i * 7 + 11)
            pLayer[i] = (if (r < 0.40f) Depth.FAR else if (r < 0.75f) Depth.MID else Depth.NEAR).toByte()
        }

        creatureCount = (cols / 12).coerceIn(5, 9)
        cKind = ByteArray(creatureCount)
        cx = FloatArray(creatureCount); cy = FloatArray(creatureCount)
        cVx = FloatArray(creatureCount); cVy = FloatArray(creatureCount)
        cPhase = FloatArray(creatureCount); cScale = FloatArray(creatureCount)
        cLayer = ByteArray(creatureCount)
        cKickX = FloatArray(creatureCount); cKickY = FloatArray(creatureCount)
        for (i in 0 until creatureCount) spawnCreature(i, true)

        java.util.Arrays.fill(rAmp, 0f)
        flash = 0f; dark = 0f; darkTarget = 0f; calm = 0f
    }

    fun addRipple(x: Float, y: Float, amp: Float, speed: Float, life: Float) {
        val i = rNext
        rNext = (rNext + 1) % MAX_RIPPLES
        rx[i] = x; ry[i] = y
        rAge[i] = 0f; rLife[i] = life
        rAmp[i] = amp; rSpeed[i] = speed
    }

    fun spawnBubble(i: Int, anywhere: Boolean) {
        val seed = i * 131 + (bNext++ * 17)
        bx[i] = Noise.hash(seed) * cols
        by[i] = if (anywhere) Noise.hash(seed + 1) * rows else rows + Noise.hash(seed + 1) * 6f
        bVy[i] = 2.2f + Noise.hash(seed + 2) * 2.6f
        bPhase[i] = Noise.hash(seed + 3) * 6.2832f
        bSize[i] = 0.5f + Noise.hash(seed + 4) * 0.5f
        val r = Noise.hash(seed + 5)
        bLayer[i] = (if (r < 0.35f) Depth.FAR else if (r < 0.7f) Depth.MID else Depth.NEAR).toByte()
    }

    fun burstBubbles(x: Float, y: Float, n: Int, speedMul: Float) {
        for (k in 0 until n) {
            val i = bNext % bubbleCount
            bNext++
            val s = bNext * 53 + k * 7
            bx[i] = x + (Noise.hash(s) - 0.5f) * 5f
            by[i] = y + (Noise.hash(s + 1) - 0.5f) * 2f
            bVy[i] = (3f + Noise.hash(s + 2) * 4f) * speedMul
            bPhase[i] = Noise.hash(s + 3) * 6.2832f
            bSize[i] = 0.6f + Noise.hash(s + 4) * 0.4f
            bLayer[i] = Depth.NEAR.toByte()
        }
    }

    fun spawnCreature(i: Int, anywhere: Boolean) {
        val seed = i * 977 + 5
        val jelly = i % 3 == 2
        cKind[i] = (if (jelly) Kind.JELLY else Kind.FISH).toByte()
        val r = Noise.hash(seed)
        val layer = if (r < 0.34f) Depth.FAR else if (r < 0.72f) Depth.MID else Depth.NEAR
        cLayer[i] = layer.toByte()
        cScale[i] = 0.6f + layer * 0.35f + Noise.hash(seed + 1) * 0.3f
        val dir = if (Noise.hash(seed + 2) < 0.65f) 1f else -1f
        cVx[i] = if (jelly) 0f else dir * (1.2f + Noise.hash(seed + 3) * 1.6f) * Depth.speed[layer]
        cVy[i] = 0f
        cPhase[i] = Noise.hash(seed + 4) * 6.2832f
        cy[i] = rows * (0.22f + Noise.hash(seed + 5) * 0.62f)
        cx[i] = if (anywhere) Noise.hash(seed + 6) * cols
        else if (cVx[i] >= 0f) -8f else cols + 8f
        cKickX[i] = 0f; cKickY[i] = 0f
    }

    companion object {
        const val MAX_RIPPLES = 8
    }
}

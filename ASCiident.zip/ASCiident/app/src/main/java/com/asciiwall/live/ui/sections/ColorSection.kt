package com.asciiwall.live.ui.sections

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.asciiwall.live.R
import com.asciiwall.live.settings.ColorUtils
import com.asciiwall.live.settings.Profile
import com.asciiwall.live.ui.MainViewModel
import com.asciiwall.live.ui.components.ActionButton
import com.asciiwall.live.ui.components.AppSlider
import com.asciiwall.live.ui.components.AppTextField
import com.asciiwall.live.ui.components.SectionCard
import com.asciiwall.live.ui.components.SwitchRow
import com.asciiwall.live.ui.components.VSpace
import com.asciiwall.live.ui.theme.App
import com.asciiwall.live.ui.theme.AppShapes
import com.asciiwall.live.ui.theme.AppType
import kotlin.math.roundToInt

/** Что сейчас правит редактор: фон (BG) или цвет градиента с индексом. */
private const val BG = -1

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColorSection(profile: Profile, vm: MainViewModel) {
    val c = App.colors
    val context = LocalContext.current
    val system = profile.useSystemPalette
    val gradient = profile.gradientEnabled
    var sel by rememberSaveable { mutableStateOf(0) }

    val maxIdx = if (gradient) profile.stops.lastIndex else 0
    val target = when {
        system -> BG
        sel == BG -> BG
        else -> sel.coerceIn(0, maxIdx)
    }
    val current = when {
        target == BG -> profile.background
        gradient -> profile.stops[target]
        else -> profile.color
    }

    fun setColor(col: Int) = vm.update { p ->
        when {
            target == BG -> p.copy(background = col)
            p.gradientEnabled -> p.copy(stops = ColorUtils.setStop(p.stops, target, col))
            else -> p.copy(color = col)
        }
    }

    SectionCard(
        tag = stringResource(R.string.section_color),
        title = stringResource(R.string.section_color_title)
    ) {
        Column {
            if (ColorUtils.systemPaletteAvailable()) {
                SwitchRow(
                    label = stringResource(R.string.chars_system_palette),
                    checked = system,
                    onChange = { on -> vm.update { it.copy(useSystemPalette = on) } }
                )
            }
            if (!system) {
                SwitchRow(
                    label = stringResource(R.string.gradient_enable),
                    checked = gradient,
                    onChange = { on -> vm.update { it.copy(gradientEnabled = on) } }
                )
            }

            // Полоса предпросмотра градиента.
            VSpace(8.dp)
            val shown = when {
                system -> ColorUtils.systemStops(context) ?: profile.stops
                gradient -> profile.stops
                else -> listOf(profile.color, profile.color)
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(16.dp)
                    .clip(AppShapes.chip)
                    .background(Brush.horizontalGradient(shown.map { Color(it) }))
                    .border(1.dp, c.border, AppShapes.chip)
            )

            // Образцы: цвета градиента и фон.
            if (!system) {
                VSpace(14.dp)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val n = if (gradient) profile.stops.size else 1
                    for (i in 0 until n) {
                        Swatch(
                            color = if (gradient) profile.stops[i] else profile.color,
                            selected = target == i,
                            onClick = { sel = i }
                        )
                    }
                    Swatch(profile.background, selected = target == BG, onClick = { sel = BG })
                }
                if (gradient) {
                    VSpace(12.dp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ActionButton(
                            stringResource(R.string.gradient_add_stop),
                            {
                                vm.update { it.copy(stops = ColorUtils.addStop(it.stops)) }
                                sel = profile.stops.size
                            },
                            enabled = profile.stops.size < Profile.MAX_STOPS
                        )
                        ActionButton(
                            stringResource(R.string.gradient_remove_stop),
                            {
                                val i = target
                                vm.update { it.copy(stops = ColorUtils.removeStop(it.stops, i)) }
                                sel = 0
                            },
                            danger = true,
                            enabled = target != BG && profile.stops.size > 2
                        )
                    }
                }
            } else {
                VSpace(14.dp)
                Swatch(profile.background, selected = true, onClick = {})
            }

            // Редактор выбранного цвета.
            VSpace(12.dp)
            if (target == BG) {
                Text(
                    stringResource(R.string.color_background).uppercase(),
                    style = AppType.label,
                    color = c.textMuted
                )
            }
            AppSlider(
                label = stringResource(R.string.color_red),
                valueText = ColorUtils.red(current).toString(),
                value = ColorUtils.red(current).toFloat(),
                range = 0f..255f,
                onChange = { v -> setColor(ColorUtils.withChannel(current, 0, v.roundToInt())) }
            )
            AppSlider(
                label = stringResource(R.string.color_green),
                valueText = ColorUtils.green(current).toString(),
                value = ColorUtils.green(current).toFloat(),
                range = 0f..255f,
                onChange = { v -> setColor(ColorUtils.withChannel(current, 1, v.roundToInt())) }
            )
            AppSlider(
                label = stringResource(R.string.color_blue),
                valueText = ColorUtils.blue(current).toString(),
                value = ColorUtils.blue(current).toFloat(),
                range = 0f..255f,
                onChange = { v -> setColor(ColorUtils.withChannel(current, 2, v.roundToInt())) }
            )

            // HEX: в профиль уходит только при полном вводе из 6 цифр.
            var text by remember(target, current) { mutableStateOf(ColorUtils.hex(current)) }
            AppTextField(
                value = text,
                onValueChange = { s ->
                    val clean = s.filter { it == '#' || it.isDigit() || it.lowercaseChar() in 'a'..'f' }.take(7)
                    text = clean
                    if (clean.removePrefix("#").length == 6) ColorUtils.parseHex(clean)?.let { setColor(it) }
                },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters)
            )

            VSpace(12.dp)
            AppSlider(
                label = stringResource(R.string.color_brightness),
                valueText = "${(profile.brightness * 100).roundToInt()}%",
                value = profile.brightness,
                range = 0f..2f,
                onChange = { v -> vm.update { it.copy(brightness = (v * 20f).roundToInt() / 20f) } }
            )
        }
    }
}

@Composable
private fun Swatch(color: Int, selected: Boolean, onClick: () -> Unit) {
    val c = App.colors
    Box(
        Modifier
            .size(44.dp)
            .clip(AppShapes.chip)
            .background(Color(color))
            .border(if (selected) 3.dp else 1.dp, if (selected) c.accent else c.border, AppShapes.chip)
            .clickable(role = Role.Button, onClick = onClick)
    )
}

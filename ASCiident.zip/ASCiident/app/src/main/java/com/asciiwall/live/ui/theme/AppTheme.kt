package com.asciiwall.live.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.asciiwall.live.settings.ColorUtils
import com.asciiwall.live.settings.ThemeMode
import com.asciiwall.live.settings.ThemeStyle
import com.asciiwall.live.settings.UiSettings

/** Палитра интерфейса. Все экраны берут цвета только отсюда (App.colors). */
@Immutable
data class AppColors(
    val dark: Boolean,
    val bg: Color,
    val card: Color,
    val border: Color,
    val accent: Color,
    val onAccent: Color,
    val selected: Color,
    val text: Color,
    val textMuted: Color,
    val textFaint: Color,
    val track: Color,
    val previewBg: Color = Color.Black,
    val previewFg: Color = accent,
    val danger: Color = Color(0xFFFF6B5E)
)

val LocalAppColors = staticCompositionLocalOf<AppColors> { error("AppTheme missing") }

object App {
    val colors: AppColors
        @Composable @ReadOnlyComposable get() = LocalAppColors.current
}

object AppShapes {
    val card = RoundedCornerShape(28.dp)
    val row = RoundedCornerShape(20.dp)
    val chip = RoundedCornerShape(14.dp)
    val preview = RoundedCornerShape(28.dp)
}

object AppType {
    private val mono = FontFamily.Monospace

    val tag = TextStyle(fontFamily = mono, fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Medium)
    val label = TextStyle(fontFamily = mono, fontSize = 13.sp, letterSpacing = 1.2.sp)
    val value = TextStyle(fontFamily = mono, fontSize = 13.sp, letterSpacing = 0.5.sp, fontWeight = FontWeight.Medium)
    val title = TextStyle(fontSize = 34.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp)
    val cardTitle = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold)
    val rowTitle = TextStyle(fontSize = 18.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold)
    val body = TextStyle(fontSize = 15.sp, lineHeight = 21.sp)
    val caption = TextStyle(fontSize = 13.sp, lineHeight = 18.sp)
}

// ---------------- Палитры ----------------

private fun terminal(dark: Boolean) = if (dark) AppColors(
    dark = true,
    bg = Color(0xFF0A1210),
    card = Color(0xFF0F1A16),
    border = Color(0xFF1E3A2E),
    accent = Color(0xFF5CFF8F),
    onAccent = Color(0xFF04140B),
    selected = Color(0xFF14281F),
    text = Color(0xFFE6F2EA),
    textMuted = Color(0xFF8FA39A),
    textFaint = Color(0xFF5E716A),
    track = Color(0xFF223A2F)
) else AppColors(
    dark = false,
    bg = Color(0xFFF1F6F2),
    card = Color.White,
    border = Color(0xFFC9E3D3),
    accent = Color(0xFF0B8F3C),
    onAccent = Color.White,
    selected = Color(0xFFE3F4E8),
    text = Color(0xFF0F1F17),
    textMuted = Color(0xFF4F6358),
    textFaint = Color(0xFF8AA093),
    track = Color(0xFFCFE3D6)
)

private fun fromAccent(accent: Color, onAccent: Color, dark: Boolean): AppColors {
    return if (dark) {
        val bg = lerp(Color(0xFF050706), accent, 0.04f)
        AppColors(
            dark = true,
            bg = bg,
            card = lerp(bg, accent, 0.06f),
            border = lerp(bg, accent, 0.25f),
            accent = accent,
            onAccent = onAccent,
            selected = lerp(bg, accent, 0.16f),
            text = lerp(Color.White, accent, 0.06f),
            textMuted = lerp(Color(0xFF9AA0A0), accent, 0.12f),
            textFaint = lerp(Color(0xFF626868), accent, 0.12f),
            track = lerp(bg, accent, 0.26f)
        )
    } else {
        val bg = lerp(Color.White, accent, 0.06f)
        AppColors(
            dark = false,
            bg = bg,
            card = Color.White,
            border = lerp(Color.White, accent, 0.25f),
            accent = accent,
            onAccent = onAccent,
            selected = lerp(Color.White, accent, 0.14f),
            text = lerp(Color(0xFF101414), accent, 0.08f),
            textMuted = lerp(Color(0xFF545A5A), accent, 0.12f),
            textFaint = lerp(Color(0xFF8E9494), accent, 0.12f),
            track = lerp(Color.White, accent, 0.22f)
        )
    }
}

@Composable
private fun resolve(ui: UiSettings, dark: Boolean): AppColors {
    val context = LocalContext.current
    return when {
        ui.themeStyle == ThemeStyle.MATERIAL && ColorUtils.systemPaletteAvailable() ->
            materialYou(context, dark)
        ui.themeStyle == ThemeStyle.CUSTOM -> {
            val accent = Color(ColorUtils.readableAccent(ui.customAccent, dark))
            fromAccent(accent, Color(ColorUtils.onColor(accent.toArgb())), dark)
        }
        else -> terminal(dark)
    }
}

private fun materialYou(context: Context, dark: Boolean): AppColors {
    if (Build.VERSION.SDK_INT < 31) return terminal(dark)
    return if (dark) {
        val s = dynamicDarkColorScheme(context)
        fromAccent(s.primary, s.onPrimary, true).copy(
            text = s.onSurface,
            textMuted = s.onSurfaceVariant
        )
    } else {
        val s = dynamicLightColorScheme(context)
        AppColors(
            dark = false,
            bg = s.surface,
            card = s.surfaceContainerLowest,
            border = s.outlineVariant,
            accent = s.primary,
            onAccent = s.onPrimary,
            selected = s.primaryContainer,
            text = s.onSurface,
            textMuted = s.onSurfaceVariant,
            textFaint = s.outline,
            track = s.surfaceVariant
        )
    }
}

// ---------------- Тема ----------------

@Composable
fun AppTheme(ui: UiSettings, content: @Composable () -> Unit) {
    val dark = when (ui.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val base = resolve(ui, dark)

    val previewDark = !ui.previewLight
    val colors = base.copy(
        previewBg = if (previewDark) Color.Black else Color(0xFFF4F8F5),
        previewFg = Color(ColorUtils.readableAccent(base.accent.toArgb(), previewDark))
    )

    val scheme = if (dark) darkColorScheme(
        primary = colors.accent, onPrimary = colors.onAccent,
        primaryContainer = colors.selected, onPrimaryContainer = colors.text,
        secondary = colors.accent, onSecondary = colors.onAccent,
        background = colors.bg, onBackground = colors.text,
        surface = colors.card, onSurface = colors.text,
        surfaceVariant = colors.track, onSurfaceVariant = colors.textMuted,
        outline = colors.border, outlineVariant = colors.border,
        error = colors.danger
    ) else lightColorScheme(
        primary = colors.accent, onPrimary = colors.onAccent,
        primaryContainer = colors.selected, onPrimaryContainer = colors.text,
        secondary = colors.accent, onSecondary = colors.onAccent,
        background = colors.bg, onBackground = colors.text,
        surface = colors.card, onSurface = colors.text,
        surfaceVariant = colors.track, onSurfaceVariant = colors.textMuted,
        outline = colors.border, outlineVariant = colors.border,
        error = colors.danger
    )

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = view.context.findActivity()?.window ?: return@SideEffect
            val c = WindowCompat.getInsetsController(window, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }

    CompositionLocalProvider(LocalAppColors provides colors) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

private fun Context.findActivity(): Activity? {
    var c = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

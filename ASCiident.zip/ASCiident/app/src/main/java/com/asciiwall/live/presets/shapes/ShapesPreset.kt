package com.asciiwall.live.presets.shapes

import com.asciiwall.live.R
import com.asciiwall.live.core.CellBuffer
import com.asciiwall.live.presets.Noise
import com.asciiwall.live.presets.Preset
import com.asciiwall.live.presets.TouchAction
import kotlin.math.abs

/**
 * "Летающие фигуры": каркасные 3D-объекты в невесомости.
 * Глубина через яркость, параллакс по z, события: касание, взрыв при разблокировке,
 * замирание при блокировке.
 */
class ShapesPreset : Preset() {

    override val id = "shapes"
    override val nameRes = R.string.preset_shapes
    override val descRes = R.string.preset_shapes_desc

    private val s = ShapesState()
    private val proj = Projector()
    private val rot = FloatArray(9)
    private val rv = FloatArray(3)
    private val pp = FloatArray(3)

    private val vx = FloatArray(40)
    private val vy = FloatArray(40)
    private val vv = FloatArray(40)
    private val ok = BooleanArray(40)

    private var lastTime = 0f

    override fun onSizeChanged(cols: Int, rows: Int) {
        super.onSizeChanged(cols, rows)
        s.resize(cols, rows, Math3D.ASPECT)
        proj.setup(cols, rows, ShapesState.WORLD_H)
    }

    override fun update(dt: Float, time: Float) {
        if (cols == 0) return
        lastTime = time
        val bgDt = bg(dt)
        val evDt = ev(dt)
        val pxDt = px(dt)

        val darkRate = if (s.darkTarget > s.dark) 1.1f else 3.2f
        s.dark += (s.darkTarget - s.dark) * minOf(1f, darkRate * evDt)
        s.calm += (s.calmTarget - s.calm) * minOf(1f, 1.4f * evDt)
        if (s.flash > 0.001f) s.flash *= 1f - minOf(1f, 1.8f * evDt) else s.flash = 0f

        s.scrollVel *= 1f - minOf(1f, 3f * pxDt)
        val shiftTarget = -(s.scrollOffset - 0.5f) * 0.8f
        s.shift += (shiftTarget - s.shift) * minOf(1f, 5f * pxDt)
        if (abs(s.scrollVel) > 0.01f) s.swipe(-s.scrollVel * 2.5f * pxDt)

        if (s.touching) {
            if (dt > 0.0005f) {
                val k = minOf(1f, 10f * dt)
                val tvx = ((s.touchX - s.touchPrevX) / dt).coerceIn(-30f, 30f)
                val tvy = ((s.touchY - s.touchPrevY) / dt).coerceIn(-30f, 30f)
                s.touchVx += (tvx - s.touchVx) * k
                s.touchVy += (tvy - s.touchVy) * k
            }
            s.touchPrevX = s.touchX
            s.touchPrevY = s.touchY
        } else {
            val k = 1f - minOf(1f, 6f * dt)
            s.touchVx *= k
            s.touchVy *= k
        }

        s.step(bgDt)
    }

    override fun draw(buffer: CellBuffer) {
        if (cols == 0) return
        buffer.clear()
        val lightMul = (1f + s.flash * 0.6f) * (1f - s.dark * 0.85f)
        val colsF = cols.toFloat()

        drawStars(buffer, lightMul, colsF)

        for (i in 0 until s.count) drawShape(buffer, i, lightMul)

        if (s.waveActive) drawWave(buffer, lightMul)

        if (s.touching && proj.project(s.touchX, s.touchY, 0f, pp)) {
            val tx = Math.round(pp[0])
            val ty = Math.round(pp[1])
            for (dy in -1..1) for (dx in -3..3) {
                val d = Noise.dist(dx / 1.9f, dy.toFloat(), 1f)
                val v = 0.5f * (1f - d / 2.2f)
                if (v > 0f) buffer.max(tx + dx, ty + dy, v, 0.9f)
            }
        }

        if (params.flicker > 0f || params.noise > 0f) {
            val step = (lastTime * 8f).toInt() * 131
            val level = buffer.level
            for (y in 0 until rows) {
                for (x in 0 until cols) {
                    val i = y * cols + x
                    val v = level[i]
                    if (v <= 0f) continue
                    level[i] = fx(v, Noise.hash2(x + step, y))
                }
            }
        }
    }

    private fun drawStars(buf: CellBuffer, lightMul: Float, colsF: Float) {
        val n = (cols * rows / 120).coerceIn(12, 60)
        val rowsF = rows.toFloat()
        for (i in 0 until n) {
            var x = (Noise.hash(i * 3 + 1) * colsF + s.shift * colsF * 0.04f) % colsF
            if (x < 0f) x += colsF
            val y = Noise.hash(i * 3 + 2) * rowsF
            val tw = 0.5f + 0.5f * Noise.sin(lastTime * 0.8f + i)
            buf.max(x.toInt(), y.toInt(), (0.08f + 0.14f * tw) * lightMul, 0.15f)
        }
    }

    private fun drawShape(buf: CellBuffer, i: Int, lightMul: Float) {
        val kind = s.kind[i].toInt()
        val vc = ShapesGeometry.vertexCount(kind)
        val verts = ShapesGeometry.verts[kind]
        val edges = ShapesGeometry.edges[kind]
        val size = s.size[i]

        Math3D.setRotation(rot, s.ax[i], s.ay[i], s.az[i])

        val near = 1f - ((s.z[i] + 1f) / 4.2f).coerceIn(0f, 1f)
        val offX = s.shift * s.halfW * (0.3f + 0.7f * near)

        var fadeSum = 0f
        for (v in 0 until vc) {
            Math3D.rotate(rot, verts[v * 3], verts[v * 3 + 1], verts[v * 3 + 2], rv)
            val wz = s.z[i] + rv[2] * size
            ok[v] = proj.project(s.x[i] + rv[0] * size + offX, s.y[i] + rv[1] * size, wz, pp)
            if (!ok[v]) continue
            vx[v] = pp[0]
            vy[v] = pp[1]
            val fade = Math3D.depthFade(wz, -1.6f, 4.4f)
            vv[v] = (0.2f + 0.8f * fade) * lightMul
            fadeSum += fade
        }
        val tint = (s.tint[i] * 0.5f + 0.5f * (fadeSum / vc)).coerceIn(0f, 1f)

        var e = 0
        while (e < edges.size) {
            val a = edges[e]
            val b = edges[e + 1]
            if (ok[a] && ok[b]) {
                Raster.line(buf, vx[a], vy[a], vv[a], vx[b], vy[b], vv[b], tint)
            }
            e += 2
        }
        if (kind != Shape.RING) {
            for (v in 0 until vc) if (ok[v]) Raster.dot(buf, vx[v], vy[v], minOf(1f, vv[v] * 1.25f), tint)
        }
    }

    private fun drawWave(buf: CellBuffer, lightMul: Float) {
        if (!proj.project(s.waveX, s.waveY, 0f, pp)) return
        val fade = 1f - s.waveR / (s.halfW * 2.4f)
        if (fade <= 0.02f) return
        val rx = s.waveR * proj.scale
        val ry = rx / Math3D.ASPECT
        val steps = (rx * 3f).toInt().coerceIn(16, 220)
        val k = 6.2832f / steps
        val v = 0.65f * fade * lightMul
        for (n in 0 until steps) {
            val a = n * k
            buf.max(
                Math.round(pp[0] + Noise.cos(a) * rx),
                Math.round(pp[1] + Noise.sin(a) * ry),
                v, 0.95f
            )
        }
    }

    override fun onTouch(nx: Float, ny: Float, action: Int) {
        if (cols == 0) return
        val x = (nx.coerceIn(0f, 1f) - 0.5f) * 2f * s.halfW
        val y = (ny.coerceIn(0f, 1f) - 0.5f) * 2f * s.halfH
        when (action) {
            TouchAction.DOWN -> {
                s.touching = true
                s.touchX = x; s.touchY = y
                s.touchPrevX = x; s.touchPrevY = y
                s.touchVx = 0f; s.touchVy = 0f
                s.burst(x, y, 1.6f)
            }
            TouchAction.MOVE -> {
                s.touchX = x; s.touchY = y
            }
            TouchAction.UP -> s.touching = false
        }
    }

    override fun onUnlock() {
        if (cols == 0) return
        s.darkTarget = 0f
        s.calmTarget = 0f
        s.flash = 1f
        s.burst(0f, 0f, 9f)
    }

    override fun onLock() {
        s.darkTarget = 1f
        s.calmTarget = 1f
        s.touching = false
    }

    override fun onScroll(offset: Float, velocity: Float) {
        s.scrollOffset = offset
        s.scrollVel = velocity
    }

    override fun onVisibility(visible: Boolean) {
        if (visible) s.touching = false
    }
}

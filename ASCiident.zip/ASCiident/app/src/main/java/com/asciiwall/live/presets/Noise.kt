package com.asciiwall.live.presets

import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.sqrt

/**
 * Шум и таблицы. Всё предрасчитано, в кадре только чтение массивов.
 */
object Noise {

    private const val SIZE = 256
    private const val MASK = SIZE - 1
    private const val TRIG_SIZE = 1024
    private const val TRIG_MASK = TRIG_SIZE - 1
    private const val TWO_PI = (2.0 * PI).toFloat()

    private val perm = IntArray(SIZE * 2)
    private val grad = FloatArray(SIZE)
    private val sinTab = FloatArray(TRIG_SIZE)
    private val cosTab = FloatArray(TRIG_SIZE)

    init {
        var seed = 1337L
        val p = IntArray(SIZE) { it }
        for (i in SIZE - 1 downTo 1) {
            seed = seed * 6364136223846793005L + 1442695040888963407L
            val j = ((seed ushr 33) % (i + 1)).toInt()
            val t = p[i]; p[i] = p[j]; p[j] = t
        }
        for (i in 0 until SIZE * 2) perm[i] = p[i and MASK]
        for (i in 0 until SIZE) grad[i] = perm[i] / 255f

        for (i in 0 until TRIG_SIZE) {
            val a = (i * TWO_PI / TRIG_SIZE).toDouble()
            sinTab[i] = kotlin.math.sin(a).toFloat()
            cosTab[i] = kotlin.math.cos(a).toFloat()
        }
    }

    /** Быстрый sin (радианы), точность достаточна для визуала. */
    fun sin(x: Float): Float {
        val i = ((x * (TRIG_SIZE / TWO_PI)).toInt()) and TRIG_MASK
        return sinTab[i]
    }

    fun cos(x: Float): Float {
        val i = ((x * (TRIG_SIZE / TWO_PI)).toInt()) and TRIG_MASK
        return cosTab[i]
    }

    private fun fade(t: Float): Float = t * t * t * (t * (t * 6f - 15f) + 10f)

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    private fun lat(x: Int, y: Int): Float = grad[perm[perm[x and MASK] + (y and MASK)]]

    private fun lat(x: Int, y: Int, z: Int): Float =
        grad[perm[perm[perm[x and MASK] + (y and MASK)] + (z and MASK)]]

    fun noise2(x: Float, y: Float): Float {
        val xf = floor(x)
        val yf = floor(y)
        val xi = xf.toInt()
        val yi = yf.toInt()
        val u = fade(x - xf)
        val v = fade(y - yf)
        val a = lat(xi, yi)
        val b = lat(xi + 1, yi)
        val c = lat(xi, yi + 1)
        val d = lat(xi + 1, yi + 1)
        return lerp(lerp(a, b, u), lerp(c, d, u), v)
    }

    fun noise3(x: Float, y: Float, z: Float): Float {
        val xf = floor(x)
        val yf = floor(y)
        val zf = floor(z)
        val xi = xf.toInt()
        val yi = yf.toInt()
        val zi = zf.toInt()
        val u = fade(x - xf)
        val v = fade(y - yf)
        val w = fade(z - zf)
        val a = lerp(lat(xi, yi, zi), lat(xi + 1, yi, zi), u)
        val b = lerp(lat(xi, yi + 1, zi), lat(xi + 1, yi + 1, zi), u)
        val c = lerp(lat(xi, yi, zi + 1), lat(xi + 1, yi, zi + 1), u)
        val d = lerp(lat(xi, yi + 1, zi + 1), lat(xi + 1, yi + 1, zi + 1), u)
        return lerp(lerp(a, b, v), lerp(c, d, v), w)
    }

    fun fbm2(x: Float, y: Float): Float =
        (noise2(x, y) * 0.65f + noise2(x * 2.07f + 5.2f, y * 2.07f + 1.3f) * 0.35f)

    fun fbm3(x: Float, y: Float, z: Float): Float =
        (noise3(x, y, z) * 0.65f + noise3(x * 2.07f + 5.2f, y * 2.07f + 1.3f, z * 1.5f) * 0.35f)

    fun hash(n: Int): Float {
        var h = n * 374761393 + 668265263
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFF) / 65535f
    }

    fun hash2(x: Int, y: Int): Float = hash(x * 73856093 xor y * 19349663)

    /** Расстояние с поправкой на пропорции символа (ячейка выше, чем шире). */
    fun dist(dx: Float, dy: Float, aspect: Float = 1.9f): Float {
        val ay = dy * aspect
        return sqrt(dx * dx + ay * ay)
    }

    fun smooth(edge0: Float, edge1: Float, x: Float): Float {
        val t = ((x - edge0) / (edge1 - edge0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }
}

package com.asciiwall.live.core

/**
 * Буфер ячеек сетки. Пресеты пишут сюда яркость (0..1) и позицию в градиенте (0..1).
 * commit() переводит яркость в индекс глифа и ступень через LUT и считает изменённые ячейки.
 * Все массивы создаются один раз при resize(), в кадре аллокаций нет.
 */
class CellBuffer(cols: Int, rows: Int) {

    var cols: Int = cols
        private set
    var rows: Int = rows
        private set
    val count: Int get() = cols * rows

    var level = FloatArray(count)
        private set
    var tint = FloatArray(count)
        private set

    var glyph = ByteArray(count)
        private set
    var shade = ByteArray(count)
        private set

    var dirty = IntArray(count)
        private set
    var dirtyCount = 0
        private set

    val changed: Boolean get() = dirtyCount > 0

    private var forceFull = true

    fun resize(newCols: Int, newRows: Int) {
        if (newCols == cols && newRows == rows) return
        cols = newCols
        rows = newRows
        val n = count
        level = FloatArray(n)
        tint = FloatArray(n)
        glyph = ByteArray(n)
        shade = ByteArray(n)
        dirty = IntArray(n)
        dirtyCount = 0
        forceFull = true
    }

    fun invalidate() {
        forceFull = true
    }

    fun clear() {
        java.util.Arrays.fill(level, 0f)
    }

    fun index(x: Int, y: Int): Int = y * cols + x

    fun inBounds(x: Int, y: Int): Boolean = x >= 0 && y >= 0 && x < cols && y < rows

    fun set(x: Int, y: Int, value: Float) {
        if (!inBounds(x, y)) return
        level[y * cols + x] = value
    }

    /** Смешивание "по максимуму". */
    fun max(x: Int, y: Int, value: Float, t: Float = -1f) {
        if (!inBounds(x, y)) return
        val i = y * cols + x
        if (value > level[i]) {
            level[i] = value
            if (t >= 0f) tint[i] = t
        }
    }

    /** Аддитивное смешивание с ограничением до 1. */
    fun add(x: Int, y: Int, value: Float) {
        if (!inBounds(x, y)) return
        val i = y * cols + x
        val v = level[i] + value
        level[i] = if (v > 1f) 1f else v
    }

    // ---- Контраст ----
    private val tone = FloatArray(256) { it / 255f }
    private var toneFor = 0.5f

    private fun rebuildTone(contrast: Float) {
        val k = (contrast - 0.5f) * 2f
        for (i in 1..255) {
            val v = i / 255f
            tone[i] = if (k >= 0f) {
                v + (v * v * (3f - 2f * v) - v) * k
            } else {
                v + ((0.35f + 0.65f * v) - v) * (-k)
            }
        }
        tone[0] = 0f
        toneFor = contrast
    }

    // ---- Свечение ----
    /**
     * Яркие ячейки подсвечивают соседей их цветом. Вызывать до commit().
     * Яркость ореола ограничена порогом GLOW_MIN, поэтому проход безопасен на месте.
     */
    fun applyGlow(amount: Float, cutoff: Float) {
        if (amount <= 0.01f) return
        val w = cols
        val h = rows
        val side = 0.34f * amount
        val vert = 0.22f * amount
        val span = 1f - cutoff
        val lim = GLOW_MIN - 0.01f
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val i = row + x
                val v = level[i]
                if (v < GLOW_MIN) continue
                val a = (v - GLOW_MIN) / (1f - GLOW_MIN)
                val t = tint[i]
                val hs = minOf(lim, cutoff + a * side * span)
                val vs = minOf(lim, cutoff + a * vert * span)
                if (x > 0) lift(i - 1, hs, t)
                if (x < w - 1) lift(i + 1, hs, t)
                if (y > 0) lift(i - w, vs, t)
                if (y < h - 1) lift(i + w, vs, t)
            }
        }
    }

    private fun lift(i: Int, v: Float, t: Float) {
        if (v > level[i]) {
            level[i] = v
            tint[i] = t
        }
    }

    /**
     * Яркость -> глиф и ступень. Возвращает число изменённых ячеек.
     * @param cutoff ниже этого порога ячейка пустая
     * @param brightness общий множитель яркости 0..2
     */
    fun commit(lut: IntArray, cutoff: Float, brightness: Float, contrast: Float = 0.5f): Int {
        if (contrast != toneFor) rebuildTone(contrast)
        var n = 0
        val c = cutoff
        val inv = if (c < 0.999f) 1f / (1f - c) else 1f
        for (i in 0 until count) {
            var v = level[i]
            v = if (v <= c) 0f else (v - c) * inv
            v *= brightness
            if (v > 1f) v = 1f
            v = tone[(v * 255f).toInt()]
            val g = lut[(v * 255f).toInt()].toByte()
            val s = if (v <= 0f) 0 else (1 + (v * (SHADES - 2)).toInt()).coerceAtMost(SHADES - 1)
            val sb = s.toByte()
            if (forceFull || g != glyph[i] || sb != shade[i]) {
                glyph[i] = g
                shade[i] = sb
                dirty[n++] = i
            }
        }
        forceFull = false
        dirtyCount = n
        return n
    }

    companion object {
        const val SHADES = 32
        /** Порог яркости, с которого ячейка светит на соседей. */
        const val GLOW_MIN = 0.7f
    }
}

package com.asciiwall.live.presets.underwater

import com.asciiwall.live.core.CellBuffer
import com.asciiwall.live.presets.Noise

/**
 * Живые объекты: пузырьки, планктон, рыбы, медузы.
 * Рисуется ПОСЛЕ UnderwaterLight (добавляет поверх через buf.max).
 */
class UnderwaterLife {

    private val tmp = FloatArray(2)

    fun update(s: UnderwaterState, light: UnderwaterLight, bgDt: Float, evDt: Float, time: Float) {
        val cols = s.cols.toFloat()
        val rows = s.rows.toFloat()
        val kickDecay = 1f - minOf(1f, 2.2f * evDt)

        // ---- Пузырьки ----
        for (i in 0 until s.bubbleCount) {
            val layer = s.bLayer[i].toInt()
            s.bVy[i] = minOf(s.bVy[i] + 0.9f * bgDt, 7f)
            s.by[i] -= s.bVy[i] * Depth.speed[layer] * bgDt
            s.bPhase[i] += bgDt * (1.6f + s.bSize[i])
            s.bx[i] += s.flowX * 0.25f * Depth.speed[layer] * bgDt
            if (s.bx[i] >= cols) s.bx[i] -= cols
            if (s.by[i] < 1.5f) s.spawnBubble(i, false)
        }

        // ---- Планктон ----
        for (i in 0 until s.planktonCount) {
            val layer = s.pLayer[i].toInt()
            light.flow(s, s.px[i], s.py[i], time, tmp)
            val sp = Depth.speed[layer] * 0.55f
            s.px[i] += tmp[0] * sp * bgDt
            s.py[i] += (tmp[1] * 0.6f + Noise.sin(time * 0.4f + s.pPhase[i]) * 0.12f) * sp * bgDt
            if (s.touching && layer >= Depth.MID) {
                val dx = s.px[i] - s.touchX
                val dy = s.py[i] - s.touchY
                val d = Noise.dist(dx, dy)
                if (d < 9f) {
                    val k = (1f - d / 9f) * 22f * evDt / (d + 0.3f)
                    s.px[i] += dx * k
                    s.py[i] += dy * k * 0.5f
                }
            }
            if (s.px[i] < 0f) s.px[i] += cols else if (s.px[i] >= cols) s.px[i] -= cols
            if (s.py[i] < 2f) s.py[i] += rows - 2f else if (s.py[i] >= rows) s.py[i] -= rows - 2f
        }

        // ---- Существа ----
        for (i in 0 until s.creatureCount) {
            val layer = s.cLayer[i].toInt()
            val spd = Depth.speed[layer]
            val jelly = s.cKind[i].toInt() == Kind.JELLY
            light.flow(s, s.cx[i], s.cy[i], time, tmp)

            if (s.touching) {
                val dx = s.cx[i] - s.touchX
                val dy = s.cy[i] - s.touchY
                val d = Noise.dist(dx, dy)
                if (d < 12f) {
                    val k = 1f - d / 12f
                    val inv = 1f / (d + 0.3f)
                    s.cKickX[i] += dx * inv * k * 34f * evDt + s.touchVx * k * 0.08f
                    s.cKickY[i] += dy * inv * k * 14f * evDt + s.touchVy * k * 0.04f
                }
            }

            val calmMul = 1f - 0.7f * s.calm
            var vx = s.cVx[i] * calmMul + tmp[0] * 0.4f * spd
            var vy = tmp[1] * 0.5f
            if (jelly) {
                s.cPhase[i] += bgDt * 2.2f * calmMul
                val c = Noise.cos(s.cPhase[i])
                vy += (if (c > 0f) c * 1.6f else 0f) - 0.45f
                vx += tmp[0] * 0.3f
            } else {
                s.cPhase[i] += bgDt * (4f + Math.abs(s.cVx[i]) * 2.2f) * calmMul
                vy += Noise.sin(time * 0.5f + s.cPhase[i] * 0.15f) * 0.35f
            }

            s.cx[i] += vx * bgDt + s.cKickX[i] * evDt
            s.cy[i] += vy * bgDt + s.cKickY[i] * evDt
            s.cKickX[i] *= kickDecay
            s.cKickY[i] *= kickDecay

            val minY = rows * 0.14f
            val maxY = rows * 0.92f
            if (s.cy[i] < minY) { s.cy[i] = minY; s.cKickY[i] = Math.abs(s.cKickY[i]) }
            if (s.cy[i] > maxY) { s.cy[i] = maxY; s.cKickY[i] = -Math.abs(s.cKickY[i]) }
            if (s.cx[i] < -14f || s.cx[i] > cols + 14f) s.spawnCreature(i, false)
        }
    }

    /** Импульс от точки (разблокировка, капля): отталкивает существ и планктон. */
    fun pushFrom(s: UnderwaterState, x: Float, y: Float, radius: Float, strength: Float) {
        for (i in 0 until s.creatureCount) {
            val dx = s.cx[i] - x
            val dy = s.cy[i] - y
            val d = Noise.dist(dx, dy)
            if (d < radius) {
                val k = (1f - d / radius) * strength / (d + 0.5f)
                s.cKickX[i] += dx * k
                s.cKickY[i] += dy * k * 0.5f
            }
        }
        for (i in 0 until s.planktonCount) {
            val dx = s.px[i] - x
            val dy = s.py[i] - y
            val d = Noise.dist(dx, dy)
            if (d < radius) {
                val k = (1f - d / radius) * strength * 0.05f / (d + 0.5f)
                s.px[i] += dx * k
                s.py[i] += dy * k * 0.5f
            }
        }
    }

    fun draw(s: UnderwaterState, buf: CellBuffer, time: Float) {
        val cols = buf.cols
        val rows = buf.rows
        val lightMul = (1f + s.flash * 0.5f) * (1f - s.dark * 0.85f)
        val colsF = cols.toFloat()
        val rowsF = rows.toFloat()

        // ---- Планктон ----
        for (i in 0 until s.planktonCount) {
            val layer = s.pLayer[i].toInt()
            var x = s.px[i] + s.shift * colsF * Depth.parallax[layer]
            x = wrap(x, colsF)
            val y = s.py[i]
            val tw = 0.5f + 0.5f * Noise.sin(time * 1.3f + s.pPhase[i])
            val v = (0.12f + 0.30f * tw) * Depth.brightness[layer] *
                (1f - 0.45f * (y / rowsF)) * lightMul
            buf.max(x.toInt(), y.toInt(), v, 0.55f)
        }

        // ---- Пузырьки ----
        for (i in 0 until s.bubbleCount) {
            val layer = s.bLayer[i].toInt()
            val sway = Noise.sin(s.bPhase[i]) * (0.5f + s.bSize[i]) * 0.9f
            val x = wrap(s.bx[i] + sway + s.shift * colsF * Depth.parallax[layer], colsF)
            val y = s.by[i]
            if (y < 0f || y >= rowsF) continue
            val fade = Noise.smooth(1.5f, 6f, y)
            val v = (0.45f + 0.5f * s.bSize[i]) * Depth.brightness[layer] * fade * lightMul
            buf.max(x.toInt(), y.toInt(), v, 0.85f)
        }

        // ---- Существа ----
        for (i in 0 until s.creatureCount) {
            val layer = s.cLayer[i].toInt()
            val x = s.cx[i] + s.shift * colsF * Depth.parallax[layer]
            val y = s.cy[i]
            val bright = Depth.brightness[layer] * lightMul
            if (s.cKind[i].toInt() == Kind.JELLY) {
                drawJelly(buf, x, y, s.cScale[i], s.cPhase[i], bright)
            } else {
                val dir = if (s.cVx[i] >= 0f) 1f else -1f
                drawFish(buf, x, y, dir, s.cScale[i], s.cPhase[i], bright)
            }
        }
    }

    private fun drawFish(buf: CellBuffer, x: Float, y: Float, dir: Float, scale: Float, phase: Float, bright: Float) {
        val len = (4f + scale * 3.2f).toInt().coerceIn(4, 11)
        val lenF = (len - 1).toFloat()
        val fat = scale > 1.0f
        for (k in 0 until len) {
            val u = k / lenF
            val xx = Math.round(x + (k - lenF) * dir)
            val inv = 1f - u
            val yc = y + inv * inv * Noise.sin(phase) * 1.1f
            val yy = Math.round(yc)
            val v = bright * (0.35f + 0.65f * u)
            buf.max(xx, yy, if (k == len - 1) bright else v, 0.78f)
            if (fat && u in 0.3f..0.85f) {
                buf.max(xx, yy + 1, v * 0.6f, 0.7f)
                buf.max(xx, yy - 1, v * 0.35f, 0.7f)
            }
            if (k == 0) {
                buf.max(xx, yy + 1, bright * 0.5f, 0.7f)
                buf.max(xx, yy - 1, bright * 0.5f, 0.7f)
            }
        }
    }

    private fun drawJelly(buf: CellBuffer, x: Float, y: Float, scale: Float, phase: Float, bright: Float) {
        val pulse = 1f + 0.18f * Noise.sin(phase)
        val w = (2.2f + scale * 2.0f) * pulse
        val bell = if (scale > 1.3f) 3 else 2
        for (r in 0 until bell) {
            val hw = w * (0.55f + 0.45f * r / (bell - 1).toFloat())
            val n = hw.toInt()
            for (dx in -n..n) {
                val edge = Math.abs(dx) / (hw + 0.01f)
                val v = bright * (0.95f - 0.35f * edge)
                buf.max(Math.round(x) + dx, Math.round(y) + r, v, 0.9f)
            }
        }
        val nt = 4
        val tl = 3f + scale * 2.5f
        val base = y + bell - 1
        for (t in 0 until nt) {
            val tx = x + (t / (nt - 1f) - 0.5f) * 2f * w * 0.8f
            val steps = tl.toInt()
            for (j in 1..steps) {
                val f = j / tl
                val xx = tx + Noise.sin(phase * 0.6f - j * 0.7f + t) * 0.9f * f
                buf.max(Math.round(xx), Math.round(base + j), bright * 0.45f * (1f - f), 0.8f)
            }
        }
    }

    private fun wrap(v: Float, max: Float): Float {
        var r = v
        while (r < 0f) r += max
        while (r >= max) r -= max
        return r
    }
}

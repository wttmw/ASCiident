package com.asciiwall.live.presets

import com.asciiwall.live.core.CellBuffer
import com.asciiwall.live.image.ImageSettings

/** Параметры сцены, общие для всех пресетов. Меняются из UI без пересоздания пресета. */
class SceneParams {
    @Volatile var cutoff: Float = 0.12f
    @Volatile var bgSpeed: Float = 1f
    @Volatile var eventSpeed: Float = 1f
    @Volatile var parallaxSpeed: Float = 1f
    @Volatile var flicker: Float = 0f
    @Volatile var noise: Float = 0f

    /** Для пресета "image": настройки картинки, пропорции ячейки, число глифов в атласе. */
    @Volatile var image: ImageSettings = ImageSettings()
    @Volatile var cellAspect: Float = 1.9f
    @Volatile var glyphLevels: Int = 10
}

/** Действие касания. */
object TouchAction {
    const val DOWN = 0
    const val MOVE = 1
    const val UP = 2
}

/**
 * Базовый класс пресета.
 * Жизненный цикл: onSizeChanged -> (update -> draw)*, события приходят между кадрами.
 * Правила: никаких аллокаций в update/draw, все массивы создаются в onSizeChanged.
 */
abstract class Preset {

    abstract val id: String
    abstract val nameRes: Int
    abstract val descRes: Int

    var params: SceneParams = SceneParams()

    protected var cols = 0
    protected var rows = 0

    open fun onSizeChanged(cols: Int, rows: Int) {
        this.cols = cols
        this.rows = rows
    }

    abstract fun update(dt: Float, time: Float)

    abstract fun draw(buffer: CellBuffer)

    open fun onTouch(nx: Float, ny: Float, action: Int) {}

    open fun onUnlock() {}

    open fun onLock() {}

    open fun onScroll(offset: Float, velocity: Float) {}

    open fun onVisibility(visible: Boolean) {}

    open fun release() {}

    protected fun bg(dt: Float): Float = dt * params.bgSpeed
    protected fun ev(dt: Float): Float = dt * params.eventSpeed
    protected fun px(dt: Float): Float = dt * params.parallaxSpeed

    /** Применяет общие эффекты (мерцание, шум) к яркости ячейки. */
    protected fun fx(level: Float, flickerNoise: Float): Float {
        var v = level
        if (params.flicker > 0f) v *= 1f - params.flicker * flickerNoise
        if (params.noise > 0f) v += params.noise * (flickerNoise - 0.5f) * 0.3f
        return if (v < 0f) 0f else if (v > 1f) 1f else v
    }
}

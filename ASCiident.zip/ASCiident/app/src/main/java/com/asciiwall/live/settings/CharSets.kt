package com.asciiwall.live.settings

import com.asciiwall.live.engine.EngineConfig

/**
 * Наборы символов. Порядок внутри набора не важен: GlyphAtlas сам сортирует глифы
 * по реальной плотности и ставит пробел первым. Метки моноширинные, не переводятся.
 */
object CharSets {

    const val CUSTOM_ID = "custom"
    const val DEFAULT_ID = "classic"

    const val MAX_CHARS = 255

    class Set(val id: String, val label: String, val chars: String)

    val presets: List<Set> = listOf(
        Set("classic", "CLASSIC", " .:-=+*#%@"),
        Set("fine", "FINE", " .'`^\",:;Il!i><~+_-?][}{1)(|/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@\$"),
        Set("lines", "LINES", " .-~=/\\|+#"),
        Set("dots", "DOTS", " .,:;oO0@"),
        Set("binary", "BINARY", " 01"),
        Set("matrix", "MATRIX", " .:+*=<>|/\\0123456789ZXW"),
        Set("waves", "WAVES", " .,~-=^*"),
        Set("blocks", "BLOCKS", " ░▒▓█"),
        Set("braille", "BRAILLE", " ⠁⠃⠇⠏⠟⠿⡿⣿")
    )

    fun resolve(id: String, custom: String): String {
        if (id == CUSTOM_ID) return sanitize(custom)
        return (presets.firstOrNull { it.id == id } ?: presets[0]).chars
    }

    /** Чистит ввод: убирает управляющие, пробелы, суррогаты, повторы; добавляет пробел первым. */
    fun sanitize(input: String): String {
        val set = LinkedHashSet<Char>()
        for (ch in input) {
            if (ch.isISOControl() || ch.isWhitespace()) continue
            if (Character.isSurrogate(ch)) continue
            set.add(ch)
            if (set.size >= MAX_CHARS) break
        }
        if (set.size < 2) return presets[0].chars
        return " " + set.joinToString("")
    }

    fun count(input: String): Int = sanitize(input).length - 1

    fun apply(c: EngineConfig, id: String, custom: String): EngineConfig =
        c.copy(chars = resolve(id, custom))
}

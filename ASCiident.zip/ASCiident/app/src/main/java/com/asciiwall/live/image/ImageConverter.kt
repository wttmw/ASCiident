package com.asciiwall.live.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Источник картинки: грузит и кэширует один декодированный Bitmap на процесс.
 * Декодирование идёт в фоновом потоке, поток рендера только читает [bitmap] и [version].
 */
object ImageSource {

    const val MAX_SIDE = 1024

    private var appContext: Context? = null
    private val exec = Executors.newSingleThreadExecutor { r ->
        Thread(r, "ascii-image").apply { isDaemon = true; priority = Thread.MIN_PRIORITY }
    }

    @Volatile var bitmap: Bitmap? = null
        private set
    @Volatile var version = 0
        private set
    @Volatile var failed = false
        private set
    @Volatile private var wanted = ""

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun request(uri: String) {
        if (uri == wanted) return
        wanted = uri
        val ctx = appContext
        if (uri.isEmpty() || ctx == null) {
            bitmap = null
            failed = false
            version++
            return
        }
        exec.execute {
            val b = ImageDecode.decode(ctx, uri, MAX_SIDE)
            if (uri == wanted) {
                bitmap = b
                failed = b == null
                version++
            } else {
                b?.recycle()
            }
        }
    }
}

/** Декодирование с уменьшением до [maxSide] и учётом EXIF-поворота (Android 9+). */
object ImageDecode {

    private fun toUri(s: String): Uri {
        val u = Uri.parse(s)
        return if (u.scheme.isNullOrEmpty()) Uri.fromFile(File(s)) else u
    }

    fun decode(ctx: Context, s: String, maxSide: Int): Bitmap? = try {
        val uri = toUri(s)
        if (Build.VERSION.SDK_INT >= 28) {
            val src = ImageDecoder.createSource(ctx.contentResolver, uri)
            ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width
                val h = info.size.height
                val big = max(w, h)
                if (big > maxSide) {
                    val k = maxSide.toFloat() / big
                    dec.setTargetSize((w * k).toInt().coerceAtLeast(1), (h * k).toInt().coerceAtLeast(1))
                }
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        }
    } catch (e: Exception) {
        null
    } catch (e: OutOfMemoryError) {
        null
    }
}

/**
 * Конвертер картинка -> яркости сетки. Не thread-safe: один экземпляр на пресет.
 * Пайплайн: площадное усреднение по ячейкам -> контуры -> инверсия, гамма, контраст,
 * порог, плотность -> дизеринг -> level (с маской покрытия) и tint.
 */
class ImageConverter {

    private var srcRef: Bitmap? = null
    private var sw = 0
    private var sh = 0
    private var lum = ByteArray(0)
    private var alpha = ByteArray(0)
    private var tone = FloatArray(0)
    private var cover = FloatArray(0)
    private var tmp = FloatArray(0)

    fun convert(
        b: Bitmap, s: ImageSettings, cols: Int, rows: Int, cellAspect: Float, levels: Int,
        level: FloatArray, tint: FloatArray
    ) {
        val n = cols * rows
        if (n <= 0 || level.size < n || tint.size < n) return
        if (b !== srcRef) prepare(b)
        if (sw <= 0 || sh <= 0) return
        if (tone.size != n) {
            tone = FloatArray(n); cover = FloatArray(n); tmp = FloatArray(n)
        }

        val fx = cols.toFloat() / sw
        val fy = rows * cellAspect / sh
        val p = if (s.fit == ImageFit.COVER) max(fx, fy) else min(fx, fy)
        val kx = p
        val ky = p / cellAspect
        val left = (cols - sw * kx) / 2f
        val top = (rows - sh * ky) / 2f
        val invKx = 1f / kx
        val invKy = 1f / ky

        // 1. Площадное усреднение яркости (с весом альфы) и покрытие.
        for (y in 0 until rows) {
            val y0f = (y - top) * invKy
            val y1f = (y + 1 - top) * invKy
            val y0 = max(0, floor(y0f).toInt())
            val y1 = min(sh, ceil(y1f).toInt())
            val clipH = (min(y1f, sh.toFloat()) - max(y0f, 0f)).coerceAtLeast(0f) / (y1f - y0f)
            for (x in 0 until cols) {
                val i = y * cols + x
                val x0f = (x - left) * invKx
                val x1f = (x + 1 - left) * invKx
                val x0 = max(0, floor(x0f).toInt())
                val x1 = min(sw, ceil(x1f).toInt())
                if (x1 <= x0 || y1 <= y0) {
                    tone[i] = 0f; cover[i] = 0f
                    continue
                }
                var sum = 0L
                var asum = 0L
                for (yy in y0 until y1) {
                    val row = yy * sw
                    for (xx in x0 until x1) {
                        val a = alpha[row + xx].toInt() and 255
                        sum += (lum[row + xx].toInt() and 255) * a
                        asum += a
                    }
                }
                val cnt = (x1 - x0) * (y1 - y0)
                val clipW = (min(x1f, sw.toFloat()) - max(x0f, 0f)).coerceAtLeast(0f) / (x1f - x0f)
                cover[i] = (asum / (255f * cnt)) * clipW * clipH
                tone[i] = if (asum > 0L) sum / (255f * asum) else 0f
            }
        }

        // 2. Усиление контуров (нерезкая маска по 4 соседям).
        if (s.sharpen > 0.01f) {
            System.arraycopy(tone, 0, tmp, 0, n)
            val k = s.sharpen * 1.6f
            for (y in 1 until rows - 1) {
                for (x in 1 until cols - 1) {
                    val i = y * cols + x
                    val avg = (tmp[i - 1] + tmp[i + 1] + tmp[i - cols] + tmp[i + cols]) * 0.25f
                    tone[i] = (tmp[i] + (tmp[i] - avg) * k).coerceIn(0f, 1f)
                }
            }
        }

        // 3. Тоновая кривая: инверсия -> гамма -> контраст -> порог -> плотность.
        val ck = (s.contrast - 0.5f) * 2f
        val th = s.threshold
        val thInv = 1f / (1f - th)
        for (i in 0 until n) {
            var v = tone[i]
            if (s.invert) v = 1f - v
            if (s.gamma != 1f) v = v.pow(s.gamma)
            v = if (ck >= 0f) v + (v * v * (3f - 2f * v) - v) * ck
            else v + ((0.35f + 0.65f * v) - v) * (-ck)
            v = if (v <= th) 0f else (v - th) * thInv
            tone[i] = (v * s.density).coerceIn(0f, 1f)
        }

        // 4. Дизеринг.
        val steps = (max(2, levels) - 1).toFloat()
        when (s.dither) {
            Dither.NONE -> {}
            Dither.BAYER -> for (y in 0 until rows) {
                for (x in 0 until cols) {
                    val i = y * cols + x
                    val thr = (BAYER[(y and 3) * 4 + (x and 3)] + 0.5f) / 16f - 0.5f
                    tone[i] = ((tone[i] * steps + thr).roundToInt() / steps).coerceIn(0f, 1f)
                }
            }
            Dither.FLOYD -> for (y in 0 until rows) {
                for (x in 0 until cols) {
                    val i = y * cols + x
                    val old = tone[i]
                    val q = ((old * steps).roundToInt() / steps).coerceIn(0f, 1f)
                    val err = old - q
                    tone[i] = q
                    if (x + 1 < cols) tone[i + 1] += err * 0.4375f
                    if (y + 1 < rows) {
                        if (x > 0) tone[i + cols - 1] += err * 0.1875f
                        tone[i + cols] += err * 0.3125f
                        if (x + 1 < cols) tone[i + cols + 1] += err * 0.0625f
                    }
                }
            }
        }

        // 5. Результат: яркость с маской покрытия, тон идёт в градиент.
        for (i in 0 until n) {
            val v = tone[i].coerceIn(0f, 1f)
            level[i] = v * cover[i]
            tint[i] = v
        }
    }

    private fun prepare(b: Bitmap) {
        srcRef = b
        sw = b.width
        sh = b.height
        val px = IntArray(sw * sh)
        b.getPixels(px, 0, sw, 0, 0, sw, sh)
        lum = ByteArray(px.size)
        alpha = ByteArray(px.size)
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val bl = c and 255
            lum[i] = ((r * 77 + g * 150 + bl * 29) shr 8).toByte()
            alpha[i] = (c ushr 24).toByte()
        }
    }

    private companion object {
        val BAYER = intArrayOf(
            0, 8, 2, 10,
            12, 4, 14, 6,
            3, 11, 1, 9,
            15, 7, 13, 5
        )
    }
}

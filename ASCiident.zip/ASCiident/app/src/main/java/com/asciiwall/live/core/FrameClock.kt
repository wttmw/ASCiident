package com.asciiwall.live.core

import android.os.SystemClock

/**
 * Часы кадров. Даёт dt с учётом множителя скорости, ограничивает скачки
 * и считает реальный FPS. Без аллокаций.
 */
class FrameClock {

    var time: Float = 0f
        private set

    var dt: Float = 0f
        private set

    var rawDt: Float = 0f
        private set

    var speed: Float = 1f
        set(value) { field = value.coerceIn(0f, MAX_SPEED) }

    var measuredFps: Float = 0f
        private set

    private var lastNanos = 0L
    private var fpsAccum = 0f
    private var fpsFrames = 0

    val frozen: Boolean get() = speed <= 0f

    fun reset() {
        lastNanos = 0L
        dt = 0f
        rawDt = 0f
    }

    fun tick(minIntervalNanos: Long): Boolean {
        val now = SystemClock.elapsedRealtimeNanos()
        if (lastNanos == 0L) {
            lastNanos = now
            return true
        }
        val elapsed = now - lastNanos
        if (elapsed < minIntervalNanos - minIntervalNanos / 10) return false

        lastNanos = now
        var real = elapsed / 1_000_000_000f
        if (real > MAX_DT) real = MAX_DT
        rawDt = real
        dt = real * speed
        time += dt

        fpsAccum += real
        fpsFrames++
        if (fpsAccum >= 0.5f) {
            val fps = fpsFrames / fpsAccum
            measuredFps = if (measuredFps == 0f) fps else measuredFps * 0.5f + fps * 0.5f
            fpsAccum = 0f
            fpsFrames = 0
        }
        return true
    }

    fun delayMillis(minIntervalNanos: Long): Long {
        if (lastNanos == 0L) return 0L
        val left = minIntervalNanos - (SystemClock.elapsedRealtimeNanos() - lastNanos)
        return if (left <= 0L) 0L else left / 1_000_000L
    }

    companion object {
        const val MAX_SPEED = 3f
        const val MAX_DT = 0.1f
    }
}

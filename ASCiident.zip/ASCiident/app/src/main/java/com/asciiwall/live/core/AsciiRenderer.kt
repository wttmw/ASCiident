package com.asciiwall.live.core

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import kotlin.math.ceil

/**
 * Рендер сетки. Рисует только изменённые ячейки в офскрин-битмап,
 * на экран выводится один drawBitmap за кадр.
 */
class AsciiRenderer {

    var buffer = CellBuffer(1, 1)
        private set
    var atlas: GlyphAtlas? = null
        private set

    private var frame: Bitmap? = null
    private var frameCanvas: Canvas? = null
    private var width = 0
    private var height = 0

    private var chars = ""
    private var typeface: Typeface = Typeface.MONOSPACE
    private var gridKey = 0

    private var background = Color.BLACK
    private var stops = intArrayOf(Color.WHITE)
    private val palette = IntArray(TINT_STEPS * CellBuffer.SHADES)

    private val glyphPaint = Paint().apply {
        isAntiAlias = false
        isFilterBitmap = false
    }
    private val bgPaint = Paint().apply { style = Paint.Style.FILL }
    private val blitPaint = Paint().apply { isFilterBitmap = false }
    private val src = Rect()
    private val dst = Rect()

    var needsDraw = true
        private set

    init {
        rebuildPalette()
    }

    fun configure(
        surfaceW: Int,
        surfaceH: Int,
        grid: GridConfig,
        newChars: String,
        newTypeface: Typeface = Typeface.MONOSPACE
    ) {
        if (surfaceW <= 0 || surfaceH <= 0) return
        val rows = grid.resolveRows(surfaceW, surfaceH)
        val cols = grid.columns
        val cw = ceil(grid.cellWidth(surfaceW)).toInt().coerceAtLeast(4)
        val ch = ceil(cw * grid.cellAspect).toInt().coerceAtLeast(6)

        val key = (cols * 31 + rows) * 31 + cw * 7 + ch
        val sizeChanged = surfaceW != width || surfaceH != height
        val atlasChanged = atlas == null || key != gridKey ||
            newChars != chars || newTypeface !== typeface

        if (sizeChanged) {
            frame?.recycle()
            frame = Bitmap.createBitmap(surfaceW, surfaceH, Bitmap.Config.ARGB_8888)
            frameCanvas = Canvas(frame!!)
            width = surfaceW
            height = surfaceH
        }
        if (atlasChanged) {
            atlas?.recycle()
            atlas = GlyphAtlas.build(newChars, cw, ch, newTypeface)
            chars = newChars
            typeface = newTypeface
            gridKey = key
        }
        buffer.resize(cols, rows)
        buffer.invalidate()
        clearFrame()
    }

    fun setStyle(gradientStops: IntArray, backgroundColor: Int) {
        stops = if (gradientStops.isEmpty()) intArrayOf(Color.WHITE) else gradientStops.copyOf()
        background = backgroundColor
        rebuildPalette()
        buffer.invalidate()
        clearFrame()
    }

    fun render(cutoff: Float, brightness: Float, contrast: Float = 0.5f, glow: Float = 0f): Boolean {
        val a = atlas ?: return false
        val f = frameCanvas ?: return false
        buffer.applyGlow(glow, cutoff)
        val n = buffer.commit(a.lut, cutoff, brightness, contrast)
        if (n == 0) return false

        val cols = buffer.cols
        val rows = buffer.rows
        val dirty = buffer.dirty
        val glyph = buffer.glyph
        val shade = buffer.shade
        val tint = buffer.tint
        val maxT = TINT_STEPS - 1
        val shades = CellBuffer.SHADES

        bgPaint.color = background
        for (k in 0 until n) {
            val i = dirty[k]
            val x = i % cols
            val y = i / cols
            dst.set(x * width / cols, y * height / rows, (x + 1) * width / cols, (y + 1) * height / rows)
            f.drawRect(dst, bgPaint)

            val s = shade[i].toInt()
            if (s == 0) continue
            val g = glyph[i].toInt() and 0xFF
            if (g == 0) continue

            var t = (tint[i] * maxT + 0.5f).toInt()
            if (t < 0) t = 0 else if (t > maxT) t = maxT
            glyphPaint.color = palette[t * shades + s]

            val l = a.srcLeft(g)
            val tp = a.srcTop(g)
            src.set(l, tp, l + a.cellW, tp + a.cellH)
            f.drawBitmap(a.bitmap, src, dst, glyphPaint)
        }
        needsDraw = true
        return true
    }

    fun draw(canvas: Canvas, dx: Float = 0f, dy: Float = 0f) {
        val b = frame ?: return
        if (dx != 0f || dy != 0f) {
            canvas.drawColor(background)
            canvas.drawBitmap(b, dx, dy, blitPaint)
        } else {
            canvas.drawBitmap(b, 0f, 0f, blitPaint)
        }
        needsDraw = false
    }

    fun release() {
        frame?.recycle()
        frame = null
        frameCanvas = null
        atlas?.recycle()
        atlas = null
        width = 0
        height = 0
        gridKey = 0
    }

    private fun clearFrame() {
        frameCanvas?.drawColor(background)
        needsDraw = true
    }

    private fun rebuildPalette() {
        val shades = CellBuffer.SHADES
        val bgR = Color.red(background)
        val bgG = Color.green(background)
        val bgB = Color.blue(background)
        for (t in 0 until TINT_STEPS) {
            val base = gradientAt(t / (TINT_STEPS - 1f))
            val r = Color.red(base)
            val g = Color.green(base)
            val b = Color.blue(base)
            for (s in 0 until shades) {
                val k = s / (shades - 1f)
                palette[t * shades + s] = Color.rgb(
                    (bgR + (r - bgR) * k).toInt(),
                    (bgG + (g - bgG) * k).toInt(),
                    (bgB + (b - bgB) * k).toInt()
                )
            }
        }
    }

    private fun gradientAt(p: Float): Int {
        if (stops.size == 1) return stops[0]
        val scaled = p.coerceIn(0f, 1f) * (stops.size - 1)
        val i = scaled.toInt().coerceAtMost(stops.size - 2)
        val f = scaled - i
        val a = stops[i]
        val b = stops[i + 1]
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt()
        )
    }

    companion object {
        const val TINT_STEPS = 16
    }
}

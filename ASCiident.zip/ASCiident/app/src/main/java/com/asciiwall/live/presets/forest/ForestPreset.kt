package com.asciiwall.live.presets.forest

import com.asciiwall.live.R
import com.asciiwall.live.core.CellBuffer
import com.asciiwall.live.presets.Noise
import com.asciiwall.live.presets.Preset
import com.asciiwall.live.presets.TouchAction
import com.asciiwall.live.presets.shapes.Raster
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Хвойный лес: 4 слоя елей, туман полосами, луна, снег, светлячки.
 * Глубина только через яркость. Деревья рисуются перезаписью (ближние перекрывают дальние).
 */
class ForestPreset : Preset() {

    override val id = "forest"
    override val nameRes = R.string.preset_forest
    override val descRes = R.string.preset_forest_desc

    private val layerStart = IntArray(5)
    private val layerW = FloatArray(4)
    private val layerPad = FloatArray(4)
    private var tX = FloatArray(0)
    private var tBase = FloatArray(0)
    private var tH = FloatArray(0)
    private var tW = FloatArray(0)
    private var tPh = FloatArray(0)
    private var tShake = FloatArray(0)
    private var tTier = ByteArray(0)
    private var tL = ByteArray(0)
    private var tSeed = IntArray(0)

    private var snowCount = 0
    private var snX = FloatArray(0)
    private var snY = FloatArray(0)
    private var snPh = FloatArray(0)
    private var snV = FloatArray(0)
    private var snL = ByteArray(0)

    private var ffCount = 0
    private var ffX = FloatArray(0)
    private var ffY = FloatArray(0)
    private var ffPh = FloatArray(0)

    private var fogX = FloatArray(0)
    private var fogY = FloatArray(0)

    private var lastTime = 0f
    private var wind = 0f
    private var gust = 0f
    private var lift = 0f
    private var ffBoost = 0f
    private var flash = 0f
    private var dark = 0f
    private var darkTarget = 0f
    private var calm = 0f
    private var calmTarget = 0f
    private var scrollOffset = 0f
    private var scrollVel = 0f
    private var shift = 0f
    private var touching = false
    private var touchX = 0f
    private var touchY = 0f
    private var bend = 0f

    override fun onSizeChanged(cols: Int, rows: Int) {
        super.onSizeChanged(cols, rows)
        val c = cols.toFloat()
        val r = rows.toFloat()

        var total = 0
        for (l in 0 until 4) {
            layerStart[l] = total
            total += max(2, (c * DENS[l]).toInt())
        }
        layerStart[4] = total
        tX = FloatArray(total); tBase = FloatArray(total); tH = FloatArray(total)
        tW = FloatArray(total); tPh = FloatArray(total); tShake = FloatArray(total)
        tTier = ByteArray(total); tL = ByteArray(total); tSeed = IntArray(total)

        for (l in 0 until 4) {
            val pad = W[l] * c * 1.4f + 3f
            layerPad[l] = pad
            layerW[l] = c + 2f * pad
            val cnt = layerStart[l + 1] - layerStart[l]
            for (k in 0 until cnt) {
                val i = layerStart[l] + k
                val seed = i * 37 + 11
                val sc = 0.8f + 0.4f * Noise.hash(seed)
                tH[i] = H[l] * r * sc
                tW[i] = max(1.5f, W[l] * c * sc)
                tX[i] = (k + 0.15f + 0.7f * Noise.hash(seed + 1)) / cnt * layerW[l]
                tBase[i] = BASE[l] * r + (Noise.hash(seed + 2) - 0.5f) * r * 0.03f
                tPh[i] = Noise.hash(seed + 3) * 6.2832f
                tTier[i] = (tH[i] / 7f).toInt().coerceIn(3, 8).toByte()
                tL[i] = l.toByte()
                tSeed[i] = seed
            }
        }

        snowCount = (cols * rows / 45).coerceIn(40, 220)
        snX = FloatArray(snowCount); snY = FloatArray(snowCount)
        snPh = FloatArray(snowCount); snV = FloatArray(snowCount)
        snL = ByteArray(snowCount)
        for (i in 0 until snowCount) {
            snX[i] = Noise.hash(i * 3 + 1) * c
            snY[i] = Noise.hash(i * 3 + 2) * r
            snPh[i] = Noise.hash(i * 3 + 3) * 6.2832f
            val q = Noise.hash(i * 7 + 5)
            val l = if (q < 0.35f) 0 else if (q < 0.65f) 1 else if (q < 0.88f) 2 else 3
            snL[i] = l.toByte()
            snV[i] = (1.1f + 0.8f * l) * (0.8f + 0.4f * Noise.hash(i * 7 + 9))
        }

        ffCount = (cols / 6).coerceIn(6, 16)
        ffX = FloatArray(ffCount); ffY = FloatArray(ffCount); ffPh = FloatArray(ffCount)
        for (i in 0 until ffCount) {
            ffX[i] = Noise.hash(i * 5 + 1) * c
            ffY[i] = r * (0.45f + 0.45f * Noise.hash(i * 5 + 2))
            ffPh[i] = Noise.hash(i * 5 + 3) * 6.2832f
        }

        fogX = FloatArray(cols)
        fogY = FloatArray(rows)

        wind = 0f; gust = 0f; lift = 0f; ffBoost = 0f; flash = 0f
        dark = 0f; darkTarget = 0f; calm = 0f; calmTarget = 0f
        touching = false; bend = 0f
    }

    override fun update(dt: Float, time: Float) {
        if (cols == 0) return
        lastTime = time
        val bgDt = bg(dt)
        val evDt = ev(dt)
        val pxDt = px(dt)
        val c = cols.toFloat()
        val r = rows.toFloat()

        val darkRate = if (darkTarget > dark) 1.1f else 3.2f
        dark += (darkTarget - dark) * min(1f, darkRate * evDt)
        calm += (calmTarget - calm) * min(1f, 1.4f * evDt)
        if (flash > 0.001f) flash *= 1f - min(1f, 1.6f * evDt) else flash = 0f
        gust *= 1f - min(1f, 1.1f * evDt)
        lift *= 1f - min(1f, 0.9f * evDt)
        ffBoost *= 1f - min(1f, 1.0f * evDt)
        bend += ((if (touching) 1f else 0f) - bend) * min(1f, 6f * evDt)
        for (i in 0 until tShake.size) tShake[i] *= 1f - min(1f, 1.8f * evDt)

        scrollVel *= 1f - min(1f, 3f * pxDt)
        val shiftTarget = -(scrollOffset - 0.5f) * 0.8f
        shift += (shiftTarget - shift) * min(1f, 5f * pxDt)
        val swipe = (-scrollVel * 3f).coerceIn(-2.5f, 2.5f)

        val base = (Noise.noise2(time * 0.07f, 3.3f) - 0.35f) * 1.3f * (1f - 0.85f * calm)
        wind += (base + gust + swipe - wind) * min(1f, 2f * bgDt)
        wind = wind.coerceIn(-4f, 4f)

        // ---- Снег ----
        val fall = 1f - 0.55f * calm
        for (i in 0 until snowCount) {
            val l = snL[i].toInt()
            snY[i] += (snV[i] * fall - lift * (0.6f + 0.2f * l)) * bgDt
            snX[i] += (wind * 1.6f * SNOW_SP[l] + Noise.sin(time * 0.8f + snPh[i]) * 0.7f) * bgDt
            if (touching) {
                val dx = snX[i] - touchX
                val dy = snY[i] - touchY
                val d = Noise.dist(dx, dy)
                if (d < 10f) {
                    val k = (1f - d / 10f) * bend * 2f * evDt
                    snX[i] += -dy * 1.9f * k
                    snY[i] += dx / 1.9f * k
                }
            }
            if (snX[i] >= c) snX[i] -= c else if (snX[i] < 0f) snX[i] += c
            if (snY[i] >= r) {
                snY[i] -= r
                snX[i] = Noise.hash(i * 7 + (time * 3f).toInt()) * c
            } else if (snY[i] < 0f) snY[i] += r
        }

        // ---- Светлячки ----
        val t = time * 0.25f
        val minY = r * 0.40f
        val maxY = r * 0.92f
        for (i in 0 until ffCount) {
            ffX[i] += (Noise.noise2(i * 5.3f + t, 1.7f) - 0.5f) * 5f * bgDt
            ffY[i] += (Noise.noise2(i * 3.1f + 9f, t + 4.2f) - 0.5f) * 3f * bgDt
            if (touching && bend > 0.05f) {
                val d = Noise.dist(touchX - ffX[i], touchY - ffY[i])
                if (d < 16f) {
                    ffX[i] += (touchX - ffX[i]) * 0.9f * evDt * bend
                    ffY[i] += (touchY - ffY[i]) * 0.9f * evDt * bend
                }
            }
            if (ffX[i] >= c) ffX[i] -= c else if (ffX[i] < 0f) ffX[i] += c
            ffY[i] = ffY[i].coerceIn(minY, maxY)
        }
    }

    override fun draw(buffer: CellBuffer) {
        if (cols == 0) return
        buffer.clear()
        val lm = (1f + flash * 0.5f) * (1f - dark * 0.85f)

        computeFog()
        drawMist(buffer, lm)
        drawSky(buffer, lm)

        for (l in 0 until 4) {
            for (i in layerStart[l] until layerStart[l + 1]) drawTree(buffer, i, lm)
            if (l < 3) {
                applyFog(buffer, l)
                if (l == 2) drawGround(buffer, lm)
            }
        }

        drawSnow(buffer, lm)
        drawFireflies(buffer, lm)

        if (touching) {
            val tx = touchX.toInt()
            val ty = touchY.toInt()
            for (dy in -1..1) for (dx in -3..3) {
                val d = Noise.dist(dx / 1.9f, dy.toFloat(), 1f)
                val v = 0.5f * (1f - d / 2.2f)
                if (v > 0f) buffer.max(tx + dx, ty + dy, v, 0.9f)
            }
        }

        if (params.flicker > 0f || params.noise > 0f) {
            val step = (lastTime * 8f).toInt() * 131
            val level = buffer.level
            for (y in 0 until rows) {
                for (x in 0 until cols) {
                    val i = y * cols + x
                    val v = level[i]
                    if (v <= 0f) continue
                    level[i] = fx(v, Noise.hash2(x + step, y))
                }
            }
        }
    }

    // ---------------- Туман ----------------

    private fun computeFog() {
        val t = lastTime
        val rowsF = rows.toFloat()
        for (y in 0 until rows) {
            val b = 1f - abs(y / rowsF - 0.74f) / 0.30f
            fogY[y] = if (b > 0f) b * b * (0.65f + 0.35f * Noise.noise2(y * 0.21f, t * 0.05f)) else 0f
        }
        val sh = shift * cols * 0.05f
        for (x in 0 until cols) {
            fogX[x] = Noise.smooth(0.20f, 0.80f, Noise.fbm2(x * 0.05f - t * 0.035f - sh, 7.7f))
        }
    }

    private fun drawMist(buf: CellBuffer, lm: Float) {
        val t = lastTime
        val sh = shift * cols * 0.05f
        for (y in 0 until rows) {
            val fy = fogY[y]
            if (fy < 0.15f) continue
            for (x in 0 until cols) {
                val m = fy * fogX[x]
                if (m < 0.3f) continue
                val n = Noise.noise2(x * 0.17f - t * 0.06f - sh, y * 0.55f)
                val w = Noise.smooth(0.60f, 0.82f, n) * m * 0.5f * lm
                if (w > 0.01f) buf.max(x, y, w, 0.3f)
            }
        }
    }

    private fun applyFog(buf: CellBuffer, layer: Int) {
        val str = FOG[layer] * (1f + 0.7f * calm)
        val level = buf.level
        for (y in 0 until rows) {
            val fy = fogY[y]
            if (fy <= 0.01f) continue
            val row = y * cols
            for (x in 0 until cols) {
                val f = str * fy * fogX[x]
                level[row + x] *= 1f - min(0.93f, f)
            }
        }
    }

    // ---------------- Небо ----------------

    private fun drawSky(buf: CellBuffer, lm: Float) {
        val c = cols.toFloat()
        val r = rows.toFloat()
        val n = (cols * rows / 160).coerceIn(10, 50)
        for (i in 0 until n) {
            var x = (Noise.hash(i * 3 + 101) * c + shift * c * 0.01f) % c
            if (x < 0f) x += c
            val y = Noise.hash(i * 3 + 102) * r * 0.55f
            val tw = 0.5f + 0.5f * Noise.sin(lastTime * 0.7f + i)
            buf.max(x.toInt(), y.toInt(), (0.14f + 0.16f * tw) * lm, 0.8f)
        }
        val mx = Math.round(c * 0.78f + shift * c * 0.02f)
        val my = Math.round(r * 0.17f)
        val rad = 3.2f
        for (dy in -2..2) for (dx in -4..4) {
            val d = Math.sqrt(((dx / rad) * (dx / rad) + (dy * 1.9f / rad) * (dy * 1.9f / rad)).toDouble()).toFloat()
            val v = if (d < 1f) 0.55f * (1f - 0.4f * d) else if (d < 1.6f) 0.28f * (1.6f - d) / 0.6f else 0f
            if (v > 0f) buf.max(mx + dx, my + dy, v * lm, 0.95f)
        }
    }

    // ---------------- Деревья ----------------

    private fun screenX(i: Int): Float {
        val l = tL[i].toInt()
        val w = layerW[l]
        var x = (tX[i] + shift * cols * PAR[l]) % w
        if (x < 0f) x += w
        return x - layerPad[l]
    }

    private fun drawTree(buf: CellBuffer, i: Int, lm: Float) {
        val l = tL[i].toInt()
        val w = tW[i]
        val h = tH[i]
        val cx0 = screenX(i)
        if (cx0 < -w - 4f || cx0 > cols + w + 4f) return

        var top = wind * 0.55f +
            Noise.sin(lastTime * 1.2f + tPh[i]) * (0.25f + 0.2f * abs(wind)) +
            tShake[i] * Noise.sin(lastTime * 14f + tPh[i]) * 0.8f
        if (bend > 0.01f) {
            val d = cx0 - touchX
            val reach = w * 2.5f + 6f
            val ad = abs(d)
            if (ad < reach) top += (if (d >= 0f) 1f else -1f) * (1f - ad / reach) * bend * 1.2f
        }
        top *= SWAY[l]

        val level = buf.level
        val tint = buf.tint
        val base = tBase[i]
        val trunk = max(1f, h * 0.07f)
        val foliage = h - trunk
        val topY = base - h
        val tiers = tTier[i].toFloat()
        val br = BR[l] * lm
        val tn = TINTL[l]
        val seed = tSeed[i]

        val y0 = max(0, ceil(topY).toInt())
        val y1 = min(rows - 1, (base - trunk).toInt())
        for (yy in y0..y1) {
            val p = ((yy - topY) / foliage).coerceIn(0f, 1f)
            val td = p * tiers
            val f = td - floor(td)
            val half = w * (0.10f + 0.90f * p) * (0.68f + 0.32f * f)
            val q = 1f - p
            val cxr = cx0 + top * q * q
            val xl = max(0, Math.round(cxr - half))
            val xr = min(cols - 1, Math.round(cxr + half))
            val lip = if (f > 0.78f) 1.3f else 1f
            val hw = half + 0.6f
            for (x in xl..xr) {
                val e = abs(x - cxr) / hw
                val moon = 1f + 0.25f * (x - cxr) / hw
                var v = br * (0.28f + 0.72f * e * e) * lip * moon *
                    (0.78f + 0.22f * Noise.hash2(x + seed, yy))
                if (v > 1f) v = 1f
                val idx = yy * cols + x
                level[idx] = v
                tint[idx] = tn + 0.2f * e
            }
        }

        val tx = Math.round(cx0)
        val ty0 = max(0, (base - trunk).toInt())
        val ty1 = min(rows - 1, base.toInt())
        val tw = if (l >= 2) 1 else 0
        for (yy in ty0..ty1) for (dx in 0..tw) {
            val x = tx + dx
            if (x < 0 || x >= cols) continue
            val idx = yy * cols + x
            level[idx] = br * 0.45f
            tint[idx] = tn
        }
    }

    private fun drawGround(buf: CellBuffer, lm: Float) {
        val level = buf.level
        val tint = buf.tint
        val r = rows.toFloat()
        val sh = shift * cols * PAR[2] * 0.09f
        for (x in 0 until cols) {
            val gy = r * 0.875f + (Noise.noise2(x * 0.09f + sh, 2.2f) - 0.5f) * r * 0.04f
            val ys = max(0, gy.toInt())
            for (y in ys until rows) {
                val depth = y - gy
                val idx = y * cols + x
                if (depth < 1.2f) {
                    level[idx] = 0.55f * lm
                    tint[idx] = 0.7f
                } else {
                    level[idx] = 0.14f * (0.5f + Noise.hash2(x, y)) * lm
                    tint[idx] = 0.5f
                }
            }
        }
    }

    // ---------------- Снег и светлячки ----------------

    private fun drawSnow(buf: CellBuffer, lm: Float) {
        val c = cols.toFloat()
        for (i in 0 until snowCount) {
            val l = snL[i].toInt()
            var x = (snX[i] + shift * c * PAR[l]) % c
            if (x < 0f) x += c
            buf.max(x.toInt(), snY[i].toInt(), SNOWB[l] * lm, 0.9f)
        }
    }

    private fun drawFireflies(buf: CellBuffer, lm: Float) {
        val c = cols.toFloat()
        for (i in 0 until ffCount) {
            val blink = Noise.smooth(0.2f, 0.9f, 0.5f + 0.5f * Noise.sin(lastTime * 0.9f + ffPh[i] * 3f))
            val g = min(1.4f, blink + ffBoost * 0.8f)
            val v = (0.15f + 0.85f * g) * lm
            var x = (ffX[i] + shift * c * 0.20f) % c
            if (x < 0f) x += c
            Raster.dot(buf, x, ffY[i], min(1f, v), 1f)
        }
    }

    // ---------------- События ----------------

    override fun onTouch(nx: Float, ny: Float, action: Int) {
        if (cols == 0) return
        touchX = nx.coerceIn(0f, 1f) * cols
        touchY = ny.coerceIn(0f, 1f) * rows
        when (action) {
            TouchAction.DOWN -> {
                touching = true
                lift += 0.6f
                ffBoost = max(ffBoost, 0.6f)
                for (i in 0 until tShake.size) {
                    if (abs(screenX(i) - touchX) < tW[i] * 2f + 8f) tShake[i] = max(tShake[i], 0.7f)
                }
            }
            TouchAction.UP -> touching = false
        }
    }

    override fun onUnlock() {
        if (cols == 0) return
        darkTarget = 0f
        calmTarget = 0f
        flash = 0.5f
        gust = 3.5f
        lift = 3.5f
        ffBoost = 1f
        for (i in 0 until tShake.size) tShake[i] = 1f
    }

    override fun onLock() {
        darkTarget = 1f
        calmTarget = 1f
        gust = 0f
        touching = false
    }

    override fun onScroll(offset: Float, velocity: Float) {
        scrollOffset = offset
        scrollVel = velocity
    }

    override fun onVisibility(visible: Boolean) {
        if (visible) touching = false
    }

    companion object {
        private val H = floatArrayOf(0.34f, 0.50f, 0.68f, 0.92f)
        private val W = floatArrayOf(0.030f, 0.045f, 0.070f, 0.115f)
        private val DENS = floatArrayOf(1f / 6f, 1f / 10f, 1f / 15f, 1f / 26f)
        private val BR = floatArrayOf(0.30f, 0.48f, 0.70f, 0.95f)
        private val TINTL = floatArrayOf(0.10f, 0.22f, 0.36f, 0.50f)
        private val BASE = floatArrayOf(0.82f, 0.86f, 0.93f, 1.05f)
        private val PAR = floatArrayOf(0.03f, 0.08f, 0.17f, 0.34f)
        private val SWAY = floatArrayOf(0.7f, 1.1f, 1.7f, 2.6f)
        private val FOG = floatArrayOf(0.80f, 0.60f, 0.35f, 0f)
        private val SNOWB = floatArrayOf(0.28f, 0.42f, 0.62f, 0.90f)
        private val SNOW_SP = floatArrayOf(0.5f, 0.75f, 1f, 1.3f)
    }
}

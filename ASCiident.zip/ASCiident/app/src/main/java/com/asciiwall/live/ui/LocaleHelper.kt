package com.asciiwall.live.ui

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.asciiwall.live.settings.ThemeMode

/**
 * Язык и ночной режим окна приложения.
 * Язык: per-app locale через AppCompat. Требует, чтобы MainActivity наследовала AppCompatActivity.
 * Одинаковое значение повторно не применяется: активити зря не пересоздаётся.
 */
object LocaleHelper {

    private val SUPPORTED = setOf("en", "uk")

    /** @param lang "system", "en" или "uk" */
    fun apply(lang: String) {
        val list = if (lang in SUPPORTED) LocaleListCompat.forLanguageTags(lang)
        else LocaleListCompat.getEmptyLocaleList()
        if (AppCompatDelegate.getApplicationLocales() != list) {
            AppCompatDelegate.setApplicationLocales(list)
        }
    }

    /** Ночной режим XML-окна. Цвета интерфейса считает AppTheme по настройке. */
    fun applyNightMode(mode: ThemeMode) {
        val m = when (mode) {
            ThemeMode.SYSTEM -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            ThemeMode.DARK -> AppCompatDelegate.MODE_NIGHT_YES
            ThemeMode.LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
        }
        if (AppCompatDelegate.getDefaultNightMode() != m) AppCompatDelegate.setDefaultNightMode(m)
    }
}

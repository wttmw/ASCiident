package com.asciiwall.live.presets.image

import com.asciiwall.live.R
import com.asciiwall.live.core.CellBuffer
import com.asciiwall.live.image.ImageConverter
import com.asciiwall.live.image.ImageSource
import com.asciiwall.live.presets.Noise
import com.asciiwall.live.presets.Preset
import com.asciiwall.live.presets.TouchAction
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Своя картинка в ASCII. Тона считает ImageConverter при смене картинки или ползунков,
 * в кадре только сэмплирование готовой сетки. Яркость картинки служит "глубиной":
 * светлые области сдвигаются при листании сильнее тёмных.
 */
class ImagePreset : Preset() {

    override val id = "image"
    override val nameRes = R.string.preset_image
    override val descRes = R.string.preset_image_desc

    private val converter = ImageConverter()
    private var bLevel = FloatArray(0)
    private var bTint = FloatArray(0)

    private var needConvert = true
    private var lastVer = -1
    private var lastKey = 0
    private var lastAspect = 0f
    private var lastLevels = 0
    private var hasImage = false

    private var sL = 0f
    private var sT = 0f

    private var lastTime = 0f
    private var flash = 0f
    private var dark = 0f
    private var darkTarget = 0f
    private var scrollOffset = 0f
    private var scrollVel = 0f
    private var shift = 0f
    private var lean = 0f
    private var sweep = 0f

    private var touching = false
    private var touchX = 0f
    private var touchY = 0f
    private var prevX = 0f
    private var prevY = 0f
    private var touchTimer = 0f
    private var touchGlow = 0f

    private var revealActive = false
    private var revealR = 0f
    private var revealMax = 1f

    private val rx = FloatArray(RIPPLES)
    private val ry = FloatArray(RIPPLES)
    private val rAge = FloatArray(RIPPLES)
    private val rLife = FloatArray(RIPPLES)
    private val rAmp = FloatArray(RIPPLES)
    private var rNext = 0

    override fun onSizeChanged(cols: Int, rows: Int) {
        super.onSizeChanged(cols, rows)
        bLevel = FloatArray(cols * rows)
        bTint = FloatArray(cols * rows)
        needConvert = true
        hasImage = false
        revealActive = false
        touching = false
        flash = 0f; dark = 0f; darkTarget = 0f
        java.util.Arrays.fill(rAmp, 0f)
        revealMax = sqrt((cols * cols + (rows * 1.9f) * (rows * 1.9f)).toDouble()).toFloat() * 0.5f + 4f
    }

    // ---------------- Конвертация ----------------

    private fun refresh() {
        val s = params.image
        ImageSource.request(s.uri)
        val ver = ImageSource.version
        val key = s.toneKey()
        val asp = params.cellAspect
        val lev = params.glyphLevels
        if (!needConvert && ver == lastVer && key == lastKey && asp == lastAspect && lev == lastLevels) return
        needConvert = false
        lastVer = ver; lastKey = key; lastAspect = asp; lastLevels = lev

        val b = ImageSource.bitmap
        if (!s.isSet || b == null || b.isRecycled) {
            hasImage = false
            return
        }
        converter.convert(b, s, cols, rows, asp, lev, bLevel, bTint)
        hasImage = true
    }

    // ---------------- Кадр ----------------

    override fun update(dt: Float, time: Float) {
        if (cols == 0) return
        lastTime = time
        val bgDt = bg(dt)
        val evDt = ev(dt)
        val pxDt = px(dt)

        refresh()

        val darkRate = if (darkTarget > dark) 1.1f else if (revealActive) 1.0f else 3.2f
        dark += (darkTarget - dark) * min(1f, darkRate * evDt)
        if (flash > 0.001f) flash *= 1f - min(1f, 1.6f * evDt) else flash = 0f
        touchGlow += ((if (touching) 1f else 0f) - touchGlow) * min(1f, 8f * evDt)

        scrollVel *= 1f - min(1f, 3f * pxDt)
        val shiftTarget = -(scrollOffset - 0.5f) * 0.8f
        shift += (shiftTarget - shift) * min(1f, 5f * pxDt)
        val leanTarget = (-scrollVel * 0.5f).coerceIn(-1.5f, 1.5f)
        lean += (leanTarget - lean) * min(1f, 6f * pxDt)

        if (revealActive) {
            revealR += revealMax / 1.2f * evDt
            if (revealR > revealMax + 3f) revealActive = false
        }

        if (touching) {
            touchTimer += evDt
            if (touchTimer > 0.3f && Noise.dist(touchX - prevX, touchY - prevY, params.cellAspect) > 2f) {
                touchTimer = 0f
                prevX = touchX; prevY = touchY
                addRipple(touchX, touchY, 0.35f, 1.0f)
            }
        }

        for (i in 0 until RIPPLES) {
            if (rAmp[i] > 0f) {
                rAge[i] += evDt
                if (rAge[i] >= rLife[i]) rAmp[i] = 0f
            }
        }

        val span = rows * 1.3f
        sweep += bgDt * rows * 0.12f
        if (sweep >= span) sweep -= span
    }

    override fun draw(buffer: CellBuffer) {
        if (cols == 0) return
        if (!hasImage) {
            buffer.clear()
            drawHint(buffer)
            return
        }

        val lv = buffer.level
        val tn = buffer.tint
        val asp = params.cellAspect
        val shiftCells = (shift * PARALLAX + lean * 0.012f) * cols
        val noisy = params.flicker > 0f || params.noise > 0f
        val fstep = (lastTime * 8f).toInt() * 131
        val lm = 1f + flash * 0.6f
        val sweepY = sweep - rows * 0.15f
        val cxm = cols * 0.5f
        val cym = rows * 0.5f
        var anyRipple = false
        for (r in 0 until RIPPLES) if (rAmp[r] > 0f) { anyRipple = true; break }

        for (y in 0 until rows) {
            for (x in 0 until cols) {
                val i = y * cols + x

                var ox = 0f
                var oy = 0f
                if (anyRipple) {
                    for (r in 0 until RIPPLES) {
                        val a = rAmp[r]
                        if (a <= 0f) continue
                        val dx = x - rx[r]
                        val dy = y - ry[r]
                        val d = Noise.dist(dx, dy, asp)
                        if (d < 0.01f) continue
                        val ring = d - rAge[r] * 9f
                        val ar = abs(ring)
                        if (ar < 4f) {
                            val push = a * (1f - rAge[r] / rLife[r]) * Noise.cos(ring * 1.4f) * (1f - ar / 4f) * 1.6f
                            ox += dx / d * push
                            oy += dy / d * push
                        }
                    }
                }
                ox += shiftCells * (0.35f + 0.65f * bLevel[i])

                var v: Float
                var t: Float
                if (ox == 0f && oy == 0f) {
                    v = bLevel[i]
                    t = bTint[i]
                } else {
                    sample(x - ox, y - oy)
                    v = sL
                    t = sT
                }
                if (v <= 0.001f) {
                    lv[i] = 0f
                    continue
                }

                v *= 1f + (Noise.noise3(x * 0.08f, y * 0.15f, lastTime * 0.15f) - 0.5f) * 0.2f

                val sd = abs(y - sweepY)
                if (sd < 2.5f) v *= 1f + 0.5f * (1f - sd / 2.5f)

                if (touchGlow > 0.02f) {
                    val d = Noise.dist(x - touchX, y - touchY, asp)
                    if (d < GLOW_R) v *= 1f + 0.9f * touchGlow * (1f - d / GLOW_R)
                }

                var cd = dark
                if (revealActive) {
                    val dd = Noise.dist(x - cxm, y - cym, asp)
                    val diff = dd - revealR
                    if (diff <= 0f) cd = 0f
                    val ad = abs(diff)
                    if (ad < 2.5f) {
                        val k = 1f - ad / 2.5f
                        v *= 1f + 1.2f * k
                        t += (1f - t) * k
                    } else if (diff > 0f) {
                        v *= 0.2f
                    }
                }
                if (cd > 0.001f) {
                    val a0 = cd * 1.15f - 0.15f
                    v *= Noise.smooth(a0, a0 + 0.15f, Noise.hash2(x, y)) * (1f - 0.5f * cd)
                }

                v *= lm
                if (noisy) v = fx(v.coerceIn(0f, 1f), Noise.hash2(x + fstep, y))
                lv[i] = if (v > 1f) 1f else if (v < 0f) 0f else v
                tn[i] = t
            }
        }
    }

    // ---------------- Сэмплирование ----------------

    private fun lvAt(x: Int, y: Int): Float =
        if (x < 0 || y < 0 || x >= cols || y >= rows) 0f else bLevel[y * cols + x]

    private fun sample(fx: Float, fy: Float) {
        val x0 = floor(fx).toInt()
        val y0 = floor(fy).toInt()
        val tx = fx - x0
        val ty = fy - y0
        val a = lvAt(x0, y0)
        val b = lvAt(x0 + 1, y0)
        val c = lvAt(x0, y0 + 1)
        val d = lvAt(x0 + 1, y0 + 1)
        sL = (a + (b - a) * tx) * (1f - ty) + (c + (d - c) * tx) * ty
        val nx = Math.round(fx)
        val ny = Math.round(fy)
        sT = if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) 0f else bTint[ny * cols + nx]
    }

    // ---------------- Подсказка без картинки ----------------

    private fun drawHint(buf: CellBuffer) {
        val pulse = 0.5f + 0.5f * Noise.sin(lastTime * 1.2f)
        val edge = 0.35f + 0.4f * pulse
        val m = 3
        val hx = 6
        val hy = 3
        for (k in 0..hx) {
            buf.max(m + k, m, edge, 0.8f)
            buf.max(cols - 1 - m - k, m, edge, 0.8f)
            buf.max(m + k, rows - 1 - m, edge, 0.8f)
            buf.max(cols - 1 - m - k, rows - 1 - m, edge, 0.8f)
        }
        for (k in 0..hy) {
            buf.max(m, m + k, edge, 0.8f)
            buf.max(cols - 1 - m, m + k, edge, 0.8f)
            buf.max(m, rows - 1 - m - k, edge, 0.8f)
            buf.max(cols - 1 - m, rows - 1 - m - k, edge, 0.8f)
        }
        val cx = cols / 2
        val cy = rows / 2
        val c = 0.3f + 0.5f * pulse
        for (k in -2..2) buf.max(cx + k, cy, c, 0.9f)
        for (k in -1..1) buf.max(cx, cy + k, c, 0.9f)
    }

    // ---------------- События ----------------

    private fun addRipple(x: Float, y: Float, amp: Float, life: Float) {
        val i = rNext
        rNext = (rNext + 1) % RIPPLES
        rx[i] = x; ry[i] = y
        rAge[i] = 0f; rLife[i] = life; rAmp[i] = amp
    }

    override fun onTouch(nx: Float, ny: Float, action: Int) {
        if (cols == 0) return
        touchX = nx.coerceIn(0f, 1f) * cols
        touchY = ny.coerceIn(0f, 1f) * rows
        when (action) {
            TouchAction.DOWN -> {
                touching = true
                prevX = touchX; prevY = touchY
                touchTimer = 0f
                addRipple(touchX, touchY, 0.9f, 1.6f)
            }
            TouchAction.UP -> {
                touching = false
                addRipple(touchX, touchY, 0.4f, 1.1f)
            }
        }
    }

    override fun onUnlock() {
        if (cols == 0) return
        darkTarget = 0f
        flash = 0.6f
        revealActive = true
        revealR = 0f
        addRipple(cols * 0.5f, rows * 0.5f, 1f, 2.4f)
    }

    override fun onLock() {
        darkTarget = 1f
        revealActive = false
        touching = false
    }

    override fun onScroll(offset: Float, velocity: Float) {
        scrollOffset = offset
        scrollVel = velocity
    }

    override fun onVisibility(visible: Boolean) {
        if (visible) touching = false
    }

    private companion object {
        const val RIPPLES = 6
        const val PARALLAX = 0.05f
        const val GLOW_R = 7f
    }
}

package com.asciiwall.live.presets

import com.asciiwall.live.presets.cave.CavePreset
import com.asciiwall.live.presets.dna.DnaPreset
import com.asciiwall.live.presets.forest.ForestPreset
import com.asciiwall.live.presets.image.ImagePreset
import com.asciiwall.live.presets.shapes.ShapesPreset
import com.asciiwall.live.presets.underwater.UnderwaterPreset

/**
 * Реестр пресетов. Порядок списка = порядок в UI.
 * Новый пресет добавляется одной строкой в [entries].
 */
object PresetRegistry {

    /** Флагман: пресет по умолчанию, первый в списке. */
    const val DEFAULT_ID = "underwater"

    class Entry(val id: String, val create: () -> Preset)

    val entries: List<Entry> = listOf(
        Entry("underwater") { UnderwaterPreset() },
        Entry("forest") { ForestPreset() },
        Entry("cave") { CavePreset() },
        Entry("shapes") { ShapesPreset() },
        Entry("dna") { DnaPreset() },
        Entry("image") { ImagePreset() }
    )

    val ids: List<String> get() = entries.map { it.id }

    fun create(id: String?): Preset {
        val e = entries.firstOrNull { it.id == id } ?: entries.first()
        return e.create()
    }

    fun indexOf(id: String?): Int =
        entries.indexOfFirst { it.id == id }.let { if (it < 0) 0 else it }
}

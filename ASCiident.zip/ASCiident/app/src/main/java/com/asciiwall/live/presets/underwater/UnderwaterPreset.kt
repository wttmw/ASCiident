package com.asciiwall.live.presets.underwater

import com.asciiwall.live.R
import com.asciiwall.live.core.CellBuffer
import com.asciiwall.live.presets.Noise
import com.asciiwall.live.presets.Preset
import com.asciiwall.live.presets.TouchAction
import kotlin.math.abs

/**
 * Флагман: "Подводное течение".
 * Слои: свет -> жизнь -> капля/палец -> общие эффекты (мерцание, шум).
 */
class UnderwaterPreset : Preset() {

    override val id = "underwater"
    override val nameRes = R.string.preset_underwater
    override val descRes = R.string.preset_underwater_desc

    private val s = UnderwaterState()
    private val light = UnderwaterLight()
    private val life = UnderwaterLife()

    private var lastTime = 0f
    private var calmTarget = 0f

    private var dropActive = false
    private var dropT = 0f
    private var dropX = 0f
    private var dropY = 0f

    override fun onSizeChanged(cols: Int, rows: Int) {
        super.onSizeChanged(cols, rows)
        s.resize(cols, rows)
        light.resize(cols, rows)
        dropActive = false
    }

    override fun update(dt: Float, time: Float) {
        if (cols == 0) return
        lastTime = time
        val bgDt = bg(dt)
        val evDt = ev(dt)
        val pxDt = px(dt)

        val darkRate = if (s.darkTarget > s.dark) 1.1f else 3.2f
        s.dark += (s.darkTarget - s.dark) * minOf(1f, darkRate * evDt)
        s.calm += (calmTarget - s.calm) * minOf(1f, 1.4f * evDt)
        if (s.flash > 0.001f) s.flash *= 1f - minOf(1f, 1.6f * evDt) else s.flash = 0f

        s.scrollVel *= 1f - minOf(1f, 3f * pxDt)
        val shiftTarget = -(s.scrollOffset - 0.5f) * 0.8f
        s.shift += (shiftTarget - s.shift) * minOf(1f, 5f * pxDt)
        val swipe = (s.scrollVel * 3f).coerceIn(-2.5f, 2.5f)
        s.flowTarget = BASE_FLOW * (1f - 0.8f * s.calm) - swipe
        s.flowX += (s.flowTarget - s.flowX) * minOf(1f, 2f * pxDt)

        if (s.touching) {
            if (dt > 0.0005f) {
                val vx = (s.touchX - s.touchPrevX) / dt
                val vy = (s.touchY - s.touchPrevY) / dt
                val k = minOf(1f, 10f * dt)
                s.touchVx += (vx.coerceIn(-40f, 40f) - s.touchVx) * k
                s.touchVy += (vy.coerceIn(-40f, 40f) - s.touchVy) * k
            }
            s.touchPrevX = s.touchX
            s.touchPrevY = s.touchY
            s.touchTimer += evDt
            val speed = abs(s.touchVx) + abs(s.touchVy)
            if (s.touchTimer > 0.35f && speed > 3f) {
                s.touchTimer = 0f
                s.addRipple(s.touchX, s.touchY, 0.35f, 7f, 1.0f)
                s.burstBubbles(s.touchX, s.touchY, 1, 0.8f)
            }
        } else {
            s.touchVx *= 1f - minOf(1f, 6f * dt)
            s.touchVy *= 1f - minOf(1f, 6f * dt)
        }

        if (dropActive) {
            dropT += evDt
            if (dropT >= DROP_TIME) {
                dropActive = false
                s.flash = 1f
                s.addRipple(dropX, dropY, 1.0f, 15f, 2.6f)
                s.addRipple(dropX, dropY, 0.6f, 9f, 3.4f)
                life.pushFrom(s, dropX, dropY, 26f, 70f)
                s.burstBubbles(dropX, dropY, 16, 1.2f)
            }
        }

        light.update(s, bgDt, evDt, time)
        life.update(s, light, bgDt, evDt, time)
    }

    override fun draw(buffer: CellBuffer) {
        if (cols == 0) return
        light.draw(s, buffer, lastTime)
        life.draw(s, buffer, lastTime)

        if (dropActive) {
            val p = (dropT / DROP_TIME).coerceIn(0f, 1f)
            val y = dropY * p * p
            val x = dropX.toInt()
            buffer.max(x, y.toInt(), 1f, 1f)
            buffer.max(x, y.toInt() - 1, 0.6f, 0.95f)
            buffer.max(x, y.toInt() - 2, 0.3f, 0.9f)
        }

        if (s.touching) {
            val tx = s.touchX.toInt()
            val ty = s.touchY.toInt()
            for (dy in -1..1) for (dx in -3..3) {
                val d = Noise.dist(dx / 1.9f, dy.toFloat(), 1f)
                val v = 0.55f * (1f - d / 2.2f)
                if (v > 0f) buffer.max(tx + dx, ty + dy, v, 0.9f)
            }
        }

        if (params.flicker > 0f || params.noise > 0f) {
            val step = (lastTime * 8f).toInt() * 131
            val level = buffer.level
            for (y in 0 until rows) {
                for (x in 0 until cols) {
                    val i = y * cols + x
                    val v = level[i]
                    if (v <= 0f) continue
                    level[i] = fx(v, Noise.hash2(x + step, y))
                }
            }
        }
    }

    override fun onTouch(nx: Float, ny: Float, action: Int) {
        if (cols == 0) return
        val x = nx.coerceIn(0f, 1f) * cols
        val y = ny.coerceIn(0f, 1f) * rows
        when (action) {
            TouchAction.DOWN -> {
                s.touching = true
                s.touchX = x; s.touchY = y
                s.touchPrevX = x; s.touchPrevY = y
                s.touchVx = 0f; s.touchVy = 0f
                s.touchTimer = 0f
                s.addRipple(x, y, 0.7f, 9f, 1.6f)
                s.burstBubbles(x, y, 6, 1f)
            }
            TouchAction.MOVE -> {
                s.touchX = x; s.touchY = y
            }
            TouchAction.UP -> {
                s.touching = false
                s.addRipple(x, y, 0.4f, 7f, 1.1f)
            }
        }
    }

    override fun onUnlock() {
        if (cols == 0) return
        s.darkTarget = 0f
        calmTarget = 0f
        dropX = cols * 0.5f
        dropY = rows * 0.38f
        dropT = 0f
        dropActive = true
    }

    override fun onLock() {
        s.darkTarget = 1f
        calmTarget = 1f
        s.touching = false
        dropActive = false
    }

    override fun onScroll(offset: Float, velocity: Float) {
        s.scrollOffset = offset
        s.scrollVel = velocity
    }

    override fun onVisibility(visible: Boolean) {
        if (visible) {
            s.touching = false
        }
    }

    companion object {
        private const val BASE_FLOW = 0.6f
        private const val DROP_TIME = 0.4f
    }
}

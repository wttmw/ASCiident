package com.asciiwall.live.settings

import com.asciiwall.live.core.GridConfig
import com.asciiwall.live.engine.EngineConfig
import com.asciiwall.live.image.ImageSettings
import com.asciiwall.live.presets.PresetRegistry
import org.json.JSONArray
import org.json.JSONObject

/** Четыре множителя скорости. Свой набор у каждого пресета. 0 у global = заморозка. */
data class SpeedSet(
    val global: Float = 1f,
    val background: Float = 1f,
    val events: Float = 1f,
    val parallax: Float = 1f
) {
    fun clamped() = SpeedSet(
        global = if (global < 0.125f) 0f else global.coerceIn(0.25f, 3f),
        background = background.coerceIn(0.25f, 3f),
        events = events.coerceIn(0.25f, 3f),
        parallax = parallax.coerceIn(0.25f, 3f)
    )
}

/** Цвета по умолчанию для каждого пресета: (тень -> свет, фон). */
object PresetLook {
    class Look(val stops: List<Int>, val background: Int)

    private val looks = mapOf(
        "underwater" to Look(listOf(0xFF0B5C8A.toInt(), 0xFFBFF6FF.toInt()), 0xFF010609.toInt()),
        "forest" to Look(listOf(0xFF1F6B4A.toInt(), 0xFFE6FFF2.toInt()), 0xFF020805.toInt()),
        "cave" to Look(listOf(0xFF7A3CFF.toInt(), 0xFF3CFFD8.toInt(), 0xFFE8FFFB.toInt()), 0xFF05030C.toInt()),
        "shapes" to Look(listOf(0xFF2E7D5B.toInt(), 0xFF5CFF8F.toInt()), 0xFF000000.toInt()),
        "dna" to Look(listOf(0xFF1E6BFF.toInt(), 0xFFFF4FD8.toInt()), 0xFF020208.toInt()),
        "image" to Look(listOf(0xFF2E7D5B.toInt(), 0xFFE6FFF2.toInt()), 0xFF000000.toInt())
    )

    fun of(presetId: String): Look = looks[presetId] ?: looks.getValue(PresetRegistry.DEFAULT_ID)
}

/**
 * Профиль: все настройки обоев. Тема интерфейса и язык сюда не входят (см. [UiSettings]).
 * Любые значения проходят через [sanitized], поэтому битый импорт не может уронить движок.
 */
data class Profile(
    val name: String = "Default",
    val presetId: String = PresetRegistry.DEFAULT_ID,

    // Сетка и FPS
    val columns: Int = GridConfig.DEFAULT_COLUMNS,
    val rows: Int = 0,
    val cellAspect: Float = GridConfig.DEFAULT_CELL_ASPECT,
    val fps: Int = GridConfig.DEFAULT_FPS,
    val autoSaver: Boolean = true,

    // Символы
    val charSetId: String = CharSets.DEFAULT_ID,
    val customChars: String = "",

    // Цвет
    val gradientEnabled: Boolean = true,
    val color: Int = 0xFF5CFF8F.toInt(),
    val stops: List<Int> = PresetLook.of(PresetRegistry.DEFAULT_ID).stops,
    val background: Int = PresetLook.of(PresetRegistry.DEFAULT_ID).background,
    val useSystemPalette: Boolean = false,
    val brightness: Float = 1f,

    // Эффекты
    val cutoff: Float = 0.12f,
    val flicker: Float = 0f,
    val noise: Float = 0f,
    val glow: Float = 0f,
    val contrast: Float = 0.5f,

    val speeds: Map<String, SpeedSet> = emptyMap(),

    /** Картинка в ASCII (используется пресетом "image"). */
    val image: ImageSettings = ImageSettings()
) {

    fun speedFor(id: String = presetId): SpeedSet = speeds[id] ?: SpeedSet()

    fun withSpeed(set: SpeedSet, id: String = presetId): Profile =
        copy(speeds = speeds + (id to set.clamped()))

    fun withPreset(id: String, applyLook: Boolean = true): Profile {
        val look = PresetLook.of(id)
        return if (applyLook) copy(presetId = id, stops = look.stops, background = look.background)
        else copy(presetId = id)
    }

    fun sanitized(): Profile {
        val fixedStops = stops.map { opaque(it) }.take(MAX_STOPS).let {
            if (it.size >= 2) it else PresetLook.of(PresetRegistry.DEFAULT_ID).stops
        }
        return copy(
            name = name.trim().take(MAX_NAME).ifEmpty { "Default" },
            presetId = if (presetId in PresetRegistry.ids) presetId else PresetRegistry.DEFAULT_ID,
            columns = columns.coerceIn(GridConfig.MIN_COLUMNS, GridConfig.MAX_COLUMNS),
            rows = if (rows == 0) 0 else rows.coerceIn(GridConfig.MIN_ROWS, GridConfig.MAX_ROWS),
            cellAspect = cellAspect.coerceIn(1.2f, 3.0f),
            fps = if (fps in GridConfig.FPS_OPTIONS) fps else GridConfig.DEFAULT_FPS,
            charSetId = if (charSetId == CharSets.CUSTOM_ID || CharSets.presets.any { it.id == charSetId })
                charSetId else CharSets.DEFAULT_ID,
            customChars = customChars.take(600),
            color = opaque(color),
            stops = fixedStops,
            background = opaque(background),
            brightness = brightness.coerceIn(0f, 2f),
            cutoff = cutoff.coerceIn(0f, 0.6f),
            flicker = flicker.coerceIn(0f, 1f),
            noise = noise.coerceIn(0f, 1f),
            glow = glow.coerceIn(0f, 1f),
            contrast = contrast.coerceIn(0f, 1f),
            speeds = speeds.mapValues { it.value.clamped() },
            image = image.sanitized()
        )
    }

    /** Перевод в конфиг движка. [systemStops] ставит UI, когда включена системная палитра. */
    fun toEngineConfig(systemStops: List<Int>? = null): EngineConfig {
        val p = sanitized()
        val sp = p.speedFor(p.presetId)
        val colors = when {
            p.useSystemPalette && systemStops != null && systemStops.size >= 2 -> systemStops.map { opaque(it) }
            p.gradientEnabled -> p.stops
            else -> listOf(p.color)
        }
        return EngineConfig(
            presetId = p.presetId,
            grid = GridConfig(
                columns = p.columns,
                rows = p.rows,
                cellAspect = p.cellAspect,
                fps = p.fps,
                autoSaver = p.autoSaver
            ),
            chars = CharSets.resolve(p.charSetId, p.customChars),
            stops = colors,
            background = p.background,
            brightness = p.brightness,
            cutoff = p.cutoff,
            flicker = p.flicker,
            noise = p.noise,
            glow = p.glow,
            contrast = p.contrast,
            image = p.image,
            speedGlobal = sp.global,
            speedBackground = sp.background,
            speedEvents = sp.events,
            speedParallax = sp.parallax
        )
    }

    // ---------------- JSON ----------------

    fun toJson(): String {
        val o = JSONObject()
        o.put("v", VERSION)
        o.put("name", name)
        o.put("preset", presetId)
        o.put("columns", columns)
        o.put("rows", rows)
        o.put("aspect", cellAspect.toDouble())
        o.put("fps", fps)
        o.put("autoSaver", autoSaver)
        o.put("charSet", charSetId)
        o.put("customChars", customChars)
        o.put("gradient", gradientEnabled)
        o.put("color", color)
        o.put("stops", JSONArray(stops))
        o.put("background", background)
        o.put("systemPalette", useSystemPalette)
        o.put("brightness", brightness.toDouble())
        o.put("cutoff", cutoff.toDouble())
        o.put("flicker", flicker.toDouble())
        o.put("noise", noise.toDouble())
        o.put("glow", glow.toDouble())
        o.put("contrast", contrast.toDouble())
        val sp = JSONObject()
        for ((id, s) in speeds) {
            sp.put(id, JSONObject()
                .put("g", s.global.toDouble())
                .put("b", s.background.toDouble())
                .put("e", s.events.toDouble())
                .put("p", s.parallax.toDouble()))
        }
        o.put("speeds", sp)
        o.put("image", image.toJson())
        return o.toString()
    }

    companion object {
        const val VERSION = 1
        const val MAX_STOPS = 6
        const val MAX_NAME = 40

        private fun opaque(c: Int): Int = c or 0xFF000000.toInt()

        /** Разбор JSON. Неизвестные поля берутся по умолчанию. null при битом вводе. */
        fun fromJson(text: String): Profile? = try {
            val o = JSONObject(text)
            val d = Profile()
            val stopsArr = o.optJSONArray("stops")
            val stops = if (stopsArr != null) List(stopsArr.length()) { stopsArr.getInt(it) } else d.stops
            val speeds = HashMap<String, SpeedSet>()
            o.optJSONObject("speeds")?.let { sp ->
                for (id in sp.keys()) {
                    val s = sp.getJSONObject(id)
                    speeds[id] = SpeedSet(
                        s.optDouble("g", 1.0).toFloat(),
                        s.optDouble("b", 1.0).toFloat(),
                        s.optDouble("e", 1.0).toFloat(),
                        s.optDouble("p", 1.0).toFloat()
                    )
                }
            }
            Profile(
                name = o.optString("name", d.name),
                presetId = o.optString("preset", d.presetId),
                columns = o.optInt("columns", d.columns),
                rows = o.optInt("rows", d.rows),
                cellAspect = o.optDouble("aspect", d.cellAspect.toDouble()).toFloat(),
                fps = o.optInt("fps", d.fps),
                autoSaver = o.optBoolean("autoSaver", d.autoSaver),
                charSetId = o.optString("charSet", d.charSetId),
                customChars = o.optString("customChars", d.customChars),
                gradientEnabled = o.optBoolean("gradient", d.gradientEnabled),
                color = o.optInt("color", d.color),
                stops = stops,
                background = o.optInt("background", d.background),
                useSystemPalette = o.optBoolean("systemPalette", d.useSystemPalette),
                brightness = o.optDouble("brightness", d.brightness.toDouble()).toFloat(),
                cutoff = o.optDouble("cutoff", d.cutoff.toDouble()).toFloat(),
                flicker = o.optDouble("flicker", d.flicker.toDouble()).toFloat(),
                noise = o.optDouble("noise", d.noise.toDouble()).toFloat(),
                glow = o.optDouble("glow", d.glow.toDouble()).toFloat(),
                contrast = o.optDouble("contrast", d.contrast.toDouble()).toFloat(),
                speeds = speeds,
                image = ImageSettings.fromJson(o.optJSONObject("image"))
            ).sanitized()
        } catch (e: Exception) {
            null
        }
    }
}

/** Настройки интерфейса приложения. Не входят в профиль. */
data class UiSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val themeStyle: ThemeStyle = ThemeStyle.TERMINAL,
    val customAccent: Int = 0xFF5CFF8F.toInt(),
    val previewLight: Boolean = false,
    /** "system", "en" или "uk". */
    val language: String = "system"
)

enum class ThemeMode { SYSTEM, DARK, LIGHT;
    companion object { fun parse(s: String?) = entries.firstOrNull { it.name == s } ?: SYSTEM }
}

enum class ThemeStyle { TERMINAL, MATERIAL, CUSTOM;
    companion object { fun parse(s: String?) = entries.firstOrNull { it.name == s } ?: TERMINAL }
}

package com.asciiwall.live.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.SurfaceTexture
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.OpenInFull
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.asciiwall.live.R
import com.asciiwall.live.engine.ConfigHub
import com.asciiwall.live.engine.EngineConfig
import com.asciiwall.live.engine.WallpaperEngine
import com.asciiwall.live.presets.PresetRegistry
import com.asciiwall.live.presets.TouchAction
import com.asciiwall.live.settings.ColorUtils
import com.asciiwall.live.ui.components.ActionButton
import com.asciiwall.live.ui.components.VSpace
import com.asciiwall.live.ui.theme.App
import com.asciiwall.live.ui.theme.AppShapes
import com.asciiwall.live.ui.theme.AppType
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

// ======================================================================
// View: тот же WallpaperEngine, что и в обоях, на своей поверхности и потоке
// ======================================================================

class PreviewView(context: Context) : TextureView(context), TextureView.SurfaceTextureListener {

    var onStats: ((Int, Int) -> Unit)? = null
    var interactive = false

    @Volatile private var engine = WallpaperEngine()
    @Volatile private var handler: Handler? = null
    @Volatile private var surface: Surface? = null
    @Volatile private var ready = false
    @Volatile private var active = false
    private var thread: HandlerThread? = null
    private var light = false
    private var lastCols = -1
    private var lastFps = -1
    private var lastStatsNanos = 0L

    private val frame = Runnable { step() }
    private val listener: (EngineConfig) -> Unit = { c ->
        engine.setConfig(prepared(c))
        kick()
    }

    init {
        surfaceTextureListener = this
    }

    // ---------------- Настройки ----------------

    fun setCorner(px: Float) {
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, px)
            }
        }
        clipToOutline = px > 0f
    }

    fun setLight(v: Boolean) {
        if (light == v) return
        light = v
        engine.setConfig(prepared(ConfigHub.current))
        kick()
    }

    private fun prepared(c: EngineConfig): EngineConfig =
        if (!light) c else c.copy(
            background = 0xFFF4F8F5.toInt(),
            stops = c.stops.map { ColorUtils.readableAccent(it, false) }
        )

    fun setActive(v: Boolean) {
        if (active == v) return
        active = v
        engine.setVisible(v)
        val h = handler ?: return
        if (v) kick() else h.removeCallbacks(frame)
    }

    // ---------------- Управление сценой ----------------

    fun unlock() { engine.unlock(); kick() }
    fun lock() { engine.lock(); kick() }
    fun scroll(offset: Float) { engine.scroll(offset); kick() }

    // ---------------- Поверхность ----------------

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        val e = WallpaperEngine()
        engine = e
        val t = HandlerThread("ascii-preview", Process.THREAD_PRIORITY_DISPLAY).also { it.start() }
        thread = t
        val hd = Handler(t.looper)
        handler = hd
        val s = Surface(st)
        surface = s
        ready = false
        ConfigHub.addListener(listener)
        e.setConfig(prepared(ConfigHub.current))
        hd.post {
            e.onSurface(w, h)
            ready = true
            e.setVisible(active)
            drawFrame(e, s)
            if (active) kick()
        }
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
        val e = engine
        val s = surface ?: return
        handler?.post {
            e.onSurface(w, h)
            drawFrame(e, s)
        }
    }

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        ConfigHub.removeListener(listener)
        ready = false
        val hd = handler
        val t = thread
        val s = surface
        val e = engine
        handler = null
        thread = null
        surface = null
        hd?.removeCallbacksAndMessages(null)
        hd?.post {
            e.release()
            s?.release()
            t?.quitSafely()
        }
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    // ---------------- Цикл кадров ----------------

    private fun step() {
        val e = engine
        val s = surface ?: return
        if (!active || !ready) return
        if (e.tick()) drawFrame(e, s)
        reportStats(e)
        val delay = if (e.clock.frozen) IDLE_MS
        else e.clock.delayMillis(e.frameNanos).coerceAtLeast(1L)
        handler?.postDelayed(frame, delay)
    }

    private fun kick() {
        val h = handler ?: return
        if (!active || !ready) return
        h.removeCallbacks(frame)
        h.post(frame)
    }

    private fun drawFrame(e: WallpaperEngine, s: Surface) {
        var canvas: Canvas? = null
        try {
            canvas = try {
                s.lockHardwareCanvas()
            } catch (ex: Exception) {
                s.lockCanvas(null)
            }
            if (canvas != null) e.draw(canvas)
        } catch (ex: Exception) {
            // Поверхность исчезла посреди кадра.
        } finally {
            if (canvas != null) {
                try { s.unlockCanvasAndPost(canvas) } catch (ex: Exception) { }
            }
        }
    }

    private fun reportStats(e: WallpaperEngine) {
        val now = System.nanoTime()
        if (now - lastStatsNanos < 500_000_000L) return
        lastStatsNanos = now
        val cols = e.cols
        val fps = if (e.clock.frozen) 0 else e.clock.measuredFps.roundToInt()
        if (cols == lastCols && fps == lastFps) return
        lastCols = cols
        lastFps = fps
        post { onStats?.invoke(cols, fps) }
    }

    // ---------------- Касания (только в раскрытом режиме) ----------------

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!interactive) return false
        val a = when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> TouchAction.DOWN
            MotionEvent.ACTION_MOVE -> TouchAction.MOVE
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> TouchAction.UP
            else -> return true
        }
        val w = width.coerceAtLeast(1)
        val h = height.coerceAtLeast(1)
        engine.touch(ev.x / w, ev.y / h, a)
        kick()
        return true
    }

    private companion object {
        const val IDLE_MS = 200L
    }
}

// ======================================================================
// Compose
// ======================================================================

@Composable
private fun rememberIsStarted(): Boolean {
    val owner = LocalLifecycleOwner.current
    var started by remember { mutableStateOf(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, _ ->
            started = owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return started
}

@Composable
private fun PreviewSurface(
    active: Boolean,
    interactive: Boolean,
    light: Boolean,
    corner: Dp,
    onStats: (Int, Int) -> Unit,
    holder: Array<PreviewView?>,
    modifier: Modifier = Modifier
) {
    val cornerPx = with(LocalDensity.current) { corner.toPx() }
    AndroidView(
        factory = { ctx -> PreviewView(ctx).also { holder[0] = it } },
        update = { v ->
            v.onStats = onStats
            v.interactive = interactive
            v.setCorner(cornerPx)
            v.setLight(light)
            v.setActive(active)
        },
        modifier = modifier
    )
}

@Composable
private fun Scrim(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier
            .clip(AppShapes.chip)
            .background(Color(0x99000000))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) { content() }
}

@Composable
private fun LiveBadge() {
    val c = App.colors
    Scrim {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(c.accent))
            Spacer(Modifier.width(6.dp))
            Text(stringResource(R.string.preview_live), style = AppType.tag, color = c.accent)
        }
    }
}

@Composable
private fun NameTag(name: String, modifier: Modifier = Modifier) {
    Scrim(modifier) {
        Text(name.uppercase(), style = AppType.tag, color = Color(0xFFE6F2EA), maxLines = 1)
    }
}

/** Закреплённое превью: компактное окно и раскрытие на весь экран. */
@Composable
fun PreviewPane(presetId: String, lightPreview: Boolean, modifier: Modifier = Modifier) {
    val c = App.colors
    var expanded by rememberSaveable { mutableStateOf(false) }
    var cols by remember { mutableIntStateOf(0) }
    var fps by remember { mutableIntStateOf(0) }
    val started = rememberIsStarted()
    val onStats: (Int, Int) -> Unit = { cl, f -> cols = cl; fps = f }
    val presetName = stringResource(remember(presetId) { PresetRegistry.create(presetId).nameRes })
    val holder = remember { arrayOfNulls<PreviewView>(1) }
    val height = (LocalConfiguration.current.screenHeightDp * 0.25f).dp
    val expandLabel = stringResource(R.string.preview_expand)

    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(R.string.preview_title),
                style = AppType.tag,
                color = c.accent,
                modifier = Modifier.weight(1f),
                maxLines = 1
            )
            Text(
                stringResource(R.string.preview_stats, cols, fps),
                style = AppType.label,
                color = c.textMuted,
                maxLines = 1
            )
        }
        VSpace(10.dp)
        Box(
            Modifier
                .fillMaxWidth()
                .height(height)
                .clip(AppShapes.preview)
                .background(c.previewBg)
                .border(1.dp, c.border, AppShapes.preview)
        ) {
            PreviewSurface(
                active = started && !expanded,
                interactive = false,
                light = lightPreview,
                corner = 27.dp,
                onStats = onStats,
                holder = holder,
                modifier = Modifier.fillMaxSize()
            )
            Box(Modifier.align(Alignment.TopStart).padding(12.dp)) { LiveBadge() }
            NameTag(presetName, Modifier.align(Alignment.BottomEnd).padding(12.dp))
            Scrim(Modifier.align(Alignment.TopEnd).padding(12.dp)) {
                Icon(Icons.Rounded.OpenInFull, contentDescription = null, tint = Color(0xFFE6F2EA), modifier = Modifier.size(16.dp))
            }
            Box(
                Modifier
                    .matchParentSize()
                    .semantics { contentDescription = expandLabel }
                    .clickable { expanded = true }
            )
        }
    }

    if (expanded) {
        FullPreview(
            presetName = presetName,
            light = lightPreview,
            started = started,
            onStats = onStats,
            onClose = { expanded = false }
        )
    }
}

/** Раскрытое превью: весь экран, касания, кнопки проверки событий. */
@Composable
private fun FullPreview(
    presetName: String,
    light: Boolean,
    started: Boolean,
    onStats: (Int, Int) -> Unit,
    onClose: () -> Unit
) {
    val c = App.colors
    val holder = remember { arrayOfNulls<PreviewView>(1) }
    val scope = rememberCoroutineScope()
    var shown by remember { mutableStateOf(false) }
    var parallaxJob by remember { mutableStateOf<Job?>(null) }
    val collapseLabel = stringResource(R.string.preview_collapse)

    LaunchedEffect(Unit) { shown = true }

    fun close() {
        scope.launch {
            shown = false
            delay(220)
            onClose()
        }
    }

    fun runParallax() {
        parallaxJob?.cancel()
        parallaxJob = scope.launch {
            var from = 0.5f
            for (to in floatArrayOf(0.1f, 0.9f, 0.5f)) {
                animate(from, to, animationSpec = tween(900, easing = FastOutSlowInEasing)) { v, _ ->
                    holder[0]?.scroll(v)
                }
                from = to
            }
        }
    }

    Dialog(
        onDismissRequest = { close() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        AnimatedVisibility(
            visible = shown,
            enter = fadeIn(tween(220)) + scaleIn(tween(260), initialScale = 0.92f, transformOrigin = TransformOrigin(0.5f, 0f)),
            exit = fadeOut(tween(200)) + scaleOut(tween(200), targetScale = 0.92f, transformOrigin = TransformOrigin(0.5f, 0f))
        ) {
            Box(Modifier.fillMaxSize().background(c.previewBg)) {
                PreviewSurface(
                    active = started,
                    interactive = true,
                    light = light,
                    corner = 0.dp,
                    onStats = onStats,
                    holder = holder,
                    modifier = Modifier.fillMaxSize()
                )

                Box(Modifier.fillMaxWidth().systemBarsPadding().padding(12.dp)) {
                    Box(Modifier.align(Alignment.TopStart)) { LiveBadge() }
                    Box(
                        Modifier
                            .align(Alignment.TopCenter)
                            .size(width = 120.dp, height = 36.dp)
                            .pointerInput(Unit) {
                                var total = 0f
                                detectVerticalDragGestures(
                                    onDragStart = { total = 0f },
                                    onVerticalDrag = { _, d -> total += d },
                                    onDragEnd = { if (total > 60f) close() }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.size(width = 40.dp, height = 4.dp).clip(CircleShape).background(Color(0x99FFFFFF)))
                    }
                    Scrim(
                        Modifier
                            .align(Alignment.TopEnd)
                            .semantics { contentDescription = collapseLabel }
                            .clickable { close() }
                    ) {
                        Icon(Icons.Rounded.Close, contentDescription = null, tint = Color(0xFFE6F2EA), modifier = Modifier.size(18.dp))
                    }
                }

                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .systemBarsPadding()
                        .padding(12.dp)
                ) {
                    NameTag(presetName, Modifier.align(Alignment.End))
                    VSpace(10.dp)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(AppShapes.card)
                            .background(c.card.copy(alpha = 0.88f))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ActionButton(stringResource(R.string.test_unlock), { holder[0]?.unlock() }, Modifier.weight(1f), filled = true)
                        ActionButton(stringResource(R.string.test_lock), { holder[0]?.lock() }, Modifier.weight(1f))
                        ActionButton(stringResource(R.string.test_parallax), { runParallax() }, Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

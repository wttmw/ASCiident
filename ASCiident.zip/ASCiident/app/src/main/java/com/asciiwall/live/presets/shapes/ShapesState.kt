package com.asciiwall.live.presets.shapes

import com.asciiwall.live.presets.Noise

/** Типы фигур (геометрия в ShapesGeometry). */
object Shape {
    const val CUBE = 0
    const val OCTA = 1
    const val RING = 2
    const val TETRA = 3
    const val COUNT = 4
}

/**
 * Состояние сцены "Летающие фигуры". Мировые единицы: y от -WORLD_H/2 до WORLD_H/2,
 * z больше = дальше. Невесомость: скорость почти не гасится.
 */
class ShapesState {

    var cols = 0
        private set
    var rows = 0
        private set

    var halfW = 4f
        private set
    var halfH = WORLD_H / 2f
        private set

    var count = 0
        private set
    var kind = ByteArray(0)
    var x = FloatArray(0); var y = FloatArray(0); var z = FloatArray(0)
    var vx = FloatArray(0); var vy = FloatArray(0); var vz = FloatArray(0)
    var ax = FloatArray(0); var ay = FloatArray(0); var az = FloatArray(0)
    var wx = FloatArray(0); var wy = FloatArray(0); var wz = FloatArray(0)
    var bwx = FloatArray(0); var bwy = FloatArray(0); var bwz = FloatArray(0)
    var size = FloatArray(0)
    var tint = FloatArray(0)
    var dx = FloatArray(0); var dy = FloatArray(0)

    // ---- События ----
    var flash = 0f
    var dark = 0f
    var darkTarget = 0f
    var calm = 0f
    var calmTarget = 0f
    var scrollOffset = 0f
    var scrollVel = 0f
    var shift = 0f

    var touching = false
    var touchX = 0f
    var touchY = 0f
    var touchVx = 0f
    var touchVy = 0f
    var touchPrevX = 0f
    var touchPrevY = 0f

    var waveActive = false
    var waveR = 0f
    var waveX = 0f
    var waveY = 0f

    fun resize(newCols: Int, newRows: Int, aspect: Float) {
        cols = newCols
        rows = newRows
        halfH = WORLD_H / 2f
        halfW = cols * 0.5f / (rows * aspect / WORLD_H)

        count = (cols / 16).coerceIn(4, 7)
        kind = ByteArray(count)
        x = FloatArray(count); y = FloatArray(count); z = FloatArray(count)
        vx = FloatArray(count); vy = FloatArray(count); vz = FloatArray(count)
        ax = FloatArray(count); ay = FloatArray(count); az = FloatArray(count)
        wx = FloatArray(count); wy = FloatArray(count); wz = FloatArray(count)
        bwx = FloatArray(count); bwy = FloatArray(count); bwz = FloatArray(count)
        size = FloatArray(count); tint = FloatArray(count)
        dx = FloatArray(count); dy = FloatArray(count)
        for (i in 0 until count) spawn(i)

        flash = 0f; dark = 0f; darkTarget = 0f; calm = 0f; calmTarget = 0f
        waveActive = false
        touching = false
    }

    fun spawn(i: Int) {
        val s = i * 61 + 7
        kind[i] = (i % Shape.COUNT).toByte()
        val slot = (i + 0.5f) / count
        x[i] = (slot - 0.5f) * 2f * halfW * 0.85f
        y[i] = (Noise.hash(s) - 0.5f) * halfH * 1.4f
        z[i] = Noise.hash(s + 1) * 3.2f - 0.8f
        vx[i] = 0f; vy[i] = 0f; vz[i] = 0f
        ax[i] = Noise.hash(s + 2) * 6.2832f
        ay[i] = Noise.hash(s + 3) * 6.2832f
        az[i] = Noise.hash(s + 4) * 6.2832f
        bwx[i] = (Noise.hash(s + 5) - 0.5f) * 1.2f
        bwy[i] = (Noise.hash(s + 6) - 0.5f) * 1.6f
        bwz[i] = (Noise.hash(s + 7) - 0.5f) * 0.9f
        wx[i] = bwx[i]; wy[i] = bwy[i]; wz[i] = bwz[i]
        size[i] = 0.75f + Noise.hash(s + 8) * 0.55f
        tint[i] = Noise.hash(s + 9)
        dx[i] = (Noise.hash(s + 10) - 0.5f) * 0.22f
        dy[i] = (Noise.hash(s + 11) - 0.5f) * 0.16f
    }

    fun step(dt: Float) {
        val drag = (0.30f + 0.9f * calm) * dt
        val spinRelax = (0.5f + 1.5f * calm) * dt
        val spinMul = 1f - 0.75f * calm
        val k = if (drag > 1f) 1f else drag
        val sr = if (spinRelax > 1f) 1f else spinRelax

        for (i in 0 until count) {
            vx[i] += (dx[i] * (1f - calm) - vx[i]) * k
            vy[i] += (dy[i] * (1f - calm) - vy[i]) * k
            vz[i] += (0f - vz[i]) * k

            wx[i] += (bwx[i] * spinMul - wx[i]) * sr * 0.6f
            wy[i] += (bwy[i] * spinMul - wy[i]) * sr * 0.6f
            wz[i] += (bwz[i] * spinMul - wz[i]) * sr * 0.6f

            x[i] += vx[i] * dt
            y[i] += vy[i] * dt
            z[i] += vz[i] * dt
            ax[i] += wx[i] * dt
            ay[i] += wy[i] * dt
            az[i] += wz[i] * dt

            val mx = halfW * 0.92f
            val my = halfH * 0.92f
            if (x[i] > mx) vx[i] -= (x[i] - mx) * 4f * dt
            else if (x[i] < -mx) vx[i] -= (x[i] + mx) * 4f * dt
            if (y[i] > my) vy[i] -= (y[i] - my) * 4f * dt
            else if (y[i] < -my) vy[i] -= (y[i] + my) * 4f * dt
            if (z[i] > 3.2f) vz[i] -= (z[i] - 3.2f) * 3f * dt
            else if (z[i] < -1f) vz[i] -= (z[i] + 1f) * 3f * dt
        }

        for (i in 0 until count) {
            for (j in i + 1 until count) {
                val ddx = x[i] - x[j]
                val ddy = y[i] - y[j]
                val ddz = (z[i] - z[j]) * 0.5f
                val d2 = ddx * ddx + ddy * ddy + ddz * ddz
                val r = (size[i] + size[j]) * 0.95f
                if (d2 < r * r && d2 > 0.0001f) {
                    val d = Math.sqrt(d2.toDouble()).toFloat()
                    val f = (r - d) / d * 2.2f * dt
                    vx[i] += ddx * f; vy[i] += ddy * f
                    vx[j] -= ddx * f; vy[j] -= ddy * f
                }
            }
        }

        if (touching) {
            for (i in 0 until count) {
                val ddx = x[i] - touchX
                val ddy = y[i] - touchY
                val d = Math.sqrt((ddx * ddx + ddy * ddy).toDouble()).toFloat()
                val reach = 2.6f + size[i]
                if (d < reach) {
                    val f = (1f - d / reach) / (d + 0.3f)
                    vx[i] += ddx * f * 7f * dt + touchVx * f * 0.03f
                    vy[i] += ddy * f * 7f * dt + touchVy * f * 0.03f
                    wy[i] += ddx * f * 3f * dt
                    wx[i] -= ddy * f * 3f * dt
                }
            }
        }

        if (waveActive) {
            waveR += 9f * dt
            if (waveR > halfW * 2.4f) waveActive = false
        }
    }

    fun burst(px: Float, py: Float, strength: Float) {
        for (i in 0 until count) {
            var ddx = x[i] - px
            var ddy = y[i] - py
            var d = Math.sqrt((ddx * ddx + ddy * ddy).toDouble()).toFloat()
            if (d < 0.2f) { ddx = Noise.hash(i + 3) - 0.5f; ddy = Noise.hash(i + 9) - 0.5f; d = 0.5f }
            val f = strength / (d + 1.2f)
            vx[i] += ddx / d * f
            vy[i] += ddy / d * f
            vz[i] += (Noise.hash(i * 5 + 1) - 0.5f) * f * 0.6f
            wx[i] += (Noise.hash(i * 5 + 2) - 0.5f) * f * 2.2f
            wy[i] += (Noise.hash(i * 5 + 3) - 0.5f) * f * 2.2f
            wz[i] += (Noise.hash(i * 5 + 4) - 0.5f) * f * 1.6f
        }
        waveActive = true
        waveR = 0f
        waveX = px
        waveY = py
    }

    fun swipe(impulse: Float) {
        for (i in 0 until count) {
            val depth = 0.5f + 0.5f * (1f - ((z[i] + 1f) / 4.2f).coerceIn(0f, 1f))
            vx[i] += impulse * depth * 0.5f
            wy[i] += impulse * depth * 0.8f
        }
    }

    companion object {
        const val WORLD_H = 8f
    }
}

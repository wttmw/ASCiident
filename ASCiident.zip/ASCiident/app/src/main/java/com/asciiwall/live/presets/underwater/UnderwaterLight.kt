package com.asciiwall.live.presets.underwater

import com.asciiwall.live.core.CellBuffer
import com.asciiwall.live.presets.Noise

/**
 * Свет сцены: поверхность, столбы света, каустики, дальнее течение, кольца от событий.
 * Рисуется ПЕРВЫМ: сам обнуляет level/tint каждой ячейки.
 */
class UnderwaterLight {

    private var surf = FloatArray(0)
    private var shaft = FloatArray(0)

    fun resize(cols: Int, rows: Int) {
        surf = FloatArray(cols)
        shaft = FloatArray(cols + rows + 4)
    }

    /** Поле течения в точке (ячейки). Результат в out[0]=vx, out[1]=vy. */
    fun flow(s: UnderwaterState, x: Float, y: Float, time: Float, out: FloatArray) {
        val n = Noise.noise3(x * 0.07f, y * 0.11f, time * 0.12f)
        val m = Noise.noise3(x * 0.09f + 31f, y * 0.08f + 17f, time * 0.10f)
        out[0] = s.flowX * (0.35f + n * 1.3f)
        out[1] = (m - 0.5f) * 1.6f * (1f - s.calm)
    }

    fun update(s: UnderwaterState, bgDt: Float, evDt: Float, time: Float) {
        val cols = s.cols
        val rows = s.rows
        if (surf.size != cols) return

        for (r in 0 until UnderwaterState.MAX_RIPPLES) {
            if (s.rAmp[r] > 0f) {
                s.rAge[r] += evDt
                if (s.rAge[r] >= s.rLife[r]) s.rAmp[r] = 0f
            }
        }

        val amp = 1f - 0.6f * s.calm
        for (x in 0 until cols) {
            val fx = x.toFloat()
            var h = 1.8f + amp * (
                0.55f * Noise.sin(fx * 0.23f + time * 0.9f) +
                0.35f * Noise.sin(fx * 0.11f - time * 0.6f + 1.7f) +
                (Noise.noise2(fx * 0.12f, time * 0.35f) - 0.5f) * 1.0f
            )
            for (r in 0 until UnderwaterState.MAX_RIPPLES) {
                val a = s.rAmp[r]
                if (a <= 0f) continue
                val d = Math.abs(fx - s.rx[r]) - s.rAge[r] * s.rSpeed[r]
                val ad = Math.abs(d)
                if (ad < 4f) {
                    val fade = 1f - s.rAge[r] / s.rLife[r]
                    val reach = 1f - (s.ry[r] / rows).coerceIn(0f, 1f)
                    h += a * fade * reach * Noise.cos(d * 1.6f) * (1f - ad / 4f) * 1.6f
                }
            }
            surf[x] = h
        }

        for (i in shaft.indices) {
            val u = i * 0.085f
            val n = Noise.noise2(u - time * 0.045f, time * 0.05f)
            val pulse = 0.75f + 0.25f * Noise.sin(time * 0.4f + i * 0.3f)
            shaft[i] = Noise.smooth(0.50f, 0.85f, n) * pulse
        }
    }

    fun draw(s: UnderwaterState, buf: CellBuffer, time: Float) {
        val cols = buf.cols
        val rows = buf.rows
        if (surf.size != cols) return
        val level = buf.level
        val tint = buf.tint

        val lightMul = (1f + s.flash * 0.8f) * (1f - s.dark * 0.85f)
        val shiftFar = s.shift * cols * Depth.parallax[Depth.FAR]
        val shiftMid = s.shift * cols * Depth.parallax[Depth.MID]
        val shiftSurf = s.shift * cols * Depth.parallax[Depth.SURFACE]
        val ts = time * 0.3f * Depth.speed[Depth.SURFACE]
        val rowsF = (rows - 1).coerceAtLeast(1).toFloat()

        for (y in 0 until rows) {
            val t = y / rowsF
            val d = 1f - t
            val dl = d * d + s.flash * 0.25f * d
            val ay = y.toFloat()

            for (x in 0 until cols) {
                val i = y * cols + x
                level[i] = 0f
                tint[i] = 0.2f

                val sy = surf[x]
                if (ay < sy - 0.5f) continue
                val dy = ay - sy

                // 1. Дальнее течение.
                val fx = x - shiftFar
                val n = Noise.fbm2(fx * 0.05f - time * 0.03f * Depth.speed[Depth.FAR], ay * 0.09f)
                val far = Noise.smooth(0.60f, 0.92f, n) * 0.22f * Depth.brightness[Depth.FAR] * lightMul
                if (far > 0f) put(level, tint, i, far, 0.12f)

                // 2. Столбы света.
                val si = (x + (ay * 0.4f).toInt() - shiftMid.toInt()).coerceIn(0, shaft.size - 1)
                val sh = shaft[si] * (d * (0.5f + 0.5f * d)) * 0.45f * Depth.brightness[Depth.MID] * lightMul
                if (sh > 0.01f) put(level, tint, i, sh, 0.7f)

                // 3. Каустики.
                if (t < 0.65f) {
                    val xs = x - shiftSurf
                    val r1 = 1f - Math.abs(Noise.noise3(xs * 0.16f, ay * 0.30f, ts) * 2f - 1f)
                    val r2 = 1f - Math.abs(Noise.noise3(xs * 0.22f + 9.1f, ay * 0.38f + 3.7f, 20f - ts * 0.8f) * 2f - 1f)
                    val c = Noise.smooth(0.70f, 0.96f, r1 * r2)
                    if (c > 0f) {
                        put(level, tint, i, c * dl * 0.85f * Depth.brightness[Depth.NEAR] * lightMul, 0.85f)
                    }
                }

                // 4. Гребень поверхности.
                if (dy < 2.2f) {
                    val crest = (1f - dy / 2.2f) * Depth.brightness[Depth.SURFACE] *
                        (0.8f + 0.2f * Noise.sin(x * 0.5f + time * 2f)) * lightMul
                    put(level, tint, i, crest, 1f)
                }
            }
        }

        for (r in 0 until UnderwaterState.MAX_RIPPLES) {
            val a = s.rAmp[r]
            if (a <= 0f) continue
            val ring = s.rAge[r] * s.rSpeed[r]
            if (ring < 0.5f) continue
            val env = a * (1f - s.rAge[r] / s.rLife[r])
            drawRing(buf, s.rx[r], s.ry[r], ring, env * 0.9f)
            drawRing(buf, s.rx[r], s.ry[r], ring * 0.82f, env * 0.4f)
        }
    }

    private fun drawRing(buf: CellBuffer, cx: Float, cy: Float, radius: Float, v: Float) {
        if (v <= 0.01f) return
        val steps = (radius * 8.2f).toInt().coerceIn(12, 220)
        val k = 6.2832f / steps
        val level = buf.level
        val tint = buf.tint
        for (n in 0 until steps) {
            val ang = n * k
            val xx = (cx + Noise.cos(ang) * radius).toInt()
            val yy = (cy + Noise.sin(ang) * radius / 1.9f).toInt()
            if (!buf.inBounds(xx, yy)) continue
            put(level, tint, yy * buf.cols + xx, v, 0.92f)
        }
    }

    private fun put(level: FloatArray, tint: FloatArray, i: Int, v: Float, tv: Float) {
        val nv = level[i] + v
        tint[i] += (tv - tint[i]) * (v / (nv + 0.0001f))
        level[i] = if (nv > 1f) 1f else nv
    }
}

package com.asciiwall.live

import android.app.Application
import com.asciiwall.live.engine.ConfigHub
import com.asciiwall.live.image.ImageSource
import com.asciiwall.live.settings.ColorUtils
import com.asciiwall.live.settings.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Холодный старт процесса: читает сохранённый профиль один раз и кладёт его в ConfigHub.
 * Без этого после перезагрузки обои стартовали бы с настройками по умолчанию.
 */
class AsciiApp : Application() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        ImageSource.init(this)
        scope.launch {
            try {
                val profile = SettingsRepository.get(this@AsciiApp).profileOnce()
                ConfigHub.publish(profile.toEngineConfig(ColorUtils.systemStops(this@AsciiApp)))
            } catch (e: Exception) {
                // Остаёмся на настройках по умолчанию.
            }
        }
    }
}

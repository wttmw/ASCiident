package com.asciiwall.live.engine

import android.graphics.Canvas
import android.os.SystemClock
import com.asciiwall.live.core.AsciiRenderer
import com.asciiwall.live.core.FrameClock
import com.asciiwall.live.core.GridConfig
import com.asciiwall.live.image.ImageSettings
import com.asciiwall.live.presets.Preset
import com.asciiwall.live.presets.PresetRegistry
import com.asciiwall.live.presets.SceneParams
import java.util.concurrent.atomic.AtomicReference

/** Настройки движка. Неизменяемые: UI собирает новый объект и отдаёт в setConfig(). */
data class EngineConfig(
    val presetId: String = PresetRegistry.DEFAULT_ID,
    val grid: GridConfig = GridConfig(),
    val chars: String = DEFAULT_CHARS,
    /** Цвета градиента: первый = глубина/тень, последний = свет. */
    val stops: List<Int> = listOf(0xFF0B5C8A.toInt(), 0xFFBFF6FF.toInt()),
    val background: Int = 0xFF010609.toInt(),
    val brightness: Float = 1f,
    val cutoff: Float = 0.12f,
    val flicker: Float = 0f,
    val noise: Float = 0f,
    val glow: Float = 0f,
    val contrast: Float = 0.5f,
    val image: ImageSettings = ImageSettings(),
    val speedGlobal: Float = 1f,
    val speedBackground: Float = 1f,
    val speedEvents: Float = 1f,
    val speedParallax: Float = 1f
) {
    companion object {
        const val DEFAULT_CHARS = " .:-=+*#%@"
    }
}

/**
 * Движок: пресет + рендерер + часы + очередь событий.
 * Не знает про Surface, поэтому одинаково работает для обоев и для превью в приложении.
 *
 * Потоки: tick(), draw(), onSurface() вызывать только из потока рендера.
 * Из любого потока безопасны: setConfig, touch, unlock, lock, scroll, setVisible, setPower.
 */
class WallpaperEngine {

    val renderer = AsciiRenderer()
    val clock = FrameClock()

    private var preset: Preset = PresetRegistry.create(null)
    private var presetId = ""
    private val params = SceneParams()

    private var config = EngineConfig()
    private val pending = AtomicReference<EngineConfig?>(EngineConfig())
    private var configured = false

    private var surfaceW = 0
    private var surfaceH = 0

    @Volatile private var visible = false
    @Volatile var batteryLow = false
    @Volatile var powerSave = false

    private var forceRender = true

    private val queue = EventQueue()
    private val outType = IntArray(1)
    private val outA = IntArray(1)
    private val outX = FloatArray(1)
    private val outY = FloatArray(1)

    private val scrollLock = Any()
    private var lastOffset = -1f
    private var lastOffsetNanos = 0L
    private var scrollVel = 0f

    val cols: Int get() = renderer.buffer.cols
    val rows: Int get() = renderer.buffer.rows

    val targetFps: Int get() = config.grid.effectiveFps(batteryLow, powerSave)

    val frameNanos: Long get() = 1_000_000_000L / targetFps

    // ---------------- Потокобезопасный вход ----------------

    fun setConfig(c: EngineConfig) {
        pending.set(c)
    }

    fun touch(nx: Float, ny: Float, action: Int) = queue.push(E_TOUCH, action, nx, ny)

    fun unlock() = queue.push(E_UNLOCK, 0, 0f, 0f)

    fun lock() = queue.push(E_LOCK, 0, 0f, 0f)

    /** @param offset 0..1 позиция рабочего стола */
    fun scroll(offset: Float) {
        val now = SystemClock.elapsedRealtimeNanos()
        val vel: Float
        synchronized(scrollLock) {
            if (lastOffset >= 0f && now > lastOffsetNanos) {
                val dt = (now - lastOffsetNanos) / 1_000_000_000f
                val v = ((offset - lastOffset) / dt).coerceIn(-6f, 6f)
                scrollVel = scrollVel * 0.5f + v * 0.5f
            }
            lastOffset = offset
            lastOffsetNanos = now
            vel = scrollVel
        }
        queue.push(E_SCROLL, 0, offset, vel)
    }

    fun setVisible(v: Boolean) {
        visible = v
        queue.push(E_VISIBLE, if (v) 1 else 0, 0f, 0f)
    }

    fun setPower(batteryLow: Boolean, powerSave: Boolean) {
        this.batteryLow = batteryLow
        this.powerSave = powerSave
    }

    // ---------------- Поток рендера ----------------

    fun onSurface(width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        surfaceW = width
        surfaceH = height
        rebuild(forcePresetResize = true)
    }

    fun requestRedraw() {
        renderer.buffer.invalidate()
        forceRender = true
    }

    /** Один шаг кадра. Возвращает true, если нужно вывести кадр на экран. */
    fun tick(): Boolean {
        val c = pending.getAndSet(null)
        if (c != null) applyConfig(c)
        if (!configured) return false

        if (!clock.tick(frameNanos)) return false

        val hadEvents = drainEvents()
        if (clock.frozen && !hadEvents && !forceRender) return renderer.needsDraw

        preset.update(clock.dt, clock.time)
        preset.draw(renderer.buffer)
        renderer.render(params.cutoff, config.brightness, config.contrast, config.glow)
        forceRender = false
        return renderer.needsDraw
    }

    fun draw(canvas: Canvas, dx: Float = 0f, dy: Float = 0f) = renderer.draw(canvas, dx, dy)

    fun release() {
        preset.release()
        renderer.release()
        configured = false
    }

    // ---------------- Внутреннее ----------------

    private fun applyConfig(c: EngineConfig) {
        val old = config
        val first = !configured && presetId.isEmpty()
        config = c

        clock.speed = c.speedGlobal
        params.cutoff = c.cutoff
        params.bgSpeed = c.speedBackground
        params.eventSpeed = c.speedEvents
        params.parallaxSpeed = c.speedParallax
        params.flicker = c.flicker
        params.noise = c.noise
        params.image = c.image
        params.cellAspect = c.grid.cellAspect

        var presetChanged = false
        if (first || c.presetId != presetId) {
            preset.release()
            preset = PresetRegistry.create(c.presetId)
            preset.params = params
            presetId = c.presetId
            presetChanged = true
        }

        if (surfaceW > 0) {
            val styleChanged = !configured || c.stops != old.stops || c.background != old.background
            val gridChanged = !configured || c.grid != old.grid || c.chars != old.chars
            if (styleChanged) renderer.setStyle(c.stops.toIntArray(), c.background)
            if (gridChanged) {
                rebuild(forcePresetResize = presetChanged)
            } else if (presetChanged) {
                preset.onSizeChanged(renderer.buffer.cols, renderer.buffer.rows)
            }
        }
        forceRender = true
    }

    private fun rebuild(forcePresetResize: Boolean) {
        val c = config
        if (!configured) renderer.setStyle(c.stops.toIntArray(), c.background)
        val oc = renderer.buffer.cols
        val or = renderer.buffer.rows
        renderer.configure(surfaceW, surfaceH, c.grid, c.chars)
        params.glyphLevels = renderer.atlas?.glyphCount ?: 10
        val nc = renderer.buffer.cols
        val nr = renderer.buffer.rows
        if (!configured || forcePresetResize || nc != oc || nr != or) {
            preset.params = params
            preset.onSizeChanged(nc, nr)
        }
        configured = true
        forceRender = true
    }

    private fun drainEvents(): Boolean {
        var any = false
        while (queue.pop(outType, outA, outX, outY)) {
            any = true
            when (outType[0]) {
                E_TOUCH -> preset.onTouch(outX[0], outY[0], outA[0])
                E_UNLOCK -> preset.onUnlock()
                E_LOCK -> preset.onLock()
                E_SCROLL -> preset.onScroll(outX[0], outY[0])
                E_VISIBLE -> {
                    val v = outA[0] == 1
                    if (v) {
                        clock.reset()
                        forceRender = true
                    }
                    preset.onVisibility(v)
                }
            }
        }
        return any
    }

    private fun List<Int>.toIntArray(): IntArray {
        val a = IntArray(size)
        for (i in indices) a[i] = this[i]
        return a
    }

    companion object {
        private const val E_TOUCH = 1
        private const val E_UNLOCK = 2
        private const val E_LOCK = 3
        private const val E_SCROLL = 4
        private const val E_VISIBLE = 5
    }
}

/**
 * Кольцевая очередь событий на примитивах. Подряд идущие MOVE склеиваются
 * (остаётся последняя позиция), поэтому поток касаний не копится между кадрами.
 */
private class EventQueue {
    private val type = IntArray(CAP)
    private val a = IntArray(CAP)
    private val x = FloatArray(CAP)
    private val y = FloatArray(CAP)
    private var head = 0
    private var size = 0

    @Synchronized
    fun push(t: Int, ia: Int, fx: Float, fy: Float) {
        if (t == 1 && ia == MOVE && size > 0) {
            val last = (head + size - 1) % CAP
            if (type[last] == 1 && a[last] == MOVE) {
                x[last] = fx
                y[last] = fy
                return
            }
        }
        if (size == CAP) {
            head = (head + 1) % CAP
            size--
        }
        val i = (head + size) % CAP
        type[i] = t; a[i] = ia; x[i] = fx; y[i] = fy
        size++
    }

    @Synchronized
    fun pop(outType: IntArray, outA: IntArray, outX: FloatArray, outY: FloatArray): Boolean {
        if (size == 0) return false
        outType[0] = type[head]; outA[0] = a[head]
        outX[0] = x[head]; outY[0] = y[head]
        head = (head + 1) % CAP
        size--
        return true
    }

    private companion object {
        const val CAP = 64
        const val MOVE = 1
    }
}

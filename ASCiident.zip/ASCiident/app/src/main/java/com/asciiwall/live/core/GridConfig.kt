package com.asciiwall.live.core

import kotlin.math.roundToInt

/**
 * Параметры сетки и частоты кадров.
 * rows == 0 означает авто-расчёт по пропорциям экрана.
 */
data class GridConfig(
    val columns: Int = DEFAULT_COLUMNS,
    val rows: Int = 0,
    val cellAspect: Float = DEFAULT_CELL_ASPECT,
    val fps: Int = DEFAULT_FPS,
    val autoSaver: Boolean = true
) {
    init {
        require(columns in MIN_COLUMNS..MAX_COLUMNS) { "columns out of range" }
        require(rows == 0 || rows in MIN_ROWS..MAX_ROWS) { "rows out of range" }
        require(cellAspect in 1.2f..3.0f) { "cellAspect out of range" }
        require(fps in FPS_OPTIONS) { "fps not supported" }
    }

    fun cellWidth(surfaceWidth: Int): Float = surfaceWidth.toFloat() / columns

    fun cellHeight(surfaceWidth: Int): Float = cellWidth(surfaceWidth) * cellAspect

    fun resolveRows(surfaceWidth: Int, surfaceHeight: Int): Int {
        if (rows != 0) return rows
        val h = cellHeight(surfaceWidth)
        return (surfaceHeight / h).roundToInt().coerceIn(MIN_ROWS, MAX_ROWS)
    }

    fun cellCount(surfaceWidth: Int, surfaceHeight: Int): Int =
        columns * resolveRows(surfaceWidth, surfaceHeight)

    val frameNanos: Long get() = 1_000_000_000L / fps

    fun effectiveFps(batteryLow: Boolean, powerSave: Boolean): Int = when {
        !autoSaver -> fps
        powerSave -> minOf(fps, 15)
        batteryLow -> minOf(fps, 24)
        else -> fps
    }

    companion object {
        const val MIN_COLUMNS = 20
        const val MAX_COLUMNS = 200
        const val MIN_ROWS = 10
        const val MAX_ROWS = 200
        const val DEFAULT_COLUMNS = 80
        const val DEFAULT_CELL_ASPECT = 1.9f
        const val DEFAULT_FPS = 30
        val FPS_OPTIONS = intArrayOf(15, 24, 30, 60)
    }
}

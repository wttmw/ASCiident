package com.asciiwall.live.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.asciiwall.live.engine.ConfigHub
import com.asciiwall.live.image.ImageDecode
import com.asciiwall.live.image.ImageSettings
import com.asciiwall.live.settings.ColorUtils
import com.asciiwall.live.settings.Profile
import com.asciiwall.live.settings.SettingsRepository
import com.asciiwall.live.settings.SpeedSet
import com.asciiwall.live.settings.UiSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Одноразовые сообщения для UI (тосты). */
enum class UiEvent { SAVED, LIMIT, LOADED, IMPORTED, IMPORT_FAILED, IMAGE_FAILED }

/**
 * Состояние всего приложения.
 * Правка настроек: сразу в память и в ConfigHub (превью и обои реагируют мгновенно),
 * на диск с задержкой 400 мс после последнего изменения.
 */
class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = SettingsRepository.get(app)
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _profile = MutableStateFlow(Profile())
    val profile: StateFlow<Profile> = _profile.asStateFlow()

    private val _saved = MutableStateFlow<List<Profile>>(emptyList())
    val saved: StateFlow<List<Profile>> = _saved.asStateFlow()

    private val _ui = MutableStateFlow(UiSettings())
    val ui: StateFlow<UiSettings> = _ui.asStateFlow()

    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()

    private val _imageMissing = MutableStateFlow(false)
    val imageMissing: StateFlow<Boolean> = _imageMissing.asStateFlow()

    private val _events = MutableSharedFlow<UiEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    private var saveJob: Job? = null

    init {
        viewModelScope.launch {
            _profile.value = repo.profileOnce()
            _ui.value = repo.uiOnce()
            _saved.value = repo.saved.first()
            _loaded.value = true
            publish()
            checkImage()
            launch { repo.saved.collect { _saved.value = it } }
            launch { repo.ui.collect { _ui.value = it } }
        }
    }

    // ---------------- Профиль ----------------

    fun update(block: (Profile) -> Profile) {
        if (!_loaded.value) return
        _profile.value = block(_profile.value).sanitized()
        publish()
        scheduleSave()
    }

    fun setPreset(id: String) = update { it.withPreset(id) }

    fun setSpeed(block: (SpeedSet) -> SpeedSet) = update { p -> p.withSpeed(block(p.speedFor())) }

    fun resetCurrent() = update { p ->
        Profile(name = p.name, image = p.image).withPreset(p.presetId)
    }

    private fun publish() {
        val p = _profile.value
        val system = if (p.useSystemPalette) ColorUtils.systemStops(getApplication()) else null
        ConfigHub.publish(p.toEngineConfig(system))
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = ioScope.launch {
            delay(SAVE_DELAY_MS)
            repo.setProfile(_profile.value)
        }
    }

    /** Немедленная запись. Вызывать из onStop. */
    fun flush() {
        if (!_loaded.value) return
        saveJob?.cancel()
        val p = _profile.value
        ioScope.launch { repo.setProfile(p) }
    }

    override fun onCleared() {
        flush()
        super.onCleared()
    }

    // ---------------- Сохранённые профили ----------------

    fun saveAs(name: String) {
        if (!_loaded.value) return
        viewModelScope.launch {
            saveJob?.cancel()
            repo.setProfile(_profile.value)
            val ok = repo.saveCurrentAs(name)
            if (ok) {
                _profile.value = repo.profileOnce()
                _events.tryEmit(UiEvent.SAVED)
            } else {
                _events.tryEmit(UiEvent.LIMIT)
            }
        }
    }

    fun load(name: String) {
        viewModelScope.launch {
            if (repo.loadSaved(name)) {
                saveJob?.cancel()
                _profile.value = repo.profileOnce()
                publish()
                checkImage()
                _events.tryEmit(UiEvent.LOADED)
            }
        }
    }

    fun delete(name: String) {
        viewModelScope.launch {
            repo.deleteSaved(name)
            pruneImages()
        }
    }

    suspend fun export(name: String? = null): String {
        if (name == null) repo.setProfile(_profile.value)
        return repo.exportJson(name)
    }

    fun import(text: String) {
        viewModelScope.launch {
            val name = repo.importJson(text)
            _events.tryEmit(if (name != null) UiEvent.IMPORTED else UiEvent.IMPORT_FAILED)
        }
    }

    // ---------------- Интерфейс ----------------

    fun updateUi(block: (UiSettings) -> UiSettings) {
        _ui.value = block(_ui.value)
        val n = _ui.value
        ioScope.launch { repo.updateUi { n } }
    }

    // ---------------- Картинка ----------------

    /** Копирует выбранную картинку в файлы приложения, проверяет декодирование, ставит в профиль. */
    fun setImage(source: Uri) {
        if (!_loaded.value) return
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) { copyImage(source) }
            if (path == null) {
                _events.tryEmit(UiEvent.IMAGE_FAILED)
                return@launch
            }
            _imageMissing.value = false
            update { it.copy(image = it.image.copy(uri = path)) }
            flush()
            withContext(Dispatchers.IO) { pruneImages() }
        }
    }

    fun clearImage() {
        update { it.copy(image = it.image.copy(uri = "")) }
        _imageMissing.value = false
        flush()
        ioScope.launch { pruneImages() }
    }

    fun updateImage(block: (ImageSettings) -> ImageSettings) =
        update { it.copy(image = block(it.image)) }

    private fun imageDir(): File = File(getApplication<Application>().filesDir, "images").apply { mkdirs() }

    private fun copyImage(source: Uri): String? {
        val app = getApplication<Application>()
        val dir = imageDir()
        val tmp = File(dir, "tmp.bin")
        val dest = File(dir, "img_${System.currentTimeMillis()}")
        return try {
            val input = app.contentResolver.openInputStream(source) ?: return null
            input.use { ins ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    var total = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > MAX_IMAGE_BYTES) {
                            tmp.delete()
                            return null
                        }
                        out.write(buf, 0, n)
                    }
                }
            }
            val probe = ImageDecode.decode(app, tmp.absolutePath, 256)
            if (probe == null) {
                tmp.delete()
                return null
            }
            probe.recycle()
            if (!tmp.renameTo(dest)) {
                tmp.delete()
                return null
            }
            dest.absolutePath
        } catch (e: Exception) {
            tmp.delete()
            null
        }
    }

    /** Удаляет файлы картинок, на которые не ссылается ни текущий, ни сохранённый профиль. */
    private suspend fun pruneImages() {
        val used = HashSet<String>()
        used.add(_profile.value.image.uri)
        for (p in repo.saved.first()) used.add(p.image.uri)
        val files = imageDir().listFiles() ?: return
        for (f in files) if (f.absolutePath !in used) f.delete()
    }

    private fun checkImage() {
        val uri = _profile.value.image.uri
        _imageMissing.value = uri.isNotEmpty() && !File(uri).exists()
    }

    private companion object {
        const val SAVE_DELAY_MS = 400L
        const val MAX_IMAGE_BYTES = 25L * 1024 * 1024
    }
}

package com.asciiwall.live.presets.dna

import com.asciiwall.live.R
import com.asciiwall.live.core.CellBuffer
import com.asciiwall.live.presets.Noise
import com.asciiwall.live.presets.Preset
import com.asciiwall.live.presets.TouchAction
import com.asciiwall.live.presets.shapes.Math3D
import com.asciiwall.live.presets.shapes.Raster
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sqrt

/**
 * ДНК: двойная спираль по диагонали, бесконечная.
 * Рабочие координаты "квадратные": X = ячейка x, Y = ячейка y * ASPECT.
 */
class DnaPreset : Preset() {

    override val id = "dna"
    override val nameRes = R.string.preset_dna
    override val descRes = R.string.preset_dna_desc

    private var radius = 10f
    private var pitch = 40f
    private var freq = 0.15f
    private var halfLen = 100f
    private var cx = 0f
    private var cy = 0f

    private val dirX = Noise.cos(ANGLE)
    private val dirY = -Noise.sin(ANGLE)
    private val nX = Noise.sin(ANGLE)
    private val nY = Noise.cos(ANGLE)

    private var rot = 0f
    private var slide = 0f
    private var slideVel = 0f
    private var spinBoost = 0f
    private var lastTime = 0f

    private var flash = 0f
    private var dark = 0f
    private var darkTarget = 0f
    private var calm = 0f
    private var calmTarget = 0f
    private var bendAmt = 0f
    private var touching = false
    private var touchX = 0f
    private var touchY = 0f
    private var waveActive = false
    private var waveU = 0f
    private var scrollOffset = 0f
    private var scrollVel = 0f
    private var shift = 0f

    private val o = FloatArray(2)

    override fun onSizeChanged(cols: Int, rows: Int) {
        super.onSizeChanged(cols, rows)
        val w = cols.toFloat()
        val h = rows * Math3D.ASPECT
        radius = w * 0.17f
        pitch = w * 0.55f
        freq = 6.2831855f / pitch
        halfLen = sqrt(w * w + h * h) * 0.5f + radius + 4f
        cx = w * 0.5f
        cy = h * 0.5f
        waveActive = false
        flash = 0f; dark = 0f; darkTarget = 0f; calm = 0f; calmTarget = 0f
        touching = false
    }

    override fun update(dt: Float, time: Float) {
        if (cols == 0) return
        lastTime = time
        val bgDt = bg(dt)
        val evDt = ev(dt)
        val pxDt = px(dt)

        val darkRate = if (darkTarget > dark) 1.1f else 3.2f
        dark += (darkTarget - dark) * minOf(1f, darkRate * evDt)
        calm += (calmTarget - calm) * minOf(1f, 1.4f * evDt)
        if (flash > 0.001f) flash *= 1f - minOf(1f, 1.6f * evDt) else flash = 0f
        bendAmt += ((if (touching) 1f else 0f) - bendAmt) * minOf(1f, 6f * evDt)
        spinBoost *= 1f - minOf(1f, 1.2f * evDt)

        scrollVel *= 1f - minOf(1f, 3f * pxDt)
        val shiftTarget = -(scrollOffset - 0.5f) * 0.8f
        shift += (shiftTarget - shift) * minOf(1f, 5f * pxDt)
        spinBoost = minOf(4f, spinBoost + abs(scrollVel) * pxDt * 4f)
        slideVel += -scrollVel * pxDt * 60f
        slideVel *= 1f - minOf(1f, 2f * pxDt)

        rot += bgDt * (0.9f * (1f - 0.85f * calm) + spinBoost)
        if (rot > 6.2831855f) rot -= 6.2831855f
        slide += bgDt * 5f * (1f - 0.8f * calm) + slideVel * bgDt
        if (slide >= pitch) slide -= pitch else if (slide < 0f) slide += pitch

        if (waveActive) {
            waveU += evDt * 150f
            if (waveU > halfLen + 20f) waveActive = false
        }
    }

    override fun draw(buffer: CellBuffer) {
        if (cols == 0) return
        buffer.clear()
        val lm = (1f + flash * 0.6f) * (1f - dark * 0.85f)

        // ---- Нити ----
        val n = (2f * halfLen / STEP).toInt()
        var p0x = 0f; var p0y = 0f; var p0v = 0f
        var p1x = 0f; var p1y = 0f; var p1v = 0f
        for (i in 0..n) {
            val u = -halfLen + i * STEP
            val ph = (u - slide) * freq + rot
            val sn = Noise.sin(ph)
            val cs = Noise.cos(ph)
            val bx = cx + dirX * u
            val by = cy + dirY * u
            val wv = waveBoost(u)

            val f0 = 0.5f + 0.5f * cs
            place(bx + nX * radius * sn, by + nY * radius * sn, f0)
            val x0 = o[0]; val y0 = o[1]
            val v0 = shade(f0) * lm + wv * (0.4f + 0.6f * f0)

            val f1 = 1f - f0
            place(bx - nX * radius * sn, by - nY * radius * sn, f1)
            val x1 = o[0]; val y1 = o[1]
            val v1 = shade(f1) * lm + wv * (0.4f + 0.6f * f1)

            if (i > 0) {
                Raster.line(buffer, p0x, p0y, p0v, x0, y0, v0, f0 * 0.6f + 0.4f)
                Raster.line(buffer, p1x, p1y, p1v, x1, y1, v1, f1 * 0.6f + 0.4f)
            }
            p0x = x0; p0y = y0; p0v = v0
            p1x = x1; p1y = y1; p1v = v1
        }

        // ---- Перемычки ----
        val spacing = pitch / RUNGS_PER_TURN
        val kStart = floor((-halfLen - slide) / spacing).toInt()
        var k = kStart
        while (true) {
            val u = slide + k * spacing
            if (u > halfLen) break
            if (u >= -halfLen) {
                val ph = k * spacing * freq + rot
                val sn = Noise.sin(ph)
                val cs = Noise.cos(ph)
                val bx = cx + dirX * u
                val by = cy + dirY * u
                val wv = waveBoost(u)

                val fa = 0.5f + 0.5f * cs
                place(bx + nX * radius * sn, by + nY * radius * sn, fa)
                val ax = o[0]; val ay = o[1]
                val fb = 1f - fa
                place(bx - nX * radius * sn, by - nY * radius * sn, fb)
                val bx2 = o[0]; val by2 = o[1]

                val va = shade(fa) * lm * 0.7f + wv * 0.6f
                val vb = shade(fb) * lm * 0.7f + wv * 0.6f
                Raster.line(buffer, ax, ay, va, bx2, by2, vb, 0.5f + 0.4f * wv)
                Raster.dot(buffer, ax, ay, minOf(1f, va * 1.3f), 0.85f)
                Raster.dot(buffer, bx2, by2, minOf(1f, vb * 1.3f), 0.85f)
            }
            k++
        }

        // ---- Ореол под пальцем ----
        if (touching) {
            val tx = Math.round(touchX)
            val ty = Math.round(touchY / Math3D.ASPECT)
            for (dy in -1..1) for (dx in -3..3) {
                val d = Noise.dist(dx / 1.9f, dy.toFloat(), 1f)
                val v = 0.5f * (1f - d / 2.2f)
                if (v > 0f) buffer.max(tx + dx, ty + dy, v, 0.9f)
            }
        }

        if (params.flicker > 0f || params.noise > 0f) {
            val step = (lastTime * 8f).toInt() * 131
            val level = buffer.level
            for (y in 0 until rows) {
                for (x in 0 until cols) {
                    val i = y * cols + x
                    val v = level[i]
                    if (v <= 0f) continue
                    level[i] = fx(v, Noise.hash2(x + step, y))
                }
            }
        }
    }

    private fun shade(front: Float): Float = 0.15f + 0.85f * front * front

    private fun waveBoost(u: Float): Float {
        if (!waveActive) return 0f
        val w = 1f - abs(u - waveU) / 16f
        return if (w > 0f) w * w else 0f
    }

    private fun place(x: Float, y: Float, front: Float) {
        var px = x
        var py = y
        if (bendAmt > 0.01f) {
            val dx = x - touchX
            val dy = y - touchY
            val d = sqrt(dx * dx + dy * dy)
            val reach = radius * 2.4f
            if (d < reach && d > 0.01f) {
                var f = 1f - d / reach
                f = f * f * bendAmt * radius * 1.4f
                px += dx / d * f
                py += dy / d * f
            }
        }
        o[0] = px + shift * cols * (0.10f + 0.08f * front)
        o[1] = py / Math3D.ASPECT
    }

    override fun onTouch(nx: Float, ny: Float, action: Int) {
        if (cols == 0) return
        touchX = nx.coerceIn(0f, 1f) * cols
        touchY = ny.coerceIn(0f, 1f) * rows * Math3D.ASPECT
        when (action) {
            TouchAction.DOWN -> {
                touching = true
                spinBoost = minOf(4f, spinBoost + 0.6f)
            }
            TouchAction.UP -> touching = false
        }
    }

    override fun onUnlock() {
        if (cols == 0) return
        darkTarget = 0f
        calmTarget = 0f
        flash = 0.6f
        spinBoost = 3f
        waveU = -halfLen
        waveActive = true
    }

    override fun onLock() {
        darkTarget = 1f
        calmTarget = 1f
        touching = false
        waveActive = false
    }

    override fun onScroll(offset: Float, velocity: Float) {
        scrollOffset = offset
        scrollVel = velocity
    }

    override fun onVisibility(visible: Boolean) {
        if (visible) touching = false
    }

    companion object {
        private const val ANGLE = 1.0f
        private const val STEP = 1.3f
        private const val RUNGS_PER_TURN = 9f
    }
}

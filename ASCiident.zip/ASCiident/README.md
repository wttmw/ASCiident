# ASCiident

ASCII live wallpaper for Android (Kotlin, Jetpack Compose). minSdk 26, targetSdk 35.

## Build on GitHub
1. Push the contents of this folder to a repository (the folder with `settings.gradle.kts` must be the repo root).
2. Open **Actions → Build APK → Run workflow** (it also runs on every push).
3. Download the `ASCiident-debug-apk` artifact and install the APK.

## Build locally
Needs JDK 17 and Gradle 8.9+: `gradle :app:assembleDebug`
(or open the folder in Android Studio, which creates the Gradle wrapper for you).
